import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import OpenAI from "openai";
import { parseStringPromise } from "xml2js";
import { readFileSync, existsSync } from "fs";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const NODE_ENV = process.env.NODE_ENV || "development";

function parseTrustProxySetting(value) {
  const raw = String(value || "").trim();
  const lowered = raw.toLowerCase();

  if (!raw || ["false", "0", "no", "off"].includes(lowered)) return null;
  if (["true", "1", "yes", "on"].includes(lowered)) return 1;

  const numeric = Number(raw);
  if (Number.isInteger(numeric) && numeric > 0 && numeric <= 10) return numeric;

  // Express also accepts trusted proxy names such as "loopback" or CIDR/IP lists.
  return raw;
}

const trustProxySetting = parseTrustProxySetting(process.env.TRUST_PROXY);
if (trustProxySetting !== null) {
  app.set("trust proxy", trustProxySetting);
}

const DATA4LIBRARY_API_KEY = process.env.DATA4LIBRARY_API_KEY;
const NAVER_CLIENT_ID = process.env.NAVER_CLIENT_ID;
const NAVER_CLIENT_SECRET = process.env.NAVER_CLIENT_SECRET;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const NOTION_API_KEY = process.env.NOTION_API_KEY;
const NOTION_FAQ_DATABASE_ID = process.env.NOTION_FAQ_DATABASE_ID;
const NOTION_VERSION = process.env.NOTION_VERSION || "2022-06-28";

/* 국립중앙도서관 Open API */
const NL_API_KEY =
  process.env.NL_API_KEY ||
  process.env.NATIONAL_LIBRARY_API_KEY ||
  process.env.NL_OPEN_API_KEY ||
  "";

const openai = OPENAI_API_KEY
  ? new OpenAI({ apiKey: OPENAI_API_KEY })
  : null;

const VALID_REGION_CODES = new Set([
  "11", "21", "22", "23", "24", "25", "26", "29",
  "31", "32", "33", "34", "35", "36", "37", "38", "39"
]);
const DATA4LIBRARY_REGION_CODES = [...VALID_REGION_CODES];

const LIBRARY_CACHE_TTL_MS = 1000 * 60 * 30; // 30분
const DATA4LIBRARY_COOLDOWN_MS = 1000 * 60 * 5; // 5분 (기존 20분 → 단축)
const NATIONAL_LIBRARY_ENRICH_LIMIT = 3;
const GPT_CLASSIFIER_MODEL = process.env.OPENAI_CLASSIFIER_MODEL || "gpt-4o-mini";

function parsePositiveIntegerEnv(name, fallback, min = 1) {
  const parsed = Number(process.env[name]);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.max(min, Math.floor(parsed));
}

const EXTERNAL_FETCH_TIMEOUT_MS = parsePositiveIntegerEnv("EXTERNAL_FETCH_TIMEOUT_MS", 15_000, 1000);
const RATE_LIMIT_WINDOW_MS = parsePositiveIntegerEnv("RATE_LIMIT_WINDOW_MS", 60_000, 1000);
const RATE_LIMIT_GENERAL_MAX = parsePositiveIntegerEnv("RATE_LIMIT_GENERAL_MAX", 120);
const RATE_LIMIT_HEAVY_MAX = parsePositiveIntegerEnv("RATE_LIMIT_HEAVY_MAX", 30);
const RATE_LIMIT_ASSIST_MAX = parsePositiveIntegerEnv("RATE_LIMIT_ASSIST_MAX", 20);
const RATE_LIMIT_ADMIN_MAX = parsePositiveIntegerEnv("RATE_LIMIT_ADMIN_MAX", 5);
const HEALTH_EXPOSE_DETAILS = process.env.HEALTH_EXPOSE_DETAILS === "1";

const LIBRARY_SEARCH_MAX_PAGES_WITH_REGION = 8;
const LIBRARY_SEARCH_MAX_PAGES_NATIONWIDE = 2;
const LIBRARY_SEARCH_CACHE_TTL_MS = 1000 * 60 * 15; // 15분
const LIBRARY_KEYWORD_FETCH_CACHE_TTL_MS = 1000 * 60 * 15; // 15분
const LIBRARY_SEARCH_MAX_PAGES_WITH_DTL_REGION = 4;
const LIBRARY_BY_BOOK_MAX_PAGES_WITH_REGION = parsePositiveIntegerEnv("LIBRARY_BY_BOOK_MAX_PAGES_WITH_REGION", 10);
const LIBRARY_BY_BOOK_MAX_PAGES_PER_REGION_NATIONWIDE = parsePositiveIntegerEnv("LIBRARY_BY_BOOK_MAX_PAGES_PER_REGION_NATIONWIDE", 4);
const LIBRARY_BY_BOOK_FETCH_CONCURRENCY = Math.min(5, parsePositiveIntegerEnv("LIBRARY_BY_BOOK_FETCH_CONCURRENCY", 3));
const LIBRARY_BY_BOOK_NATIONWIDE_REGION_CONCURRENCY = Math.min(5, parsePositiveIntegerEnv("LIBRARY_BY_BOOK_NATIONWIDE_REGION_CONCURRENCY", 3));
const POPULAR_BOOK_CACHE_TTL_MS = 1000 * 60 * 20; // 20분
const POPULAR_BOOK_PAGE_SIZE = 20;
const BOOK_RECOMMENDATION_CACHE_TTL_MS = 1000 * 60 * 20; // 20분
const BOOK_RECOMMENDATION_MAX_SEARCH_QUERIES = 4;
const BOOK_RECOMMENDATION_RESULT_LIMIT = 20;
const QUERY_UNDERSTANDING_CACHE_TTL_MS = 1000 * 60 * 10; // 10분
const QUERY_UNDERSTANDING_VALID_INTENTS = new Set([
  "book_search",
  "book_availability",
  "library_search",
  "popular_books",
  "book_recommendation",
  "book_info",
  "faq",
  "ambiguous",
  "unknown"
]);
const QUERY_UNDERSTANDING_VALID_API_ROUTES = new Set([
  "books",
  "books_then_holdings",
  "libraries",
  "popular_books",
  "book_recommendations",
  "assist",
  "clarify",
  "none"
]);
const NEARBY_LIBRARY_RESULT_LIMIT = parsePositiveIntegerEnv("NEARBY_LIBRARY_RESULT_LIMIT", 12);
const NEARBY_LIBRARY_RADIUS_KM = (() => {
  const parsed = Number(process.env.NEARBY_LIBRARY_RADIUS_KM);
  if (!Number.isFinite(parsed) || parsed <= 0) return 4;
  return Math.min(20, parsed);
})();
const NAVER_PLACE_ANCHOR_ENABLED = /^(1|true|yes|on)$/i.test(String(process.env.NAVER_PLACE_ANCHOR_ENABLED || ""));
const NAVER_PLACE_ANCHOR_TIMEOUT_MS = parsePositiveIntegerEnv("NAVER_PLACE_ANCHOR_TIMEOUT_MS", 5_000, 1000);
const NAVER_PLACE_ANCHOR_DISPLAY = Math.min(5, parsePositiveIntegerEnv("NAVER_PLACE_ANCHOR_DISPLAY", 5, 1));
const PLACE_ANCHOR_CACHE_TTL_MS = parsePositiveIntegerEnv("PLACE_ANCHOR_CACHE_TTL_MS", 1000 * 60 * 60, 60_000);

// 전국도서관표준데이터 XML DB 관련
const STANDARD_LIB_XML_PATH = process.env.STANDARD_LIB_XML_PATH || new URL("./library_data.xml", import.meta.url).pathname;
const STANDARD_LIB_RELOAD_INTERVAL_MS = 1000 * 60 * 60 * 24; // 24시간마다 재로드

const libraryCache = new Map();
const librarySearchCache = new Map();
const libraryKeywordFetchCache = new Map();
const popularBooksCache = new Map();
const bookRecommendationCache = new Map();
const queryUnderstandingCache = new Map();
const placeAnchorCache = new Map();
let data4LibraryCooldownUntil = 0;

// 전국도서관표준데이터 XML 인메모리 DB
let standardLibraryDb = [];
let standardLibraryLoadedAt = 0;

function getLibraryCacheKey(isbn, region = "") {
  return `${String(isbn || "").trim()}::${String(region || "").trim()}`;
}

function getCachedLibraries(isbn, region = "") {
  const key = getLibraryCacheKey(isbn, region);
  const cached = libraryCache.get(key);

  if (!cached) return null;
  if (Date.now() > cached.expiresAt) {
    libraryCache.delete(key);
    return null;
  }

  return cached.data;
}

function setCachedLibraries(isbn, region = "", data = []) {
  const key = getLibraryCacheKey(isbn, region);

  libraryCache.set(key, {
    data,
    expiresAt: Date.now() + LIBRARY_CACHE_TTL_MS
  });

  if (libraryCache.size > 500) {
    const firstKey = libraryCache.keys().next().value;
    if (firstKey) libraryCache.delete(firstKey);
  }
}


function getTimedCacheValue(cache, key) {
  const cached = cache.get(key);
  if (!cached) return null;
  if (Date.now() > cached.expiresAt) {
    cache.delete(key);
    return null;
  }
  return cached.data;
}

function setTimedCacheValue(cache, key, data, ttlMs) {
  cache.set(key, {
    data,
    expiresAt: Date.now() + ttlMs
  });

  if (cache.size > 500) {
    const firstKey = cache.keys().next().value;
    if (firstKey) cache.delete(firstKey);
  }
}

function shouldStartData4LibraryCooldown(message = "") {
  const text = String(message || "").trim();
  if (!text) return false;

  return (
    text.includes("1일 500건 이상 요청 시 IP 등록이 필요합니다") ||
    text.includes("등록 된 IP를 확인하시기 바랍니다")
  );
}

function activateData4LibraryCooldown(reason = "") {
  data4LibraryCooldownUntil = Date.now() + DATA4LIBRARY_COOLDOWN_MS;
  console.log("[DATA4LIBRARY COOLDOWN]", {
    until: new Date(data4LibraryCooldownUntil).toISOString(),
    reason: String(reason || "").slice(0, 300)
  });
}

function isData4LibraryCoolingDown() {
  return Date.now() < data4LibraryCooldownUntil;
}

function getData4LibraryCooldownMessage() {
  return "현재 도서관 API 사용 제한으로 검색이 일시적으로 불가합니다.";
}

function normalizeCorsOrigin(origin) {
  const raw = String(origin || "").trim();
  if (!raw) return "";

  try {
    const parsed = new URL(raw);
    if (!["http:", "https:"].includes(parsed.protocol)) return "";
    return `${parsed.protocol}//${parsed.host}`;
  } catch (error) {
    // Keep an explicit origin-like value as a last resort, but remove trailing slashes.
    return raw.replace(/\/+$/, "");
  }
}

const PRODUCTION_CORS_ORIGINS = [
  "https://minervalib.com",
  "https://www.minervalib.com"
].map(normalizeCorsOrigin).filter(Boolean);

const DEVELOPMENT_CORS_ORIGINS = [
  "http://localhost:3000",
  "http://127.0.0.1:3000",
  "http://localhost:5500",
  "http://127.0.0.1:5500"
].map(normalizeCorsOrigin).filter(Boolean);

const EXTRA_CORS_ORIGINS = String(process.env.ALLOWED_ORIGINS || "")
  .split(",")
  .map(normalizeCorsOrigin)
  .filter(Boolean);

const ALLOWED_CORS_ORIGINS = new Set([
  ...PRODUCTION_CORS_ORIGINS,
  ...(NODE_ENV === "production" ? [] : DEVELOPMENT_CORS_ORIGINS),
  ...EXTRA_CORS_ORIGINS
]);

app.use(cors({
  origin(origin, callback) {
    // Non-browser requests such as health checks or curl calls may not include Origin.
    if (!origin || ALLOWED_CORS_ORIGINS.has(origin)) {
      return callback(null, true);
    }

    return callback(null, false);
  },
  methods: ["GET", "POST", "OPTIONS"],
  allowedHeaders: ["Content-Type", "X-Admin-Secret", "x-admin-secret"]
}));

app.use(express.json({ limit: "64kb" }));

function getClientIp(req) {
  return req.ip || req.socket?.remoteAddress || "unknown";
}

function createRateLimiter({ name, max, windowMs = RATE_LIMIT_WINDOW_MS }) {
  const hits = new Map();

  return function rateLimit(req, res, next) {
    const now = Date.now();
    const key = `${name}:${getClientIp(req)}`;
    const current = hits.get(key);

    if (!current || now > current.resetAt) {
      hits.set(key, { count: 1, resetAt: now + windowMs });
      return next();
    }

    current.count += 1;

    if (current.count > max) {
      const retryAfterSeconds = Math.max(1, Math.ceil((current.resetAt - now) / 1000));
      res.set("Retry-After", String(retryAfterSeconds));
      return res.status(429).json({
        error: "요청이 너무 많습니다. 잠시 후 다시 시도해 주세요."
      });
    }

    if (hits.size > 10_000) {
      for (const [storedKey, value] of hits) {
        if (now > value.resetAt) hits.delete(storedKey);
      }
    }

    return next();
  };
}

const generalRateLimiter = createRateLimiter({
  name: "general",
  max: RATE_LIMIT_GENERAL_MAX
});

const heavyRateLimiter = createRateLimiter({
  name: "heavy",
  max: RATE_LIMIT_HEAVY_MAX
});

const assistRateLimiter = createRateLimiter({
  name: "assist",
  max: RATE_LIMIT_ASSIST_MAX
});

const adminRateLimiter = createRateLimiter({
  name: "admin",
  max: RATE_LIMIT_ADMIN_MAX
});

app.use(["/api/books", "/api/libraries", "/api/library-search"], generalRateLimiter);
app.use(["/api/book-recommendations", "/api/popular-books"], heavyRateLimiter);
app.use(["/api/assist", "/api/query-understanding"], assistRateLimiter);
app.use("/api/admin", adminRateLimiter);

function sanitizeQuery(value, maxLength = 200) {
  if (typeof value !== "string") return "";
  return value.trim().slice(0, maxLength);
}

function sanitizeIsbn(value) {
  if (typeof value !== "string") return "";
  return value.replace(/[^0-9Xx]/g, "").slice(0, 20);
}

function sanitizeRegionCode(value) {
  const region = String(value || "").trim();
  if (!region) return "";
  return VALID_REGION_CODES.has(region) ? region : "";
}

function forceArray(value) {
  if (!value) return [];
  return Array.isArray(value) ? value : [value];
}

function maskAuthKeyInUrl(url) {
  return String(url || "").replace(/(authKey=)([^&]+)/, "$1***");
}

function maskNationalLibraryKeyInUrl(url) {
  return String(url || "").replace(/([?&]key=)([^&]+)/, "$1***");
}

function mapData4LibraryErrorMessage(message = "") {
  const text = String(message || "").trim();

  if (
    text.includes("1일 500건 이상 요청 시 IP 등록이 필요합니다") ||
    text.includes("등록 된 IP를 확인하시기 바랍니다")
  ) {
    return "현재 도서관 API 사용 제한으로 검색이 일시적으로 불가합니다.";
  }

  if (text.includes("인증키") || text.toLowerCase().includes("auth")) {
    return "도서관 API 인증 설정에 문제가 있습니다.";
  }

  return text || "현재 도서관 API 사용 제한으로 검색이 일시적으로 불가합니다.";
}

async function fetchWithTimeout(url, options = {}, timeoutMs = EXTERNAL_FETCH_TIMEOUT_MS) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    return await fetch(url, {
      ...options,
      signal: controller.signal
    });
  } finally {
    clearTimeout(timeoutId);
  }
}

async function fetchJson(url, options = {}) {
  const response = await fetchWithTimeout(url, options);
  if (!response.ok) {
    throw new Error(`외부 API 호출 실패: ${response.status}`);
  }
  return response.json();
}

async function fetchXml(url) {
  if (isData4LibraryCoolingDown()) {
    throw new Error(`정보나루 API 오류: ${getData4LibraryCooldownMessage()}`);
  }

  const response = await fetchWithTimeout(url);
  const xml = await response.text();

  console.log("[LIB API URL]", maskAuthKeyInUrl(url));
  console.log("[LIB API STATUS]", response.status);
  console.log("[LIB API RAW]", xml.slice(0, 1200));

  if (!response.ok) {
    throw new Error(`외부 API 호출 실패: ${response.status}`);
  }

  const parsed = await parseStringPromise(xml, {
    explicitArray: false,
    trim: true
  });

  const apiError = parsed?.response?.error;
  if (apiError) {
    console.log("[LIB API ERROR]", apiError);

    if (shouldStartData4LibraryCooldown(apiError)) {
      activateData4LibraryCooldown(apiError);
    }

    throw new Error(`정보나루 API 오류: ${apiError}`);
  }

  console.log("[LIB API PARSED]", JSON.stringify(parsed)?.slice(0, 1200));
  return parsed;
}

async function fetchXmlLoose(url, logPrefix = "XML API") {
  const response = await fetchWithTimeout(url);
  const xml = await response.text();

  console.log(`========== ${logPrefix} ==========`);

  if (url.includes("nl.go.kr")) {
    console.log("[API URL]", maskNationalLibraryKeyInUrl(url));
  } else {
    console.log("[API URL]", maskAuthKeyInUrl(url));
  }

  console.log("[API STATUS]", response.status);
  console.log("[API RAW]", xml.slice(0, 1200));
  console.log("=============================");

  if (!response.ok) {
    throw new Error(`외부 API 호출 실패: ${response.status}`);
  }

  const parsed = await parseStringPromise(xml, {
    explicitArray: false,
    trim: true,
    mergeAttrs: true
  });

  return parsed;
}

function stripHtml(text = "") {
  return String(text)
    .replace(/<[^>]*>/g, " ")
    .replace(/&quot;/g, '"')
    .replace(/&amp;/g, "&")
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/\s+/g, " ")
    .trim();
}

function tryParseJsonObject(text = "") {
  const raw = String(text || "").trim();
  if (!raw) return null;

  try {
    return JSON.parse(raw);
  } catch {}

  const match = raw.match(/\{[\s\S]*\}/);
  if (!match) return null;

  try {
    return JSON.parse(match[0]);
  } catch {
    return null;
  }
}

function formatPubDate(pubdate = "") {
  const raw = String(pubdate || "").trim();
  if (/^\d{8}$/.test(raw)) {
    return `${raw.slice(0, 4)}-${raw.slice(4, 6)}-${raw.slice(6, 8)}`;
  }
  if (/^\d{4}$/.test(raw)) {
    return raw;
  }
  return raw;
}

function normalizeSearchText(text) {
  return String(text || "")
    .toLowerCase()
    .replace(/\s+/g, "")
    .replace(/[^\p{L}\p{N}]/gu, "");
}

const KOREAN_REQUEST_TAIL_PATTERN = /(?:찾아\s*(?:줘요|줘|주세요|줄래요?|주실래요?|줄\s*수\s*있(?:어|나요|니|을까)|봐줘요?|봐요?|봐|주라)?|알려\s*(?:줘요|줘|주세요|줄래요?|주실래요?|줄\s*수\s*있(?:어|나요|니|을까)|주라)?|보여\s*(?:줘요|줘|주세요|줄래요?|주실래요?|줄\s*수\s*있(?:어|나요|니|을까)|주라)?|검색\s*(?:해\s*)?(?:줘요|줘|주세요|줄래요?|주실래요?|줄\s*수\s*있(?:어|나요|니|을까)|봐줘요?|봐요?|봐|주라)?|추천\s*(?:해\s*)?(?:줘요|줘|주세요|줄래요?|주실래요?|줄\s*수\s*있(?:어|나요|니|을까)|주라)?)\s*$/u;
const NORMALIZED_KOREAN_REQUEST_TAIL_PATTERN = /(?:찾아(?:줘요|줘|주세요|줄래요|줄래|주실래요|주실래|줄수있어|줄수있나요|줄수있니|줄수있을까|봐줘요|봐줘|봐요|봐|주라)?|알려(?:줘요|줘|주세요|줄래요|줄래|주실래요|주실래|줄수있어|줄수있나요|줄수있니|줄수있을까|주라)?|보여(?:줘요|줘|주세요|줄래요|줄래|주실래요|주실래|줄수있어|줄수있나요|줄수있니|줄수있을까|주라)?|검색(?:해)?(?:줘요|줘|주세요|줄래요|줄래|주실래요|주실래|줄수있어|줄수있나요|줄수있니|줄수있을까|봐줘요|봐줘|봐요|봐|주라)?|추천(?:해)?(?:줘요|줘|주세요|줄래요|줄래|주실래요|주실래|줄수있어|줄수있나요|줄수있니|줄수있을까|주라)?)$/u;
const KOREAN_BARE_WHERE_TAIL_PATTERN = /(?:^|[\s,])어디\s*(?:에서|서|에)?\s*[?？!！.。]*$/u;

function stripKoreanRequestTail(text = "") {
  let cleaned = String(text || "").trim();

  for (let i = 0; i < 4; i += 1) {
    const next = cleaned
      .replace(/[?？!！.。]+\s*$/u, "")
      .replace(KOREAN_REQUEST_TAIL_PATTERN, "")
      .replace(/\s+/g, " ")
      .trim();
    if (next === cleaned) break;
    cleaned = next;
  }

  return cleaned;
}

function hasBookAvailabilityActionPhrase(text = "") {
  const value = String(text || "").trim();
  if (!value) return false;
  return /(?:어느|어떤|무슨|어디)\s*도서관(?:에서|에)?|(?:있는|있을)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))|(?:소장한?|소장된|소장\s*중인|소장|보유한?|보유\s*중인|보유|구비(?:된|한)?|비치(?:된|한)?)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?|(?:대출|대여)\s*(?:가능(?:한)?|할\s*수\s*있는|되는|된|처)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?|(?:대출처|대여처|소장처|보유처)|(?:빌릴|빌리는|빌려\s*주는|빌려\s*볼\s*수\s*있는)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?|(?:찾을|구할|볼|읽을)\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))|어디(?:에서|서)?\s*(?:구해|구하|대여해|대출해|빌려|빌릴)|(?:구해|구하|대여해|대출해|빌려)\s*(?:줘|주세요|주라)?\s*$/u.test(value);
}

function hasExplicitAvailabilityActionTail(message = "") {
  const text = String(message || "").trim();
  if (!text) return false;
  return /(?:소장|보유|대출|대여|구비|비치|대출처|대여처|소장처|보유처|빌릴|빌리는|빌려|구할|찾을\s*수|볼\s*수|읽을\s*수|어느\s*도서관|어떤\s*도서관|무슨\s*도서관|있는\s*(?:도서관|곳|데)|도서관(?:에서|에)?\s*있|어디(?:에서|서)\s*(?:볼|읽|찾|구|빌|대출|대여))/u.test(text);
}

function stripBookAvailabilityActionTail(text = "") {
  let cleaned = String(text || "").replace(/\s+/g, " ").trim();
  if (!cleaned) return "";

  const tailPatterns = [
    /\s*(?:어느|어떤|무슨|어디)\s*도서관(?:에서|에)?\s*$/u,
    /\s*(?:어느|어떤|무슨|어디)\s*$/u,
    /\s*(?:소장\s*여부|대출\s*여부)\s*$/u,
    /\s*(?:소장한?|소장된|소장\s*중인|보유한?|보유\s*중인|구비(?:된|한)?|비치(?:된|한)?)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?\s*$/u,
    /\s*(?:소장|보유|구비|비치)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?\s*$/u,
    /\s*(?:대출|대여)\s*(?:가능(?:한)?|할\s*수\s*있는|할\s*수\s*있(?:어|어요|나요|니|습니까|을까|을까요|는지|나)?|되는|된|처)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?\s*$/u,
    /\s*(?:대출처|대여처|소장처|보유처)\s*$/u,
    /\s*(?:빌릴|빌리는|빌려\s*주는|빌려\s*볼\s*수\s*있는|구할\s*수\s*있는|찾을\s*수\s*있는|볼\s*수\s*있는|읽을\s*수\s*있는)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?\s*$/u,
    /\s*(?:빌려|빌려\s*볼\s*수|구할\s*수|찾을\s*수|볼\s*수|읽을\s*수|대여할\s*수|대출\s*할\s*수)\s*$/u,
    /\s*(?:어디(?:에서|서)?\s*)?(?:구해|대여해|대출해|빌려)\s*$/u,
    /\s*(?:대여|대출)\s*(?:찾(?:아|기)?|검색)?\s*$/u,
    /\s*(?:있(?:나|냐|나요|습니까|니|을까|을까요|는지|음)|있(?:어|어요)|없(?:나|나요|습니까|니|을까|을까요|는지|어|어요))\s*$/u
  ];

  for (let i = 0; i < 5; i += 1) {
    const before = cleaned;
    for (const pattern of tailPatterns) {
      cleaned = cleaned.replace(pattern, "").trim();
    }
    if (before === cleaned) break;
  }

  return cleaned;
}

function stripTrailingKoreanParticles(text = "") {
  let cleaned = String(text || "")
    .replace(/\s+/g, " ")
    .trim();

  if (!cleaned) return "";

  // 띄어 쓴 조사는 제목 일부일 가능성이 낮으므로 제거한다. 예: "데미안 은".
  cleaned = cleaned.replace(/\s+(?:은|는|을|를)$/u, "").trim();
  if (!cleaned) return "";

  const tokens = cleaned.split(/\s+/u).filter(Boolean);
  const lastToken = tokens[tokens.length - 1] || cleaned;
  const tokenLength = Array.from(lastToken).length;
  const protectedEnding = /(?:작가|화가|소설가|문학가|음악가|예술가|철학가|번역가|평론가|비평가|만화가|사진가|연출가|극작가|연구가|교육가|사상가|는가|은가|인가|던가|런가|것인가|할까|고양이|듀이|떡볶이)$/u;
  if (protectedEnding.test(cleaned)) return cleaned;

  // 제목 훼손을 막기 위해 과/도/만/의/와/을/를은 붙어 있으면 기본적으로 보존한다.
  // 은/는은 위치 질문에서 주제 표지일 가능성이 매우 높아 제거한다.
  cleaned = cleaned.replace(/(?:은|는)$/u, "").trim();
  if (!cleaned || protectedEnding.test(cleaned)) return cleaned;

  // 이/가는 짧은 자연어 위치 질문에서 조사일 수 있지만 제목 끝 글자일 수도 있다.
  // 여기서는 후보 생성을 위한 보수적 제거만 수행하고, 원본 후보는 buildBookTitleCandidates가 보존한다.
  const last = cleaned.split(/\s+/u).filter(Boolean).pop() || "";
  if (/(?:이|가)$/u.test(last) && Array.from(last).length >= 2 && !protectedEnding.test(cleaned)) {
    cleaned = cleaned.replace(/(?:이|가)$/u, "").trim();
  }

  return cleaned;
}

function stripAvailabilityObjectParticle(text = "") {
  const cleaned = String(text || "").replace(/\s+/g, " ").trim();
  if (!cleaned) return "";
  // 명확한 소장/보유/대여 action 앞의 짧은 단일 제목 후보에서는 목적격 조사를 제거한다.
  // 예: "데미안을 소장한 도서관" -> "데미안". 다어절 제목의 "... 것을" 같은 제목 일부는 보존한다.
  if (!/\s/u.test(cleaned) && Array.from(cleaned).length >= 3) {
    return cleaned.replace(/(?:을|를)$/u, "").trim() || cleaned;
  }
  return cleaned;
}

function isPredicateOnlyAvailabilityTitle(text = "") {
  const normalized = normalizeSearchText(text);
  return /^(?:있어|있어요|있나|있냐|있음|있나요|있습니까|있을까|있을까요|없는지|없나요|없어|없어요)$/.test(normalized);
}

function isBookLibraryExistenceAmbiguityCandidate(message = "", selectedRegion = "") {
  const text = stripKoreanRequestTail(String(message || "").trim().toLowerCase()).replace(/[?？!！.。]+$/u, "").trim();
  if (!text) return false;
  // "데미안 도서관 있어?"는 "데미안" 책의 소장 도서관인지, "데미안 도서관" 명칭인지 애매하다.
  // 단, "종로 산책 도서관에 있어?"처럼 조사 '에/에서'가 있으면 책 소장 질문으로 처리한다.
  const match = text.match(/^(.{2,})\s+도서관\s*있(?:어|어요|나요|나|냐|니|습니까|을까|을까요|는지|음)?$/u);
  if (!match?.[1]) return false;
  const prefix = stripTrailingKoreanParticles(match[1] || "");
  if (!prefix || prefix.length < 2) return false;
  if (getBroadRegionHintForUnderstanding(prefix) || getDetailedRegionAliasHint(prefix, selectedRegion)) return false;
  if (looksLikeTrustedSpecificLibraryNameForUnderstanding(`${prefix} 도서관`)) return false;
  return true;
}



function isKnownLocalPlaceLibraryListingQuery(message = "") {
  const text = String(message || "").trim().toLowerCase().replace(/[?？!！.。]+$/u, "");
  if (!text || !/(?:도서관|작은\s*도서관|문고)/u.test(text)) return false;
  const names = [];
  try {
    (UNDERSTANDING_PLACE_ALIAS_HINTS || []).forEach((item) => (item.names || []).forEach((name) => names.push(String(name || ""))));
  } catch (_) {}
  try {
    (DETAILED_REGION_MAP || []).forEach((item) => (item.names || []).forEach((name) => names.push(String(name || ""))));
  } catch (_) {}
  const uniqueNames = [...new Set(names.map((name) => name.replace(/\s+/g, " ").trim()).filter((name) => name.length >= 2))]
    .sort((a, b) => b.length - a.length);
  return uniqueNames.some((name) => {
    const compactName = name.replace(/\s+/g, "");
    const escaped = escapeRegExp(name).replace(/\\\s\+/g, "\\s+");
    const compactEscaped = escapeRegExp(compactName);
    return new RegExp(`^(?:${escaped}|${compactEscaped})(?:에|에서|의)?\\s*(?:있는|소재(?:한)?|위치(?:한)?|가까운|근처|주변|인근)?\\s*(?:도서관|작은\\s*도서관|문고)(?:\\s*(?:알려|찾|검색|추천|어디|목록|있))?`, "u").test(text);
  });
}

function isLibraryLocationListingQueryForUnderstanding(message = "") {
  const text = stripKoreanRequestTail(String(message || "").trim().toLowerCase()).replace(/[?？!！.。]+$/u, "").trim();
  if (!text) return false;
  if (isKnownLocalPlaceLibraryListingQuery(text)) return true;
  const match = text.match(/^(.{1,60}?)(?:\s*(?:에\s*있는|에서|에는|에서는|에))?\s+도서관$/u);
  if (!match?.[1]) return false;
  const prefix = normalizeUnderstandingAreaToken(match[1]);
  if (!prefix) return false;
  if (getBroadRegionHintForUnderstanding(prefix) || getDetailedRegionAliasHint(prefix) || getLooseAreaAliasHint(prefix)) return true;
  if (new RegExp(`(?:${UNDERSTANDING_SIDO_PATTERN})`, "u").test(prefix)) return true;
  if (new RegExp(`${UNDERSTANDING_ADMIN_UNIT_PATTERN}`, "u").test(prefix)) return true;
  if (/(?:근처|주변|인근|부근|쪽|학교|초등학교|중학교|고등학교|대학교|대학|병원|공원|시장|구청|시청|주민센터|터미널|역)$/u.test(prefix)) return true;
  return false;
}

function stripAvailabilitySubjectMarker(text = "") {
  let cleaned = String(text || "").replace(/\s+/g, " ").trim();
  if (!cleaned) return "";
  const protectedEnding = /(?:작가|화가|소설가|문학가|음악가|예술가|철학가|번역가|평론가|비평가|만화가|사진가|연출가|극작가|연구가|교육가|사상가|는가|은가|인가|던가|런가|것인가|할까|고양이|듀이|떡볶이)$/u;
  cleaned = cleaned.replace(/\s+(?:은|는|이|가|을|를)$/u, "").trim();
  if (!cleaned || protectedEnding.test(cleaned)) return cleaned;
  const tokens = cleaned.split(/\s+/u).filter(Boolean);
  const lastToken = tokens[tokens.length - 1] || cleaned;
  const tokenLength = Array.from(lastToken).length;
  if (/(?:을|를)$/u.test(lastToken) && tokenLength >= 2) return cleaned.replace(/(?:을|를)$/u, "").trim();
  if (/(?:가)$/u.test(lastToken) && tokenLength >= 2) return cleaned.replace(/가$/u, "").trim();
  // '모순이 어디'처럼 받침 있는 명사 + 주격 조사일 가능성이 큰 경우만 제거한다.
  // '듀이', '고양이'처럼 제목 자체가 이로 끝나는 경우는 보호한다.
  if (/(?:이)$/u.test(lastToken) && tokenLength >= 3 && !/(?:고양이|듀이|떡볶이)$/u.test(lastToken)) return cleaned.replace(/이$/u, "").trim();
  return cleaned;
}

function stripBareWhereSubjectMarker(text = "") {
  let cleaned = String(text || "").replace(/\s+/g, " ").trim();
  if (!cleaned) return "";
  const protectedEnding = /(?:작가|화가|소설가|문학가|음악가|예술가|철학가|번역가|평론가|비평가|만화가|사진가|연출가|극작가|연구가|교육가|사상가|는가|은가|인가|던가|런가|것인가|할까|고양이|듀이|떡볶이)$/u;
  cleaned = cleaned.replace(/\s+(?:은|는|이|가)$/u, "").trim();
  if (!cleaned || protectedEnding.test(cleaned)) return cleaned;
  const lastToken = cleaned.split(/\s+/u).filter(Boolean).pop() || cleaned;
  const tokenLength = Array.from(lastToken).length;
  if (/가$/u.test(lastToken) && tokenLength >= 2) return cleaned.replace(/가$/u, "").trim();
  if (/이$/u.test(lastToken) && tokenLength >= 3 && !/(?:고양이|듀이|떡볶이)$/u.test(lastToken)) return cleaned.replace(/이$/u, "").trim();
  // bare where에서는 을/를을 보존한다. 예: “나는 소망한다 내게 금지된 것을 어디”.
  return cleaned;
}

function normalizeAvailabilityBookTitleFinal(text = "", message = "") {
  let cleaned = normalizeAiProvidedBookTitleCandidate(String(text || ""));
  cleaned = stripBookAvailabilityActionTail(cleaned) || cleaned;
  cleaned = stripWhichLibraryQualifierFromTitle(cleaned);
  cleaned = stripGenericLibraryNounSuffixFromTitle(cleaned);
  if (hasBookAvailabilityActionPhrase(message) || /(?:어디|어딘|어딨|있(?:어|나|냐|나요|음)?)/u.test(String(message || ""))) {
    cleaned = hasExplicitAvailabilityActionTail(message)
      ? stripAvailabilitySubjectMarker(cleaned)
      : stripBareWhereSubjectMarker(cleaned);
  }
  return cleaned.replace(/\s+/g, " ").trim();
}

function isWeakPredicateOnlyAvailabilityTitle(title = "") {
  const normalized = normalizeSearchText(title || "");
  return /^(?:있어|있음|있나|있냐|있나요|있습니까|있을까|있니|있어요|없어|없음|없나)$/.test(normalized);
}

function getBookTitleLibraryPredicateAmbiguityPlan(message = "", selectedRegion = "") {
  const text = stripKoreanRequestTail(String(message || "").trim().toLowerCase()).replace(/[?？!！.。]+$/u, "").trim();
  if (!text) return null;

  // 명확한 도서관 탐색/추천은 “책 제목 + 도서관” ambiguity가 가로채면 안 된다.
  // 예: “아이랑 가기 좋은 서울 도서관 추천해줘”, “서구 도서관”.
  if (isLibraryRecommendationRequest(text) || isClearLocationPhraseLibraryQueryForUnderstanding(text)) return null;
  const clearLibraryPlan = getClearLibraryListingPlanForUnderstanding(text, selectedRegion);
  if (clearLibraryPlan) return null;

  const match = text.match(/^(.{2,80}?)\s+도서관\s*(?:있(?:어|어요|나|냐|나요|습니까|니|을까|을까요|는지|음)?|없(?:어|어요|나|나요|습니까|니|을까|을까요|는지|음)?)\s*$/u);
  if (!match?.[1]) return null;
  const prefix = normalizeAvailabilityBookTitleFinal(match[1], text);
  if (!prefix || Array.from(prefix).length < 2) return null;
  const localRegionForPrefix = getAmbiguousLocalRegionMentionInText(prefix);
  if (localRegionForPrefix && /(?:^|\s)(?:중구|서구|동구|남구|북구)(?:\s*지역)?$/u.test(prefix)) {
    return buildAmbiguousLocalRegionLibrarySearchPlan(localRegionForPrefix, text, selectedRegion);
  }
  if (getBroadRegionHintForUnderstanding(prefix) || getDetailedRegionAliasHint(prefix, selectedRegion)) return null;
  if (isTrustedSpacedLibraryStemForUnderstanding(prefix) || isSafeSpacedLibraryNameForUnderstanding(`${prefix} 도서관`) || isKnownStandardLibraryNameForUnderstanding(`${prefix}도서관`)) return null;
  const context = stripLeadingContextFromAvailabilitySubject(prefix, selectedRegion);
  if (context?.regionHint && context.bookTitle && normalizeSearchText(context.bookTitle) !== normalizeSearchText(prefix)) {
    return {
      intent: "book_availability",
      normalizedQuery: context.bookTitle,
      bookTitle: context.bookTitle,
      bookTitleCandidates: buildBookTitleCandidates(context.bookTitle, prefix),
      libraryName: context.libraryName || "",
      regionHint: context.regionHint,
      region: context.region || "",
      confidence: 0.89,
      source: "rule",
      reason: "책 제목 뒤의 지역+도서관 일반명사를 분리한 소장 검색"
    };
  }
  return {
    intent: "ambiguous",
    normalizedQuery: prefix,
    bookTitle: prefix,
    bookTitleCandidates: buildBookTitleCandidates(prefix),
    confidence: 0.88,
    source: "rule",
    reason: "책 제목+도서관 일반명사인지 실제 도서관명인지 애매함",
    needsClarification: true,
    alternatives: [
      { label: `『${prefix}』 소장 도서관 찾기`, intent: "book_availability", normalizedQuery: prefix, bookTitle: prefix, bookTitleCandidates: buildBookTitleCandidates(prefix) },
      { label: `“${prefix} 도서관” 도서관 검색`, intent: "library_search", normalizedQuery: `${prefix} 도서관` }
    ]
  };
}


function getBareBookTrailingLibraryAmbiguityPlan(message = "", selectedRegion = "") {
  const text = stripKoreanRequestTail(String(message || "").trim().toLowerCase()).replace(/[?？!！.。]+$/u, "").replace(/\s+/g, " ").trim();
  if (!text) return null;
  if (hasBookAvailabilityActionPhrase(text) || isSpecificLibraryInfoRequest(text) || isLikelyFaqIntent(text)) return null;

  const candidates = [];
  const compact = text.match(/^(.+?)\s+(.{2,60}?(?:도서관|작은\s*도서관|문고))$/u);
  if (compact?.[1] && compact?.[2]) candidates.push({ title: compact[1], libraryName: compact[2] });
  const spaced = text.match(/^(.+?)\s+([가-힣A-Za-z0-9]{2,30})\s+도서관$/u);
  if (spaced?.[1] && spaced?.[2]) candidates.push({ title: spaced[1], libraryName: `${spaced[2]} 도서관` });

  for (const item of candidates) {
    const title = normalizeAvailabilityBookTitleFinal(stripAvailabilityObjectParticle(item.title), text);
    const libraryName = String(item.libraryName || "").replace(/\s+/g, " ").trim();
    if (!title || Array.from(title).length < 2 || !libraryName) continue;
    if (!looksLikeSpecificLibraryNameCandidateForAvailability(libraryName, selectedRegion)
      && !looksLikeTrustedSpecificLibraryNameForUnderstanding(libraryName)
      && !isSafeSpacedLibraryNameForUnderstanding(libraryName)
      && !isKnownStandardLibraryNameForUnderstanding(libraryName)) continue;
    const first = libraryName.replace(/(?:도서관|작은\s*도서관|문고)$/u, "").trim().split(/\s+/u)[0] || "";
    const hint = getLooseAreaAliasHint(first, selectedRegion) || getDetailedRegionAliasHint(first, selectedRegion);
    return {
      intent: "ambiguous",
      normalizedQuery: title,
      bookTitle: title,
      bookTitleCandidates: buildBookTitleCandidates(title),
      libraryName,
      regionHint: hint?.regionHint || "",
      region: hint?.region || "",
      confidence: 0.86,
      source: "rule",
      needsClarification: true,
      clarificationMessage: `“${libraryName}”에서 『${title}』을 찾는 건가요, 아니면 그대로 책/도서관을 검색할까요?`,
      reason: "책 제목 뒤의 도서관명이 소장 확인인지 단순 검색어인지 애매함",
      alternatives: [
        { label: `“${libraryName}”에서 『${title}』 찾기`, intent: "book_availability", normalizedQuery: title, bookTitle: title, libraryName, regionHint: hint?.regionHint || "", region: hint?.region || "" },
        { label: `“${libraryName}” 도서관 검색`, intent: "library_search", normalizedQuery: libraryName, libraryName, regionHint: hint?.regionHint || "", region: hint?.region || "" },
        { label: `“${title} ${libraryName}” 그대로 책 검색`, intent: "book_search", normalizedQuery: `${title} ${libraryName}`, bookTitle: `${title} ${libraryName}` }
      ]
    };
  }
  return null;
}

function getBareSpecificLibraryBookAmbiguityPlan(message = "") {
  const text = stripKoreanRequestTail(String(message || "").trim().toLowerCase()).replace(/[?？!！.。]+$/u, "").trim();
  if (!text) return null;
  if (hasBookAvailabilityActionPhrase(text) || isSpecificLibraryInfoRequest(text) || isLikelyFaqIntent(text)) return null;

  const patterns = [
    /^(.{2,40}?(?:도서관|작은\s*도서관|문고))\s+(.{1,60})$/u,
    /^(.{2,30})\s+도서관\s+(.{1,60})$/u
  ];

  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (!match?.[1] || !match?.[2]) continue;
    const libraryName = stripTrailingKoreanParticles(match[1]).replace(/\s+/g, " ").trim();
    const compactLibraryName = libraryName.replace(/\s+/g, "");
    if (!(looksLikeTrustedSpecificLibraryNameForUnderstanding(libraryName) || isSafeSpacedLibraryNameForUnderstanding(libraryName) || looksLikeTrustedSpecificLibraryNameForUnderstanding(compactLibraryName))) continue;
    const title = normalizeAvailabilityBookTitleFinal(match[2], text);
    if (!title || Array.from(title).length < 2) continue;
    return {
      intent: "ambiguous",
      normalizedQuery: title,
      bookTitle: title,
      bookTitleCandidates: buildBookTitleCandidates(title),
      libraryName,
      confidence: 0.84,
      source: "rule",
      reason: "도서관명과 책 제목만 있어 소장 여부 질문인지 일반 제목 검색인지 확인 필요",
      needsClarification: true,
      alternatives: [
        { label: `“${libraryName}”에서 『${title}』 찾기`, intent: "book_availability", normalizedQuery: title, libraryName },
        { label: `“${libraryName} ${title}” 그대로 책 검색`, intent: "book_search", normalizedQuery: `${libraryName} ${title}` }
      ]
    };
  }

  return null;
}


function isUnsupportedDigitalTitleLike(message = "") {
  let text = String(message || "").trim().toLowerCase().replace(/[?？!！.。]+$/u, "");
  if (!text) return false;

  // “전자책의 미래는 어디”, “전자도서관의 미래는 어디”처럼 뒤에 위치 질문/조사가 붙은 제목형 문장은
  // 자료형 문의가 아니라 책 제목 검색으로 보존해야 한다.
  const titleProbe = text.replace(/\s*(?:은|는|이|가)?\s*(?:어디(?:에서|서|에)?|어딘(?:데|지|가)?|어딨(?:어|나요)?|있(?:어|나요|나|음)?)\s*$/u, "").trim() || text;
  const digitalPattern = "(?:전자\\s*책|전자도서|전자\\s*도서|ebook|e\\s*[-‐‑‒–—－]?\\s*book|e\\s*[-‐‑‒–—－]?\\s*북|이북|오디오\\s*북|오디오북)";
  const titleNouns = "(?:미래|역사|시대|사회|문화|산업|혁명|입문|개론|읽기|사용자|시장|저작권|플랫폼|출판|독서|교육|만들기|제작|제작법|활용|활용법|가이드|안내서|교과서|강의|수업|연구|기술|전략|트렌드|디자인|기획|비즈니스|사람들?)";
  if (new RegExp(`^전자\\s*도서관(?:의|과|와)?\\s*${titleNouns}(?:\\s|$)`, "iu").test(titleProbe)) return true;
  if (new RegExp(`^(?:${digitalPattern})(?:의|과|와)?\\s*${titleNouns}(?:\\s|$)`, "iu").test(titleProbe)) return true;
  if (new RegExp(`^(?:${digitalPattern})(?:을|를)?\\s+(?:만드는|만든|듣는|읽는|보는|활용하는|연구하는)\\s+.{2,}$`, "iu").test(titleProbe)) return true;
  if (new RegExp(`^(?:${digitalPattern})(?:으로|로)\\s*(?:듣는|읽는|보는|배우는)\\s+.{2,}$`, "iu").test(titleProbe)) return true;
  return false;
}

function getUnsupportedDigitalBookPlan(message = "") {
  const text = String(message || "").trim();
  if (!text) return null;
  const digitalPattern = "(?:전자\\s*책|전자도서|전자\\s*도서|ebook|e\\s*[-‐‑‒–—－]?\\s*book|e\\s*[-‐‑‒–—－]?\\s*북|이북|오디오\\s*북|오디오북)";
  const digitalRe = new RegExp(digitalPattern, "iu");
  if (!digitalRe.test(text)) return null;

  // “전자책의 미래”, “오디오북 만들기”처럼 단어가 책 제목 일부인 경우는 FAQ로 보내지 않는다.
  if (isUnsupportedDigitalTitleLike(text)) return null;

  const actionCue = "(?:있|있어|있나요|볼\\s*수|읽을\\s*수|대출|대여|빌릴|구할|소장|보유|지원|이용|방법|법|서비스|앱|어플|다운로드|도서관)";
  const guideCue = "(?:이용|방법|법|대출|대여|빌리|보는|읽는|지원|서비스|신청|예약|앱|어플|다운로드|로그인|회원|가능|되나요|돼|해|어떻게)";
  const prefixCondition = new RegExp(`^(?:${digitalPattern})(?:으로|로)?\\s+.{1,80}?${actionCue}`, "iu");
  const suffixCondition = new RegExp(`^.{1,80}?\\s+(?:${digitalPattern})(?:으로|로)?\\s*${actionCue}`, "iu");
  const directGuide = new RegExp(`^(?:도서관\\s*)?(?:${digitalPattern})(?:\\s*${guideCue}|(?:으로|로)?\\s*${guideCue})`, "iu");
  const libraryGuide = new RegExp(`^도서관\\s+.*(?:${digitalPattern}|전자도서|오디오북|e\\s*북|이북)`, "iu");

  if (!(prefixCondition.test(text) || suffixCondition.test(text) || directGuide.test(text) || libraryGuide.test(text))) return null;
  return {
    intent: "faq",
    normalizedQuery: text,
    confidence: 0.9,
    source: "rule",
    reason: "현재 검색 API에서 전자책/오디오북 소장 검색은 안정적으로 지원하지 않아 안내로 라우팅"
  };
}


function getLoanAvailabilityPlan(message = "", selectedRegion = "") {
  const raw = String(message || "").trim();
  const text = stripKoreanRequestTail(raw.toLowerCase()).replace(/[?？!！.。]+$/u, "").replace(/\s+/g, " ").trim();
  if (!text) return null;

  const loanSignal = /대출\s*(?:가능(?:해|한가요|한|할까요|한지|할지|하나요|합니까)?|할\s*수\s*(?:있는|있(?:어|어요|나요|니|습니까|을까|을까요|는지|나)?)|되(?:는|나요|니|어|나|나요)?|돼(?:요|나요)?|됨|중|처)|대출가능/u;
  if (!loanSignal.test(text)) return null;
  if (/(?:대출\s*(?:기간|기한|권수|규정|방법|연장|예약)|몇\s*권|몇권|몇\s*일|몇일)/u.test(text)) return null;
  if (/^도서관(?:에서|에)?\s*대출\s*가능(?:한|해|한가요|한지|할지|하나요|합니까)?\s*(?:책|도서(?!관))?$/u.test(text)) return null;

  const actionTail = "대출\\s*(?:가능(?:해|한가요|한|할까요|한지|할지|하나요|합니까)?|할\\s*수\\s*(?:있는|있(?:어|어요|나요|니|습니까|을까|을까요|는지|나)?)|되(?:는|나요|니|어|나|나요)?|돼(?:요|나요)?|됨|중|처)|대출가능";
  const placeTail = "(?:\\s*(?:도서관|곳|데(?=$|\\s|[?？!！.。])))?";

  const makePlan = (title, libraryName = "", confidence = 0.93, extra = {}) => {
    let cleanedTitle = normalizeAvailabilityBookTitleFinal(stripAvailabilityObjectParticle(title), text);
    cleanedTitle = normalizeAvailabilityBookTitleFinal(stripGenericLibraryNounPrefixFromTitle(cleanedTitle) || cleanedTitle, text);
    let regionHint = extra.regionHint || "";
    let region = extra.region || "";
    let finalLibraryName = libraryName || extra.libraryName || "";

    // “서울 중구 도서관 데미안 대출 가능”, “서울 중구에 있는 도서관에서 데미안 대출 가능”처럼
    // 대출 가능 판단 뒤에도 지역/도서관 일반명사가 제목 앞에 남을 수 있으므로 한 번 더 분리한다.
    const context = stripLeadingContextFromAvailabilitySubject(cleanedTitle, selectedRegion);
    if (context?.bookTitle && context.bookTitle !== cleanedTitle) {
      cleanedTitle = normalizeAvailabilityBookTitleFinal(stripGenericLibraryNounPrefixFromTitle(context.bookTitle), text);
      finalLibraryName = finalLibraryName || context.libraryName || "";
      regionHint = regionHint || context.regionHint || "";
      region = region || context.region || "";
    }

    if (!cleanedTitle || isLibraryOnlyAvailabilitySubject(cleanedTitle, selectedRegion)) return null;
    if (Array.from(cleanedTitle).length < 1) return null;
    return {
      intent: "book_availability",
      normalizedQuery: cleanedTitle,
      bookTitle: cleanedTitle,
      bookTitleCandidates: buildBookTitleCandidates(cleanedTitle, title),
      libraryName: finalLibraryName || "",
      regionHint,
      region,
      needsRegionClarification: Boolean(extra.needsRegionClarification),
      confidence,
      source: "rule",
      preserveTitle: true,
      reason: finalLibraryName ? "특정 도서관의 책 대출 가능 여부를 묻는 표현" : "책의 대출 가능 여부를 묻는 표현"
    };
  };

  const makeRegionPlan = (title, detail = "", broad = "", confidence = 0.93) => {
    const broadCode = broad ? getRegionCodeFromText(broad, selectedRegion) : "";
    const hint = detail ? getDetailedRegionAliasHint(detail, broadCode || selectedRegion) : null;
    const regionHint = hint?.regionHint || detail || "";
    const region = sanitizeRegionCode(hint?.region || broadCode || getRegionCodeFromText(detail, selectedRegion) || "");
    const needsRegionClarification = Boolean(hint?.ambiguous && !selectedRegion && !broadCode);
    return makePlan(title, "", confidence, { regionHint, region, needsRegionClarification });
  };

  // 예: 서울 중구 도서관 데미안 대출 가능 / 서울 중구에 있는 도서관에서 데미안 대출 가능
  const regionLibraryFirst = text.match(new RegExp(`^(?:(${UNDERSTANDING_SIDO_PATTERN})\\s+)?([가-힣0-9]{1,12}(?:구|군|시|읍|면|동))(?:에|에서|에는|에서는)?(?:\\s*있는)?\\s*도서관(?:에서는|에서|에는|에)?\\s+(.+?)\\s*${actionTail}${placeTail}\\s*$`, "u"));
  if (regionLibraryFirst?.[2] && regionLibraryFirst?.[3]) {
    const plan = makeRegionPlan(regionLibraryFirst[3], regionLibraryFirst[2], regionLibraryFirst[1] || "", 0.94);
    if (plan) return plan;
  }

  // 예: 정독도서관데미안대출가능 / 마포중앙도서관데미안대출가능
  const compactLibraryFirst = !/\s/u.test(text)
    ? text.match(new RegExp(`^(.{2,50}?(?:도서관|문고))(.+?)${actionTail}$`, "u"))
    : null;
  if (compactLibraryFirst?.[1] && compactLibraryFirst?.[2]) {
    const libraryName = stripTrailingKoreanParticles(compactLibraryFirst[1]);
    const title = compactLibraryFirst[2];
    if (libraryName && title && Array.from(title).length >= 1) {
      const plan = makePlan(title, libraryName, 0.9);
      if (plan) return plan;
    }
  }

  // 예: 정독도서관 데미안 대출 가능 / 정독 도서관에서 데미안 대출 가능
  const libraryFirst = text.match(new RegExp(`^(.{2,50}?(?:도서관|작은\\s*도서관|문고))(?:에서는|에서|에는|에)?\\s+(.+?)\\s*${actionTail}${placeTail}\\s*$`, "u"));
  if (libraryFirst?.[1] && libraryFirst?.[2]) {
    const libraryName = stripTrailingKoreanParticles(libraryFirst[1]);
    if (looksLikeTrustedSpecificLibraryNameForUnderstanding(libraryName) || isSafeSpacedLibraryNameForUnderstanding(libraryName)) {
      const plan = makePlan(libraryFirst[2], libraryName, 0.94);
      if (plan) return plan;
    }
  }

  // 예: 데미안 정독 도서관 대출 가능 / 데미안은 정독 도서관에서 대출 가능
  const libraryAfter = text.match(new RegExp(`^(.+?)(?:은|는|이|가|을|를)?\\s+(.{2,40}?(?:도서관|작은\\s*도서관|문고))(?:에서는|에서|에는|에)?\\s*${actionTail}${placeTail}\\s*$`, "u"));
  if (libraryAfter?.[1] && libraryAfter?.[2]) {
    const libraryName = stripTrailingKoreanParticles(libraryAfter[2]);
    if (looksLikeTrustedSpecificLibraryNameForUnderstanding(libraryName) || isSafeSpacedLibraryNameForUnderstanding(libraryName)) {
      const plan = makePlan(libraryAfter[1], libraryName, 0.92);
      if (plan) return plan;
    }
  }

  // 예: 데미안 대출 가능 / 데미안 대출 가능한 도서관 / 데미안 대출돼?
  const general = text.match(new RegExp(`^(.+?)\\s*${actionTail}${placeTail}\\s*$`, "u"));
  if (general?.[1]) {
    const plan = makePlan(general[1], "", 0.93);
    if (plan) return plan;
  }

  return null;
}

function getLargePrintBookPlan(message = "") {
  const text = stripKoreanRequestTail(String(message || "").trim().toLowerCase()).replace(/[?？!！.。]+$/u, "").trim();
  if (!text || !/(?:큰\s*글자|큰글자|큰\s*활자)/u.test(text)) return null;
  if (!/(?:어디|어딘|어딨|있|볼\s*수|읽을\s*수|소장|보유|대출|대여|빌릴|구할|찾|도서관)/u.test(text)) return null;
  const conditionPattern = `(?:${LARGE_PRINT_BOOK_CONDITION_PATTERN})`;
  const cue = "(?:어디|어딘|어딨|있(?:어|어요|나|나요|니|냐|습니까|을까|을까요|는지)?|소장|보유|대출|대여|빌릴|구비|비치|볼\\s*수|읽을\\s*수)";
  let title = "";
  let match = text.match(new RegExp(`^${conditionPattern}(?:로|으로)?\\s+(.+?)\\s*${cue}.*$`, "u"));
  if (match?.[1]) title = normalizeAvailabilityBookTitleFinal(match[1], text);
  if (!title) {
    match = text.match(new RegExp(`^(.+?)\\s+${conditionPattern}(?:로|으로)?\\s*${cue}.*$`, "u"));
    if (match?.[1]) title = normalizeAvailabilityBookTitleFinal(match[1], text);
  }
  if (!title || Array.from(title).length < 2) return null;
  const primary = `큰글자 ${title}`.replace(/\s+/g, " ").trim();
  const alt = `${title} 큰글자`.replace(/\s+/g, " ").trim();
  return {
    intent: "book_availability",
    normalizedQuery: primary,
    bookTitle: primary,
    bookTitleCandidates: buildBookTitleCandidates(primary, alt, title),
    confidence: 0.88,
    source: "rule",
    reason: "큰글자 판본은 도서 검색어 후보로 검색",
    preserveTitle: true,
    filters: []
  };
}


function getBookLeadingRegionLibraryAvailabilityPlan(message = "", selectedRegion = "") {
  const text = stripKoreanRequestTail(String(message || "").trim().toLowerCase()).replace(/[?？!！.。]+$/u, "").trim();
  if (!text) return null;
  const predicate = "(?:있(?:어|어요|나|냐|나요|습니까|니|을까|을까요|는지|음)?|소장|보유|대출\\s*가능|대여\\s*가능|구비|비치)?";
  const broadDetailLibrary = new RegExp(`^(.+?)\\s+(${UNDERSTANDING_SIDO_PATTERN})\\s+([가-힣0-9]{1,12}(?:구|군|시|읍|면|동))\\s*도서관\\s*${predicate}$`, "u");
  let match = text.match(broadDetailLibrary);
  if (match?.[1] && match?.[2] && match?.[3]) {
    const title = normalizeAvailabilityBookTitleFinal(match[1], text);
    const broad = match[2];
    const detail = match[3];
    const broadCode = getRegionCodeFromText(broad, selectedRegion);
    if (title && (Array.from(title).length >= 2 || hasClearAvailabilityCueForShortTitle(text))) {
      return {
        bookTitle: title,
        normalizedQuery: title,
        libraryName: `${detail}도서관`,
        regionHint: detail,
        region: broadCode || getRegionCodeFromText(detail, selectedRegion) || "",
        confidence: 0.9
      };
    }
  }

  const detailLibrary = text.match(/^(.+?)\s+([가-힣0-9]{1,12}(?:구|군|시|읍|면|동))\s*도서관\s*(?:있(?:어|어요|나|냐|나요|습니까|니|을까|을까요|는지|음)?|소장|보유|대출\s*가능|대여\s*가능|구비|비치)?$/u);
  if (detailLibrary?.[1] && detailLibrary?.[2]) {
    const title = normalizeAvailabilityBookTitleFinal(detailLibrary[1], text);
    const detail = detailLibrary[2];
    if (title && (Array.from(title).length >= 2 || hasClearAvailabilityCueForShortTitle(text))) {
      return {
        bookTitle: title,
        normalizedQuery: title,
        libraryName: `${detail}도서관`,
        regionHint: detail,
        region: getRegionCodeFromText(detail, selectedRegion) || "",
        confidence: 0.88
      };
    }
  }
  return null;
}

function getBookLeadingSpecificLibraryAvailabilityPlan(message = "", selectedRegion = "") {
  const text = stripKoreanRequestTail(String(message || "").trim().toLowerCase()).replace(/[?？!！.。]+$/u, "").trim();
  if (!text) return null;
  const predicateCore = "(?:있(?:어|어요|나|냐|나요|습니까|니|을까|을까요|는지|음)?|소장|보유|대출\\s*가능|대여\\s*가능|구비|비치|빌릴\\s*수\\s*있(?:어|나요)?|대출\\s*할\\s*수\\s*있(?:어|나요)?|대여\\s*할\\s*수\\s*있(?:어|나요)?)";
  const match = text.match(new RegExp(`^(.+?)(?:은|는|이|가|을|를)?\\s+(.{2,50}?(?:도서관|작은\\s*도서관|문고))(?:에서는|에서|에는|에)?\\s*${predicateCore}$`, "u"));
  if (!match?.[1] || !match?.[2]) return null;
  const candidateLibrary = stripTrailingKoreanParticles(match[2]);
  if (!(looksLikeTrustedSpecificLibraryNameForUnderstanding(candidateLibrary) || isSafeSpacedLibraryNameForUnderstanding(candidateLibrary))) return null;
  const title = normalizeAvailabilityBookTitleFinal(match[1], text);
  if (!title || (Array.from(title).length < 2 && !hasClearAvailabilityCueForShortTitle(text))) return null;
  return {
    bookTitle: title,
    normalizedQuery: title,
    libraryName: candidateLibrary,
    regionHint: "",
    region: "",
    confidence: 0.91
  };
}

function buildBookTitleCandidates(...values) {
  const seen = new Set();
  const candidates = [];
  const add = (value = "") => {
    const cleaned = normalizeProvidedBookTitleCandidate(String(value || ""));
    if (!cleaned) return;
    if (typeof hasObviousAvailabilityRequestResidue === "function" && hasObviousAvailabilityRequestResidue(cleaned)) return;
    const key = normalizeSearchText(cleaned);
    if (!key || seen.has(key)) return;
    seen.add(key);
    candidates.push(cleaned);
  };

  values.flat(Infinity).forEach((value) => {
    if (!value) return;
    add(value);
    const text = String(value || "").replace(/\s+/g, " ").trim();
    if (!text) return;
    const particleCandidate = stripTrailingKoreanParticles(text);
    add(particleCandidate);
    const token = text.replace(/(?:은|는|가|을|를)$/u, "").trim();
    add(token);
    // 제목 끝의 도/만/의/와/과는 제목 구성 글자인 경우가 많아 자동 제거 후보를 만들지 않는다.
  });

  return candidates.slice(0, 5);
}

function stripGenericLibraryNounPrefixFromTitle(subject = "") {
  const text = String(subject || "").replace(/\s+/g, " ").trim();
  if (!text) return text;
  const stripped = text.replace(/^(?:공공\s*)?(?:작은\s*)?도서관(?:에서|에는|에서|에)?\s+/u, "").trim();
  return stripped || text;
}

function hasClearAvailabilityCueForShortTitle(message = "") {
  const text = String(message || "").trim();
  return /(?:어디|어딘|어딨|있나|있냐|있어|소장|보유|대출|대여|빌릴|빌리는|빌려|구비|비치|구할|찾을|볼\s*수|읽을\s*수|도서관)/u.test(text);
}

function normalizeProvidedBookTitleCandidate(value = "") {
  // 규칙 기반 후보에는 명백한 요청 꼬리만 제거한다. 제목 내부의 어디/에서/비치/구비/도서관은 보존한다.
  let cleaned = stripKoreanCasualPrefix(stripKoreanRequestTail(String(value || "")))
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .replace(/^[\s"'「『《〈]+|[\s"'」』》〉]+$/g, "")
    .replace(/[?？!！.。]+$/u, "")
    .replace(/\s+/g, " ")
    .trim();

  const strippedTail = stripBookAvailabilityActionTail(cleaned);
  if (strippedTail && strippedTail.length >= 1) cleaned = strippedTail;
  cleaned = cleaned.replace(/\s+(?:은|는|을|를)$/u, "").trim();
  return cleaned;
}

function normalizeAiProvidedBookTitleCandidate(value = "") {
  // AI가 문맥상 책 제목이라고 판단한 값은 파괴적으로 다시 자르지 않는다.
  // JSON/인용부호/문장부호/명백한 요청 꼬리만 정리한다.
  return stripKoreanCasualPrefix(stripKoreanRequestTail(String(value || "")))
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .replace(/^[\s"'「『《〈]+|[\s"'」』》〉]+$/g, "")
    .replace(/[?？!！.。]+$/u, "")
    .replace(/\s+/g, " ")
    .trim();
}

function stripKoreanCasualPrefix(text = "") {
  let cleaned = String(text || "").trim();

  for (let i = 0; i < 3; i += 1) {
    const next = cleaned
      .replace(/^(?:야|저기|혹시|음|어|아|근데|그럼|그러면|있잖아|잠깐)[,\s]+/u, "")
      .replace(/^님[,\s]+/u, "")
      .trim();
    if (next === cleaned) break;
    cleaned = next;
  }

  return cleaned;
}

function normalizeBookSearchKeyword(input = "") {
  let keyword = String(input || "")
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .replace(/(?:어느|어떤|무슨)\s*도서관(?:에서|에)?\s*있(?:어|어요|나요|니|습니까|을까|을까요|는지|나)?\s*[?？!！.。]*$/gi, "")
    .replace(/어느\s*도서관에서\s*빌릴\s*수\s*있[어나요]*/gi, "")
    .replace(/어느\s*도서관(?:에서|에)?\s*있(?:어|나요|니|습니까|을까|을까요)?/gi, "")
    .replace(/(?:어느|어떤|무슨)\s*도서관(?:에서|에)?\s*(?:소장|대출|빌릴|빌려|찾을).*$/gi, "")
    .replace(/(?:어느|어떤|무슨)\s*도서관(?:에서|에)?/gi, "")
    .replace(/(?:찾을|볼|읽을|구할)\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?/gi, "")
    .replace(/빌릴\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?/gi, "")
    .replace(/대여\s*할\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?/gi, "")
    .replace(/대여\\s*가능(?:한)?\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?/gi, "")
    .replace(/대여\s*(?:되는|가능한?)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?/gi, "")
    .replace(/빌려\s*볼\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?/gi, "")
    .replace(/(?:구비된|구비|비치된|비치)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))/gi, "")
    .replace(/대출처/gi, "")
    .replace(/대출\s*할\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?/gi, "")
    .replace(/대출\\s*가능(?:한)?\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?/gi, "")
    .replace(/대여\\s*가능(?:한)?\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?/gi, "")
    .replace(/대여\s*할\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?/gi, "")
    .replace(/대여\s*(?:되는|가능한?)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?/gi, "")
    .replace(/빌려\s*볼\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?/gi, "")
    .replace(/구할\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?/gi, "")
    .replace(/(?:구비된|구비|비치된|비치)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))/gi, "")
    .replace(/대출처/gi, "")
    .replace(/(?:빌릴|빌리는)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))/gi, "")
    .replace(/빌려\s*주는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?/gi, "")
    .replace(/(?:있는|있을)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?/gi, "")
    .replace(/(?:소장한?|소장된|소장\s*중인|보유한?|보유\s*중인)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))/gi, "")
    .replace(/소장\s*도서관/gi, "")
    .replace(/보유\s*도서관/gi, "")
    .replace(/소장\s*여부/gi, "")
    .replace(/대출\s*여부/gi, "")
    .replace(/도서관\s*(?:찾아\s*(?:줘요|줘|주세요|줄래요?|주실래요?|줄\s*수\s*있(?:어|나요|니|을까)|봐줘요?|봐요?|봐|주라)?|검색\s*(?:해\s*)?(?:줘요|줘|주세요|줄래요?|주실래요?|줄\s*수\s*있(?:어|나요|니|을까))?)/gi, "")
    .replace(/^(.+?)(?:이|가)?\s*(?:쓴|지은|저술한|집필한)\s*(?:책|도서(?!관))?\s*$/gi, "$1")
    .replace(/((?:작가|화가|소설가|문학가|음악가|예술가|철학가|번역가|평론가|비평가|만화가|사진가|연출가|극작가|연구가|교육가|사상가))\s+(?:책|도서(?!관))\s*$/gi, "$1")
    .replace(/^(?:책|도서(?!관))\s*제목\s*(?:은|는|가|을|를)?\s*/gi, "")
    .replace(/^(?:책|도서(?!관))\s*(?:검색|찾기|찾아보기)\s*/gi, "")
    .replace(/^(.{2,}?)(?:이라는|라는|란)\s*(?:책|도서(?!관))\s*(?:입니다|이에요|예요|야|맞아)?\s*$/gi, "$1")
    .replace(/^(.{2,}?)(?:이라는|라는|란)\s*(?:책|도서(?!관))\s*(?:찾|검색|알려|보여|추천|어디|있|빌릴|대출|소장).*$/gi, "$1")
    .replace(/\s+(?:책|도서(?!관))\s*(?:검색|찾기|찾아보기)?$/gi, "")
    .replace(/(?:이|가)?\s*(?:쓴|지은|저술한|집필한)\s*(?:책|도서(?!관))?\s*$/gi, "")
    .replace(/어디\s*(?:에서|서)?\s*(?:볼|읽을?|찾을)\s*수\s*있(?:어|어요|나요|니|습니까|을까|을까요|는데|는지|나)?.*$/gi, "")
    .replace(/어디\s*(?:에서|서|에)?\s*(?:있(?:어|어요|나요|니|습니까|을까|을까요|는데|는지|나)?|위치(?:해)?|찾을\s*수\s*있(?:어|어요|나요|니|을까|을까요)?|야|임|인가요?|일까|죠).*$/gi, "")
    .replace(/어딘\s*(?:데|지|가요?|가).*$/gi, "")
    .replace(/어딨\s*(?:어|어요|나요|니|냐|습니까|는데)?.*$/gi, "")
    .replace(/어디(?:에서|서)?\s*빌릴\s*수\s*있[어나요]*/gi, "")
    .replace(/어디(?:에서|서)?\s*빌려[요]?/gi, "")
    .replace(/어디(?:에서|서)?\s*대출\\s*가능(?:해|한가요|할까요)?/gi, "")
    .replace(/\s+어디(?:에서|서|에)?\s*$/gi, "")
    .replace(/(?:찾을|볼|읽을)\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?/gi, "")
    .replace(/(?:대여\s*(?:가능(?:한)?|할\s*수\s*있는|되(?:는|어|나요)?)|빌려\s*볼\s*수\s*있는|구할\s*수\s*있는)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?/gi, "")
    .replace(/(?:구비|비치)(?:한|된)?\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))/gi, "")
    .replace(/(?:대출처|소장처|보유처)/gi, "")
    .replace(/빌릴\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?/gi, "")
    .replace(/(?:빌릴|빌리는)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))/gi, "")
    .replace(/빌려\s*주는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?/gi, "")
    .replace(/빌릴\s*수\s*있[어나요]*/gi, "")
    .replace(/대출\s*할\s*수\s*있[어나요]*/gi, "")
    .replace(/대출\\s*가능(?:해|한가요|할까요)?/gi, "")
    .replace(/대여\\s*가능(?:해|한가요|할까요|한)?/gi, "")
    .replace(/대여\s*할\s*수\s*있[어나요]*/gi, "")
    .replace(/대여\s*(?:되는|돼|되나요|가능)/gi, "")
    .replace(/빌려\s*볼\s*수\s*있[어나요]*/gi, "")
    .replace(/구할\s*수\s*있[어나요]*/gi, "")
    .replace(/\s+(?:구비된|구비|비치된|비치)\s*$/gi, "")
    .replace(/대출처\s*$/gi, "")
    .replace(/(?:은|는|이|을|를)?\s*있(?:나|냐|나요|습니까|니|을까|을까요|는지)\s*[?？!！.。]*$/gi, "")
    .replace(/(?:은|는|이|을|를)?\s*있(?:어|어요)\s*[?？!！.。]*$/gi, "")
    .replace(/(?:은|는|이|을|를)?\s*없(?:나|나요|습니까|니|을까|을까요|는지|어|어요)\s*[?？!！.。]*$/gi, "");

  keyword = stripKoreanCasualPrefix(stripKoreanRequestTail(keyword))
    .replace(/[?？!！.。]/g, " ")
    .replace(/\s+/g, " ")
    .replace(/\s*(?:위치|주소)(?:가|는)?\s*$/giu, "")
    .trim();

  keyword = stripBookAvailabilityActionTail(keyword);
  keyword = stripTrailingKoreanParticles(keyword);
  keyword = keyword
    .replace(/\s+(?:은|는|이|가|을|를|와|과|도|만|의)$/u, "")
    .trim();

  keyword = stripBookAvailabilityActionTail(keyword);
  return stripTrailingKoreanParticles(keyword);
}

function normalizePlainBookSearchKeyword(input = "") {
  // 일반 책 검색은 제목 자체가 "어디/있는/에서"를 포함할 수 있으므로
  // 소장 검색용 정규화를 적용하지 않는다. 명령형 꼬리와 명백한 검색 접두사만 정리한다.
  let keyword = stripKoreanCasualPrefix(stripKoreanRequestTail(String(input || "")))
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .replace(/^[\s"'「『《〈]+|[\s"'」』》〉]+$/g, "")
    .replace(/[?？!！.。]+$/u, "")
    .replace(/^(?:책|도서(?!관))\s*제목\s*(?:은|는|이|가|을|를)?\s*/giu, "")
    .replace(/^(?:책|도서(?!관))\s*(?:검색|찾기|찾아보기)\s*/giu, "")
    .replace(/\s+(?:책|도서(?!관))\s*(?:검색|찾기|찾아보기)$/giu, "")
    .replace(/^(.{2,}?)(?:이라는|라는|란)\s*(?:책|도서(?!관))\s*(?:입니다|이에요|예요|야|맞아)?\s*$/giu, "$1")
    .replace(/^(.+?)(?:이|가)?\s*(?:쓴|지은|저술한|집필한)\s*(?:책|도서(?!관))?\s*$/giu, "$1")
    .replace(/\s+/g, " ")
    .trim();

  // 띄어 쓴 조사는 제거하되, 붙은 조사는 제목 일부일 수 있어 보존한다.
  keyword = keyword.replace(/\s+(?:은|는|이|가|을|를)$/u, "").trim();
  return keyword;
}

function stripKoreanRequestTailFromNormalizedText(text = "") {
  let cleaned = String(text || "").trim();

  for (let i = 0; i < 4; i += 1) {
    const next = cleaned.replace(NORMALIZED_KOREAN_REQUEST_TAIL_PATTERN, "").trim();
    if (next === cleaned) break;
    cleaned = next;
  }

  return cleaned;
}

function includesAny(originalText, keywords = []) {
  const normalized = normalizeSearchText(originalText);
  return keywords.some((keyword) => normalized.includes(normalizeSearchText(keyword)));
}

function extractBookTitleFromQuestion(input) {
  const text = String(input || "").trim();
  if (!text) return "";

  const patterns = [
    /[“"']?(.+?)[”"']?\s*(?:은|는|이|가)?\s*(무슨\s*내용|어떤\s*내용|어떤 책|무슨 책|책이야|책인가요|줄거리|책\s*소개|도서\s*소개|소개|설명|내용)/i,
    /[“"']?(.+?)[”"']?\s*(?:은|는|이|가)?\s*(가 뭐야|이 뭐야|이란|란)/i
  ];

  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match?.[1]) {
      return match[1]
        .trim()
        .replace(/[“"']+/g, "")
        .replace(/\s+(?:책|도서(?!관))$/u, "")
        .replace(/\s*(?:은|는|이|가)$/u, "")
        .trim();
    }
  }

  return text
    .replace(/\s*(?:은|는|이|가)?\s*어떤 책.*$/i, "")
    .replace(/\s*(?:은|는|이|가)?\s*무슨 책.*$/i, "")
    .replace(/\s*(?:은|는|이|가)?\s*무슨\s*내용.*$/i, "")
    .replace(/\s*(?:은|는|이|가)?\s*어떤\s*내용.*$/i, "")
    .replace(/\s*(?:은|는|이|가)?\s*줄거리.*$/i, "")
    .replace(/\s*(?:은|는|이|가)?\s*내용.*$/i, "")
    .replace(/\s*(?:은|는|이|가)?\s*소개.*$/i, "")
    .replace(/\s*(?:은|는|이|가)?\s*설명.*$/i, "")
    .replace(/에\s*대해\s*알려줘.*$/i, "")
    .replace(/에\s*대해\s*소개해줘.*$/i, "")
    .replace(/에\s*대해\s*설명해줘.*$/i, "")
    .replace(/알려줘.*$/i, "")
    .replace(/소개해줘.*$/i, "")
    .replace(/설명해줘.*$/i, "")
    .replace(/해줘.*$/i, "")
    .replace(/[“"']+/g, "")
    .replace(/\s+(?:책|도서(?!관))$/u, "")
    .replace(/\s*(?:은|는|이|가)$/u, "")
    .trim();
}

/* ------------------------------
 * FAQ / assist rules
 * ------------------------------ */

const FAQ_CACHE_TTL_MS = 10 * 60 * 1000;
let faqCache = {
  data: null,
  fetchedAt: 0
};


const DEFAULT_FAQ_DATA = [
  {
    question: "도서관의 날은 언제인가요?",
    keywords: ["도서관의 날", "도서관의날"],
    answer: "도서관의 날은 매년 4월 12일입니다.",
    topic: "library_day",
    intent: "date",
    enabled: true,
    priority: 100
  },
  {
    question: "도서관의 날이 무엇인가요?",
    keywords: ["도서관의 날", "도서관의날", "의미"],
    answer: "도서관의 날은 도서관의 가치와 역할을 알리기 위한 날입니다.",
    topic: "library_day",
    intent: "description",
    enabled: true,
    priority: 90
  },
  {
    question: "이용 방법이 궁금해요.",
    keywords: ["이용 안내", "사용 방법", "검색 방법", "어떻게 이용", "이용 방법"],
    answer: "지역을 선택한 뒤 도서관명이나 책 제목을 입력하면 관련 정보를 찾을 수 있습니다. 예를 들어 ‘중구 도서관’, ‘데미안 있는 도서관’처럼 입력하시면 됩니다.",
    topic: "usage",
    intent: "method",
    enabled: true,
    priority: 80
  },
  {
    question: "미네르바 서비스 소개",
    keywords: ["미네르바", "minerva", "서비스 소개", "무슨 서비스"],
    answer: "Minerva Search는 도서관 정보와 책 소장 도서관을 대화형으로 찾을 수 있게 만든 서비스입니다.",
    topic: "service_intro",
    intent: "description",
    enabled: true,
    priority: 70
  }
];

function getNotionTextValue(property) {
  if (!property) return "";
  if (property.type === "title") {
    return forceArray(property.title).map((item) => item?.plain_text || "").join("").trim();
  }
  if (property.type === "rich_text") {
    return forceArray(property.rich_text).map((item) => item?.plain_text || "").join("").trim();
  }
  if (property.type === "select") {
    return property.select?.name || "";
  }
  if (property.type === "status") {
    return property.status?.name || "";
  }
  if (property.type === "url") {
    return property.url || "";
  }
  return "";
}

function getNotionKeywords(property) {
  if (!property) return [];
  if (property.type === "multi_select") {
    return forceArray(property.multi_select).map((item) => String(item?.name || "").trim()).filter(Boolean);
  }

  const textValue = getNotionTextValue(property);
  return textValue
    .split(/[\n,|/]/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function getNotionCheckboxValue(property, fallback = true) {
  if (!property) return fallback;
  if (property.type === "checkbox") return Boolean(property.checkbox);
  const textValue = getNotionTextValue(property).toLowerCase();
  if (!textValue) return fallback;
  return !["false", "off", "0", "disabled", "비활성"].includes(textValue);
}

function getNotionNumberValue(property, fallback = 0) {
  if (!property) return fallback;
  if (property.type === "number") return Number(property.number || 0);
  const textValue = getNotionTextValue(property);
  const numeric = Number(textValue);
  return Number.isFinite(numeric) ? numeric : fallback;
}

function pickProperty(properties, names = []) {
  for (const name of names) {
    if (properties?.[name]) return properties[name];
  }
  return null;
}

function parseNotionFaqPage(page) {
  const properties = page?.properties || {};
  const question = getNotionTextValue(pickProperty(properties, ["질문", "Question", "title", "Name", "이름"]));
  const answer = getNotionTextValue(pickProperty(properties, ["답변", "Answer", "내용", "본문"]));
  const keywords = getNotionKeywords(pickProperty(properties, ["키워드", "Keywords", "검색어", "태그"]));
  const topic = getNotionTextValue(pickProperty(properties, ["주제", "Topic"]));
  const intent = getNotionTextValue(pickProperty(properties, ["의도", "Intent"]));
  const enabled = getNotionCheckboxValue(pickProperty(properties, ["사용", "Enabled", "공개", "활성화"]), true);
  const priority = getNotionNumberValue(pickProperty(properties, ["우선순위", "Priority", "정렬"]), 0);

  return {
    question,
    answer,
    keywords,
    topic: topic || "",
    intent: intent || "",
    enabled,
    priority
  };
}

async function fetchNotionFaqPages() {
  if (!NOTION_API_KEY || !NOTION_FAQ_DATABASE_ID) return null;

  let hasMore = true;
  let startCursor = undefined;
  const pages = [];

  while (hasMore) {
    const response = await fetchWithTimeout(`https://api.notion.com/v1/databases/${NOTION_FAQ_DATABASE_ID}/query`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${NOTION_API_KEY}`,
        "Notion-Version": NOTION_VERSION,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        page_size: 100,
        ...(startCursor ? { start_cursor: startCursor } : {})
      })
    });

    if (!response.ok) {
      throw new Error(`노션 FAQ 조회 실패: ${response.status}`);
    }

    const payload = await response.json();
    pages.push(...forceArray(payload.results));
    hasMore = Boolean(payload.has_more);
    startCursor = payload.next_cursor || undefined;
  }

  return pages;
}

function normalizeFaqItem(item) {
  const question = String(item.question || "").trim();
  const answer = String(item.answer || "").trim();
  const keywords = forceArray(item.keywords).map((keyword) => String(keyword || "").trim()).filter(Boolean);
  const topic = String(item.topic || "").trim();
  const intent = String(item.intent || "").trim();
  const enabled = item.enabled !== false;
  const priority = Number.isFinite(Number(item.priority)) ? Number(item.priority) : 0;

  return { question, answer, keywords, topic, intent, enabled, priority };
}

async function getFaqData() {
  const now = Date.now();
  if (faqCache.data && now - faqCache.fetchedAt < FAQ_CACHE_TTL_MS) {
    return faqCache.data;
  }

  try {
    const notionPages = await fetchNotionFaqPages();
    if (Array.isArray(notionPages) && notionPages.length > 0) {
      const data = notionPages
        .map(parseNotionFaqPage)
        .map(normalizeFaqItem)
        .filter((item) => item.enabled && item.answer && (item.question || item.keywords.length > 0))
        .sort((a, b) => b.priority - a.priority);

      if (data.length > 0) {
        faqCache = { data, fetchedAt: now };
        return data;
      }
    }
  } catch (error) {
    console.error("NOTION_FAQ_ERROR:", error);
  }

  const fallback = DEFAULT_FAQ_DATA.map(normalizeFaqItem).filter((item) => item.enabled);
  faqCache = { data: fallback, fetchedAt: now };
  return fallback;
}

function scoreFaqMatch(item, query) {
  const rawQuery = String(query || "").trim().toLowerCase();
  const normalizedQuery = normalizeSearchText(query);
  const normalizedQuestion = normalizeSearchText(item.question);
  const normalizedKeywords = item.keywords.map((keyword) => normalizeSearchText(keyword)).filter(Boolean);
  const rawKeywords = item.keywords.map((keyword) => String(keyword || "").trim().toLowerCase()).filter(Boolean);

  if (!normalizedQuery) return 0;

  let score = 0;

  if (normalizedQuestion && normalizedQuery === normalizedQuestion) score += 320;
  if (normalizedQuestion && normalizedQuery.includes(normalizedQuestion)) score += 180;
  if (normalizedQuestion && normalizedQuestion.includes(normalizedQuery) && normalizedQuery.length >= 3) score += 120;
  if (rawQuery && String(item.question || "").trim().toLowerCase() === rawQuery) score += 180;

  normalizedKeywords.forEach((keyword) => {
    if (!keyword) return;
    if (normalizedQuery === keyword) score += 240;
    else if (normalizedQuery.includes(keyword)) score += 130;
    else if (keyword.includes(normalizedQuery) && normalizedQuery.length >= 3) score += 90;
  });

  rawKeywords.forEach((keyword) => {
    if (!keyword) return;
    if (rawQuery === keyword) score += 180;
    else if (rawQuery.includes(keyword)) score += 120;
    else if (keyword.includes(rawQuery) && rawQuery.length >= 3) score += 75;
  });

  const queryTokens = rawQuery.split(/\s+/).filter(Boolean);
  const questionText = String(item.question || "").trim().toLowerCase();
  const keywordBlob = rawKeywords.join(" ");
  const tokenMatches = queryTokens.filter((token) => questionText.includes(token) || keywordBlob.includes(token)).length;
  score += tokenMatches * 25;

  score += Math.min(item.priority || 0, 100);
  return score;
}

async function findBestFaqMatch(query) {
  const faqData = await getFaqData();
  const ranked = faqData
    .map((item) => ({ item, score: scoreFaqMatch(item, query) }))
    .filter((entry) => entry.score >= 95)
    .sort((a, b) => b.score - a.score);

  return ranked[0]?.item || null;
}

function isLibraryServiceFaqIntent(message = "") {
  const text = String(message || "").trim().toLowerCase();
  if (!text) return false;
  if (isBookDescriptionRequest(text)) return false;
  if (isUnsupportedDigitalTitleLike(text)) return false;

  const normalized = normalizeSearchText(text);
  if (/^(?:대출기간|대출기한|대출권수|운영시간|이용시간|휴관일|회원증|회원카드|도서대출증)$/.test(normalized)) {
    return true;
  }

  const directServiceSignals = /(?:연체|반납|반납일|회원증|회원\s*카드|도서\s*대출증|운영\s*시간|이용\s*시간|개관|폐관|휴관|휴관일|상호\s*대차|희망\s*도서|책\s*이음|무인\s*반납|분실|재발급|회원\s*가입|비밀번호|행사|프로그램|문화\s*행사|예약|홈페이지|웹\s*사이트|사이트|앱|어플|애플리케이션|어플리케이션|대출증|전자\s*책|전자도서|전자\s*도서|ebook|e\s*-?\s*book|e\s*-?\s*북|e\s*북|이북|오디오\s*북|오디오북|열람실|좌석|프린트|프린터|출력|인쇄|스캔|복사|노트북|pc|컴퓨터|와이파이|wifi|주차|사물함|보관함|식당|카페|휴게실|스터디\s*룸|스터디룸)/u;
  if (directServiceSignals.test(text)) return true;

  const loanRuleSignals = /(?:대출\s*(?:기간|기한|권수|규정|방법|가능\s*권수)|몇\s*권|몇권|몇\s*일|몇일|얼마나\s*빌릴|언제까지\s*빌릴)/u;
  if (loanRuleSignals.test(text)) return true;

  const genericBookAction = /(?:도서관(?:에서|에)?\s*)?(?:책|도서(?!관)|전자\s*책|전자도서|ebook|e\s*-?\s*book)\s*(?:빌릴|빌리는\s*법|대출|반납|연장|예약)\s*(?:수|방법|법|가능|되|돼|해|하려면|할\s*수)?/u;
  if (genericBookAction.test(text)) return true;
  if (/도서관(?:에서|에)?\s*(?:대출\s*가능(?:한)?|대출\s*되는|빌릴\s*수\s*있는)\s*(?:책|도서(?!관))?/u.test(text)) return true;
  if (/(?:전자\s*책|전자도서|ebook|e\s*-?\s*book)\s*(?:대출|이용|빌리|빌리는\s*법|보는\s*법|읽는\s*법|방법)/u.test(text)) return true;
  if (/도서관/u.test(text) && /(?:예약|전자\s*책|전자도서|홈페이지|웹\s*사이트|사이트|회원\s*가입|이용\s*방법|이용법|앱|어플|어플리케이션|애플리케이션|대출증)/u.test(text)) return true;

  const genericRenewReserve = /(?:연장|예약)\s*(?:할\s*수|가능|방법|하려면|되나|되나요|돼|돼요|취소)/u;
  if (genericRenewReserve.test(text)) return true;

  return false;
}

function isLikelyFaqIntent(message = "") {
  const text = String(message || "").trim().toLowerCase();
  if (!text) return false;
  if (isLibraryServiceFaqIntent(text)) return true;

  const faqSignals = [
    "방법",
    "이용",
    "문의",
    "소개",
    "도서관의날",
    "도서관의 날",
    "도서관주간",
    "도서관 주간",
    "자주 묻는",
    "faq"
  ];

  if (!faqSignals.some((signal) => text.includes(signal))) return false;
  if (isStrongLibrarySearchIntent(text)) return false;
  if (isBookDescriptionRequest(text)) return false;
  return true;
}

function isStrongLibrarySearchIntent(message = "") {
  const text = String(message || "").trim().toLowerCase();
  if (!text) return false;

  const negativeSignals = ["어떤 책", "무슨 책", "줄거리", "책 소개", "내용", "에 대해 알려", "에 대해 설명", "에 대해 소개"];
  if (negativeSignals.some((signal) => text.includes(signal))) return false;

  if (/(?:도서관|작은\s*도서관|문고)의\s+.{1,}/u.test(text) && !/(?:위치|주소|운영|이용|개관|휴관|전화|연락처|주차|와이파이|좌석|열람실)/u.test(text)) return false;

  const explicitSignals = [
    "근처 도서관",
    "도서관 어디",
    "도서관 어딘",
    "도서관 어딨",
    "도서관 찾아",
    "소재 도서관",
    "도서관 위치",
    "도서관 주소"
  ];

  if (explicitSignals.some((signal) => text.includes(signal))) return true;
  if (/(도서관|작은\s*도서관|문고)\s*(?:은|는|가|을|를)?\s*(?:어디|어딘|어딨|위치|주소)/u.test(text)) return true;
  if (/(도서관|작은\s*도서관|문고)\s*(?:은|는|가|을|를)?\s*있(?:나|냐|나요|습니까|니|어|어요|는지)?\s*[?？!！.。]*$/u.test(text)) return true;

  const simpleRegionOrLibraryQuery = /^(?:서울|서울시|부산|부산시|대구|대구시|인천|인천시|광주|광주시|대전|대전시|울산|울산시|세종|세종시|경기|경기도|강원|강원도|충북|충청북도|충남|충청남도|전북|전라북도|전남|전라남도|경북|경상북도|경남|경상남도|제주|제주도|[가-힣0-9]{1,8}(?:구|시|군|읍|면|동|로|길))(?:\s*도서관)?$/u;
  if (simpleRegionOrLibraryQuery.test(text) && !isLikelyFalseAdminRegionHint(text)) {
    return true;
  }

  return /(?:서울|부산|대구|인천|광주|대전|울산|세종|경기|강원|충북|충남|전북|전남|경북|경남|제주|[가-힣0-9]{1,12}(?:구|시|군|읍|면|동|로|길)).*(도서관)/u.test(text);
}

function isLikelyPlainBookQuery(message = "") {
  const text = String(message || "").trim();
  const lowered = text.toLowerCase();
  if (!text) return false;
  if (/^97[89]\d{10}$/.test(text.replace(/[^0-9]/g, ""))) return true;
  if (text.length > 60) return false;
  if (/[?？]/.test(text)) return false;
  if (/(도서관|문의|방법|이용|서비스|행사|주간|의 날|도서관의날)/i.test(lowered)) return false;
  if (isLibraryServiceFaqIntent(text)) return false;
  if (isStrongLibrarySearchIntent(lowered)) return false;
  if (isAmbiguousRegionWhereQueryForUnderstanding(text)) return false;
  return true;
}


function isBareBookWhereQuestion(message = "") {
  const text = String(message || "").trim().toLowerCase();
  if (!text || !KOREAN_BARE_WHERE_TAIL_PATTERN.test(text)) return false;
  if (isStrongLibrarySearchIntent(text)) return false;

  const subject = stripTrailingKoreanParticles(normalizeBookSearchKeyword(text));
  if (!subject || subject.length < 2) return false;
  if (isStrongLibrarySearchIntent(subject)) return false;
  if (/(도서관|작은\s*도서관|문고)$/u.test(subject)) return false;

  const normalizedSubject = subject.replace(/\s+/g, "");
  if (/^(여기|거기|저기|이곳|그곳|저곳|현재위치|내위치)$/u.test(normalizedSubject)) return false;

  if (/^(서울|부산|대구|인천|광주|대전|울산|세종|경기|강원|충북|충남|전북|전남|경북|경남|제주|[가-힣0-9]+구|[가-힣0-9]+시|[가-힣0-9]+군|[가-힣0-9]+읍|[가-힣0-9]+면|[가-힣0-9]+동|[가-힣0-9]+리)$/u.test(normalizedSubject)) {
    return false;
  }

  return true;
}

function clampConfidence(value, fallback = 0.7) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return fallback;
  return Math.max(0, Math.min(1, numeric));
}

function isAmbiguousRegionOnlyQueryForUnderstanding(message = "", selectedRegion = "") {
  const raw = String(message || "").trim().replace(/[?？!！.。]+$/u, "");
  const normalized = normalizeSearchText(raw);
  if (!normalized) return false;
  if (/^(서울|서울시|부산|부산시|대구|대구시|인천|인천시|광주|광주시|대전|대전시|울산|울산시|세종|세종시|경기|경기도|강원|강원도|충북|충청북도|충남|충청남도|전북|전라북도|전남|전라남도|경북|경상북도|경남|경상남도|제주|제주도)$/.test(normalized)) return true;
  if (/^[가-힣0-9]{1,5}(?:구|시|군)$/.test(normalized) && !isLikelyFalseAdminRegionHint(normalized)) return true;
  return isDetailedRegionAliasOnlyForUnderstanding(raw, selectedRegion);
}

function isAmbiguousRegionWhereQueryForUnderstanding(message = "", selectedRegion = "") {
  const text = String(message || "").trim();
  if (!text) return false;
  const regionQuery = text.replace(/\s*(?:어디|어딘데|어디야|어디임|어디에|어디서)\s*[?？!！.。]*$/u, "").trim();
  if (!regionQuery || regionQuery === text) return false;
  return isAmbiguousRegionOnlyQueryForUnderstanding(regionQuery, selectedRegion);
}

function isPopularBooksQuestion(message = "", selectedRegion = "") {
  const text = String(message || "").trim().toLowerCase();
  if (!text) return false;

  const hasHardPopularSignal = /(잘\s*나가는|인기|대출\s*인기|많이\s*빌린|많이\s*대출|베스트|요즘\s*핫한|핫한|순위|랭킹)/u.test(text);
  const hasRecommendSignal = /추천/u.test(text);
  const hasBookSignal = /(책|도서(?!관)|자료|베스트셀러)/u.test(text);
  const hasExplicitLibrarySignal = /도서관/u.test(text);
  const hasBroadRegionSignal = /(서울|부산|대구|인천|광주|대전|울산|세종|경기|강원|충북|충남|전북|전남|경북|경남|제주)/u.test(text);
  const hasSpecificAreaSignal = /[가-힣0-9]{2,}(?:구|군|시|읍|면|동)(?=\s|$|의|에서|에|인기|대출|많이|잘|베스트|도서|책|자료|순위|랭킹|추천)/u.test(text);
  const hasLibraryOrLocationSignal = hasExplicitLibrarySignal || hasBroadRegionSignal || hasSpecificAreaSignal;
  const hasSpecificLocationSignal = hasExplicitLibrarySignal || hasSpecificAreaSignal;

  if (!hasBookSignal) return false;
  if (hasHardPopularSignal) return hasLibraryOrLocationSignal || Boolean(sanitizeRegionCode(selectedRegion)) || /(?:요즘\s*)?인기\s*(?:많은|있는)?\s*(?:책|도서|자료)|많이\s*빌린\s*(?:책|도서|자료)/u.test(text);
  if (hasRecommendSignal) return hasSpecificLocationSignal;

  return false;
}

function extractPopularBooksQueryForUnderstanding(message = "") {
  const cleaned = String(message || "")
    .replace(/도서관\s*에서의?/gi, "도서관 ")
    .replace(/(서울|부산|대구|인천|광주|대전|울산|세종|경기|강원|충북|충남|전북|전남|경북|경남|제주)(?:시|도|광역시|특별시|특별자치시|특별자치도)?\s*에서의?/gi, "$1 ")
    .replace(/([가-힣0-9]+(?:구|군|시|읍|면|동))\s*에서의?/gi, "$1 ")
    .replace(/도서관\s*의/gi, "도서관 ")
    .replace(/([가-힣0-9]+(?:구|군|시|읍|면|동))\s*의/gi, "$1 ")
    .replace(/\s+의\s+/gi, " ")
    .replace(/잘\s*나가는/gi, "")
    .replace(/인기\s*많은/gi, "")
    .replace(/인기\s*대출/gi, "")
    .replace(/대출\s*인기/gi, "")
    .replace(/많이\s*빌린/gi, "")
    .replace(/많이\s*대출된/gi, "")
    .replace(/많이\s*대출/gi, "")
    .replace(/많은/gi, "")
    .replace(/인기있는|인기\s*있는|인기/gi, "")
    .replace(/베스트\s*셀러|베스트|랭킹|순위|요즘\s*핫한|핫한|요즘|추천/gi, "")
    .replace(/책|도서(?!관)|자료/gi, "")
    .replace(/목록/gi, "")
    .replace(/\s*(?:에서|에)\s*$/gi, "")
    .replace(KOREAN_REQUEST_TAIL_PATTERN, "")
    .replace(/[?？]/g, "")
    .replace(/\s+/g, " ")
    .trim();

  return cleaned;
}

const UNDERSTANDING_SIDO_PATTERN = "서울(?:특별시|시)?|부산(?:광역시|시)?|대구(?:광역시|시)?|인천(?:광역시|시)?|광주(?:광역시|시)?|대전(?:광역시|시)?|울산(?:광역시|시)?|세종(?:특별자치시|시)?|경기(?:도)?|강원(?:특별자치도|도)?|충북|충청북도|충남|충청남도|전북|전라북도|전남|전라남도|경북|경상북도|경남|경상남도|제주(?:특별자치도|도)?";
const UNDERSTANDING_ADMIN_UNIT_PATTERN = "[가-힣0-9]+(?:구|군|시|읍|면|동)";

const UNDERSTANDING_PLACE_ALIAS_HINTS = [
  { names: ["홍대", "홍대입구"], region: "11", districtName: "마포구", regionHint: "홍대" },
  { names: ["신촌"], region: "11", districtName: "서대문구", regionHint: "신촌" },
  { names: ["대학로"], region: "11", districtName: "종로구", regionHint: "대학로" },
  { names: ["강남역"], region: "11", districtName: "강남구", regionHint: "강남역" },
  { names: ["대치동", "대치"], region: "11", districtName: "강남구", regionHint: "대치동" },
  { names: ["잠실"], region: "11", districtName: "송파구", regionHint: "잠실" },
  { names: ["여의도"], region: "11", districtName: "영등포구", regionHint: "여의도" },
  { names: ["광화문"], region: "11", districtName: "종로구", regionHint: "광화문" },
  { names: ["전주", "전주시"], region: "35", districtName: "전주시", regionHint: "전주" },
  { names: ["통영", "통영시"], region: "38", districtName: "통영시", regionHint: "통영" },
  { names: ["천안", "천안시"], region: "34", districtName: "천안시", regionHint: "천안" },
  { names: ["분당", "분당구", "성남 분당", "성남시 분당"], region: "31", districtName: "성남시", regionHint: "분당" },
  { names: ["일산", "일산동구", "일산서구", "고양 일산", "고양시 일산"], region: "31", districtName: "고양시", regionHint: "일산" },
  { names: ["영통", "영통구", "수원 영통", "수원시 영통"], region: "31", districtName: "수원시", regionHint: "영통" },
  { names: ["수지", "수지구", "용인 수지", "용인시 수지"], region: "31", districtName: "용인시", regionHint: "수지" },
  { names: ["마산", "창원 마산", "창원시 마산"], region: "38", districtName: "창원시", regionHint: "마산" },
  { names: ["울릉", "울릉도"], region: "37", districtName: "울릉군", regionHint: "울릉도" },
  { names: ["혜화동", "혜화"], region: "11", districtName: "종로구", regionHint: "혜화동" },
  { names: ["우동", "해운대 우동", "해운대구 우동"], region: "21", districtName: "해운대구", regionHint: "우동" }
];

const AMBIGUOUS_LOCAL_REGION_NAMES = new Set(["중구", "서구", "동구", "남구", "북구"].map((item) => normalizeSearchText(item)));
const AMBIGUOUS_BOOK_REGION_TOKENS = new Set(["광주", "광주시", "종로", "부평", "홍대", "전주", "통영", "분당", "일산", "잠실", "신촌", "대학로", "대치동", "대치", "마산", "울릉", "울릉도"].map((item) => normalizeSearchText(item)));

function isAmbiguousLocalRegionName(value = "") {
  const token = normalizeSearchText(normalizeUnderstandingAreaToken(value));
  return AMBIGUOUS_LOCAL_REGION_NAMES.has(token);
}


function getAmbiguousLocalRegionMentionInText(value = "") {
  const raw = String(value || "").replace(/[,，]/g, " ").replace(/\s+/g, " ").trim();
  if (!raw) return "";
  const normalized = normalizeSearchText(raw);
  const names = ["중구", "서구", "동구", "남구", "북구"];
  for (const name of names) {
    const compact = normalizeSearchText(name);
    if (new RegExp(`(?:^|[^가-힣0-9])${escapeRegExp(name)}(?:지역)?(?=$|[^가-힣0-9]|도서관|문고|어디|위치|행사|프로그램|추천|인기|데미안)`, "u").test(raw)) return name;
    if (normalized.startsWith(compact) || normalized.startsWith(`${compact}지역`) || normalized.startsWith(`${compact}도서관`)) return name;
    // 광역명 뒤에 붙는 경우: 서울서구도서관, 서울 서구 데미안 등
    for (const entry of REGION_ALIAS_ENTRIES || []) {
      if (entry?.normalized && normalized.startsWith(`${entry.normalized}${compact}`)) return name;
    }
  }
  return "";
}

function getBroadLocalRegionPairFromText(value = "") {
  const raw = String(value || "").replace(/[,，]/g, " ").replace(/\s+/g, " ").trim();
  const normalized = normalizeSearchText(raw);
  if (!normalized) return null;
  const localNames = ["중구", "서구", "동구", "남구", "북구"];
  for (const entry of REGION_ALIAS_ENTRIES || []) {
    if (!entry?.normalized || !entry?.code) continue;
    if (!normalized.startsWith(entry.normalized)) continue;
    const remainder = normalized.slice(entry.normalized.length);
    for (const localName of localNames) {
      const local = normalizeSearchText(localName);
      if (!remainder.startsWith(local)) continue;
      return {
        broadRegionHint: entry.name,
        broadRegion: entry.code,
        localRegionHint: localName,
        valid: isValidBroadRegionLocalPair(entry.code, localName)
      };
    }
  }
  return null;
}

function isValidBroadRegionLocalPair(broadRegionCode = "", localRegionName = "") {
  const region = sanitizeRegionCode(broadRegionCode || "");
  const local = normalizeSearchText(normalizeUnderstandingAreaToken(localRegionName));
  if (!region || !local || !Array.isArray(DETAILED_REGION_MAP)) return false;
  return DETAILED_REGION_MAP.some((item) => {
    if (item.region !== region) return false;
    return (item.names || []).some((name) => normalizeSearchText(name) === local);
  });
}

function getPlanLocalRegionGuardrailHint(plan = {}, originalMessage = "") {
  const regionHint = sanitizeQuery(plan.regionHint || "", 80);
  if (regionHint && isAmbiguousLocalRegionName(regionHint)) return normalizeUnderstandingAreaToken(regionHint);

  const libraryNameHint = getAmbiguousLocalRegionFromLibraryNameForUnderstanding(plan.libraryName || "");
  if (libraryNameHint) return libraryNameHint;

  const normalized = sanitizeQuery(plan.normalizedQuery || plan.query || "", 160);
  const normalizedLibraryHint = getAmbiguousLocalRegionFromLibraryNameForUnderstanding(normalized);
  if (normalizedLibraryHint) return normalizedLibraryHint;

  const mention = getAmbiguousLocalRegionMentionInText(originalMessage || normalized);
  return mention || "";
}


function applyAmbiguousLocalRegionGuardrail(plan = {}, originalMessage = "", selectedRegion = "") {
  if (!plan || typeof plan !== "object") return null;
  const selected = sanitizeRegionCode(selectedRegion || "");

  const intent = String(plan.intent || "");
  const eligible = new Set(["library_search", "popular_books", "book_availability", "ambiguous"]);
  if (!eligible.has(intent)) return null;

  const regionHint = getPlanLocalRegionGuardrailHint(plan, originalMessage);
  if (!regionHint || !isAmbiguousLocalRegionName(regionHint)) return null;

  const broadPair = getBroadLocalRegionPairFromText(originalMessage || plan.normalizedQuery || "");
  if (broadPair?.localRegionHint && normalizeSearchText(broadPair.localRegionHint) === normalizeSearchText(regionHint)) {
    if (broadPair.valid) return null;
    // 예: 서울 서구. 유효하지 않은 광역+구 조합은 다른 시도로 자동 보정하지 않고 지역 확인한다.
  } else if (selected) {
    // 선택 지역이 있더라도 그 선택 지역 안에 해당 중복 구가 없으면
    // 다른 시도(예: 서울 선택 + 서구 → 부산 서구)로 자동 보정하지 않는다.
    if (isValidBroadRegionLocalPair(selected, regionHint)) return null;
  }

  const guardrailSelectedRegion = "";

  if (intent === "popular_books") {
    return buildAmbiguousLocalRegionPopularBooksPlan(regionHint, originalMessage, guardrailSelectedRegion);
  }

  if (intent === "book_availability") {
    const title = sanitizeQuery(plan.bookTitle || plan.normalizedQuery || "", 120);
    const bookPlan = buildAmbiguousLocalRegionBookAvailabilityPlan(regionHint, title, originalMessage, guardrailSelectedRegion, { libraryName: plan.libraryName || "" });
    if (bookPlan) return bookPlan;
  }

  if (intent === "ambiguous") {
    const alternatives = Array.isArray(plan.alternatives) ? plan.alternatives : [];
    const hasBookLibraryAmbiguity = alternatives.some((item) => String(item?.intent || "") === "book_availability")
      && alternatives.some((item) => String(item?.intent || "") === "library_search");
    if (!hasBookLibraryAmbiguity) return null;
  }

  return buildAmbiguousLocalRegionLibrarySearchPlan(regionHint, originalMessage, guardrailSelectedRegion);
}

function getAmbiguousLocalRegionMatchesForUnderstanding(value = "") {
  const token = normalizeUnderstandingAreaToken(value);
  if (!token || !isAmbiguousLocalRegionName(token)) return [];
  try {
    return getExactDetailedRegionMatchesForUnderstanding(token, "").filter((item) => item?.region);
  } catch (_) {
    return [];
  }
}

function buildAmbiguousLocalRegionBookAvailabilityPlan(regionHint = "", bookTitle = "", originalMessage = "", selectedRegion = "", options = {}) {
  const normalizedRegion = normalizeUnderstandingAreaToken(regionHint);
  if (!normalizedRegion || selectedRegion || !isAmbiguousLocalRegionName(normalizedRegion)) return null;

  const title = normalizeAvailabilityBookTitleFinal(
    stripGenericLibraryNounPrefixFromTitle(stripBookAvailabilityActionTail(String(bookTitle || "")) || String(bookTitle || "")),
    originalMessage
  );
  if (!title || (Array.from(title).length < 1)) return null;

  const matches = getAmbiguousLocalRegionMatchesForUnderstanding(normalizedRegion);
  if (matches.length <= 1) return null;

  const requestedLibraryName = sanitizeQuery(options.libraryName || "", 120);
  const alternatives = matches.slice(0, 8).map((item) => {
    const regionName = (typeof REGION_CODE_TO_NAME !== "undefined" && REGION_CODE_TO_NAME[item.region]) ? REGION_CODE_TO_NAME[item.region] : item.region;
    const district = item.districtName || normalizedRegion;
    const label = requestedLibraryName
      ? `${regionName} ${requestedLibraryName}에서 『${title}』 찾기`
      : `${regionName} ${district} 기준으로 『${title}』 찾기`;
    return {
      label,
      intent: "book_availability",
      normalizedQuery: title,
      bookTitle: title,
      bookTitleCandidates: buildBookTitleCandidates(title),
      libraryName: requestedLibraryName,
      regionHint: district,
      region: item.region,
      filters: [{ field: "libraryAddressOrName", op: "contains_any", values: requestedLibraryName ? [district, requestedLibraryName] : [district] }]
    };
  });

  return {
    intent: "ambiguous",
    normalizedQuery: title,
    bookTitle: title,
    bookTitleCandidates: buildBookTitleCandidates(title),
    regionHint: normalizedRegion,
    region: "",
    confidence: 0.92,
    source: "rule",
    needsClarification: true,
    clarificationMessage: requestedLibraryName
      ? `“${requestedLibraryName}”이 여러 지역에 있을 수 있어요. 어느 지역 기준으로 『${title}』을 찾을까요?`
      : `“${normalizedRegion}”는 여러 지역에 있어요. 어느 지역 기준으로 『${title}』을 찾을까요?`,
    reason: "중복되는 세부 지역명은 전국 기준에서 시도를 단정하지 않고 이용자에게 지역을 확인",
    alternatives
  };
}



function buildAmbiguousLocalRegionLibrarySearchPlan(regionHint = "", originalMessage = "", selectedRegion = "") {
  const normalizedRegion = normalizeUnderstandingAreaToken(regionHint);
  if (!normalizedRegion || selectedRegion || !isAmbiguousLocalRegionName(normalizedRegion)) return null;
  const matches = getAmbiguousLocalRegionMatchesForUnderstanding(normalizedRegion);
  if (matches.length <= 1) return null;
  const alternatives = matches.slice(0, 8).map((item) => {
    const regionName = (typeof REGION_CODE_TO_NAME !== "undefined" && REGION_CODE_TO_NAME[item.region]) ? REGION_CODE_TO_NAME[item.region] : item.region;
    const district = item.districtName || normalizedRegion;
    const query = `${district} 도서관`;
    return {
      label: `${regionName} ${district} 도서관 검색`,
      intent: "library_search",
      normalizedQuery: query,
      libraryName: query,
      regionHint: district,
      region: item.region,
      filters: [{ field: "libraryAddressOrName", op: "contains_any", values: [district] }]
    };
  });
  return {
    intent: "ambiguous",
    normalizedQuery: `${normalizedRegion} 도서관`,
    regionHint: normalizedRegion,
    region: "",
    confidence: 0.91,
    source: "rule",
    needsClarification: true,
    clarificationMessage: `“${normalizedRegion}”는 여러 지역에 있어요. 어느 지역의 도서관을 찾을까요?`,
    reason: "중복되는 세부 지역명만으로 도서관을 찾는 경우 시도를 먼저 확인",
    alternatives
  };
}


function buildAmbiguousLocalRegionPopularBooksPlan(regionHint = "", originalMessage = "", selectedRegion = "") {
  const normalizedRegion = normalizeUnderstandingAreaToken(regionHint);
  if (!normalizedRegion || selectedRegion || !isAmbiguousLocalRegionName(normalizedRegion)) return null;
  const matches = getAmbiguousLocalRegionMatchesForUnderstanding(normalizedRegion);
  if (matches.length <= 1) return null;
  const alternatives = matches.slice(0, 8).map((item) => {
    const regionName = (typeof REGION_CODE_TO_NAME !== "undefined" && REGION_CODE_TO_NAME[item.region]) ? REGION_CODE_TO_NAME[item.region] : item.region;
    const district = item.districtName || normalizedRegion;
    return {
      label: `${regionName} ${district} 인기대출도서 보기`,
      intent: "popular_books",
      normalizedQuery: district,
      libraryName: "",
      regionHint: district,
      region: item.region,
      filters: [{ field: "libraryAddressOrName", op: "contains_any", values: [district] }]
    };
  });
  return {
    intent: "ambiguous",
    normalizedQuery: normalizedRegion,
    regionHint: normalizedRegion,
    region: "",
    confidence: 0.91,
    source: "rule",
    needsClarification: true,
    clarificationMessage: `“${normalizedRegion}”는 여러 지역에 있어요. 어느 지역 기준으로 인기대출도서를 볼까요?`,
    reason: "중복되는 세부 지역명의 인기대출도서 요청은 시도를 먼저 확인",
    alternatives
  };
}


function getClearLibraryListingPlanForUnderstanding(message = "", selectedRegion = "") {
  const text = stripKoreanRequestTail(String(message || "").trim().toLowerCase())
    .replace(/[?？!！.。]+$/u, "")
    .replace(/\s+/g, " ")
    .trim();
  if (!text || !/(?:도서관|작은\s*도서관|문고)/u.test(text)) return null;

  // “중구 데미안 있는 도서관”처럼 도서관 앞에 책 제목이 섞인 소장 요청은 여기서 처리하지 않는다.
  if (/(?:소장|보유|대출|대여|구비|비치|빌릴|빌리는|찾을\s*수|구할\s*수|볼\s*수|읽을\s*수)/u.test(text)) return null;

  const libraryNoun = "(?:공공\\s*)?(?:작은\\s*)?도서관|문고";
  const match = text.match(new RegExp(`^(.{1,40}?)(?:에|에서|에는|에서는|의)?\\s*(?:있는|소재(?:한)?|위치(?:한)?|가까운|근처|주변|인근)?\\s*(?:${libraryNoun})$`, "u"));
  if (!match?.[1]) return null;

  const prefix = String(match[1] || "").replace(/\s+/g, " ").trim();
  if (!prefix) return null;
  if (/\s+있는$/u.test(prefix)) return null;
  if (/(?:책|도서(?!관)|자료)$/u.test(prefix)) return null;

  const info = getGenericLibraryRegionPrefixInfo(prefix, selectedRegion) || getLooseAreaAliasHint(prefix, selectedRegion) || getDetailedRegionAliasHint(prefix, selectedRegion);
  if (!info) return null;

  const regionHint = info.regionHint || prefix;
  const region = sanitizeRegionCode(info.region || getRegionCodeFromText(regionHint, selectedRegion) || selectedRegion || "");
  if (!selectedRegion && (info.ambiguous || (!region && isAmbiguousLocalRegionName(regionHint)))) {
    return buildAmbiguousLocalRegionLibrarySearchPlan(regionHint, text, selectedRegion);
  }

  const normalizedQuery = `${prefix} 도서관`.replace(/\s+/g, " ").trim();
  return {
    intent: "library_search",
    normalizedQuery,
    libraryName: "",
    regionHint,
    region,
    confidence: 0.93,
    source: "rule",
    reason: "지역/장소 기준 도서관 목록을 찾는 명확한 표현",
    filters: regionHint ? [{ field: "libraryAddressOrName", op: "contains_any", values: [regionHint] }] : []
  };
}

function getAmbiguousLocalRegionFromLibraryNameForUnderstanding(libraryName = "") {
  const raw = String(libraryName || "").replace(/\s+/g, " ").trim();
  if (!raw) return "";
  const stem = normalizeUnderstandingAreaToken(raw.replace(/(?:작은\s*도서관|도서관|문고)$/u, "").trim());
  if (!stem) return "";
  if (isAmbiguousLocalRegionName(stem)) return stem;
  const tokens = stem.split(/\s+/u).filter(Boolean);
  if (tokens.length === 1 && isAmbiguousLocalRegionName(tokens[0])) return tokens[0];
  return "";
}

function getCompoundRegionAliasHint(value = "") {
  const token = normalizeSearchText(normalizeUnderstandingAreaToken(value));
  if (!token) return null;

  if (/^(?:경기|경기도)광주시?$/.test(token)) {
    return { regionHint: "광주", region: "31", dtlRegion: "31250", districtName: "광주시", specific: true, compound: true };
  }
  if (/^(?:전북|전라북도)전주시?$/.test(token)) {
    return { regionHint: "전주", region: "35", districtName: "전주시", specific: true, compound: true };
  }
  if (/^(?:경남|경상남도)통영시?$/.test(token)) {
    return { regionHint: "통영", region: "38", districtName: "통영시", specific: true, compound: true };
  }
  if (/^(?:충남|충청남도)천안시?$/.test(token)) {
    return { regionHint: "천안", region: "34", districtName: "천안시", specific: true, compound: true };
  }

  return null;
}

function isLikelyFalseAdminRegionHint(text = "") {
  const compact = normalizeSearchText(text);
  return /(?:다면|라면|으면|거라면|거면|없다면|한다면|된다면|인다면|아니라면|가면|보면|하면|이면)$/.test(compact);
}

function normalizeUnderstandingAreaToken(value = "") {
  return stripTrailingKoreanParticles(
    String(value || "")
      .replace(/[,，]/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .replace(/\s*(?:근처|주변|인근|부근|쪽)\s*$/u, "")
      .replace(/\s*(?:에서는|에서|에는|에)\s*$/u, "")
      .trim()
  );
}

function getExactDetailedRegionMatchesForUnderstanding(value = "", selectedRegion = "") {
  const token = normalizeUnderstandingAreaToken(value);
  const normalizedToken = normalizeSearchText(token);
  if (!normalizedToken || !Array.isArray(DETAILED_REGION_MAP)) return [];

  const matches = DETAILED_REGION_MAP.filter((item) => {
    const hasExclude = item.exclude?.some((ex) => normalizedToken.includes(normalizeSearchText(ex)));
    if (hasExclude) return false;
    return item.names.some((name) => normalizeSearchText(name) === normalizedToken);
  });

  const region = sanitizeRegionCode(selectedRegion || "");
  const regionalMatches = region ? matches.filter((item) => item.region === region) : [];
  return regionalMatches.length ? regionalMatches : matches;
}

function getCompoundDetailedRegionHint(value = "", selectedRegion = "") {
  const token = normalizeUnderstandingAreaToken(value);
  const normalizedToken = normalizeSearchText(token);
  if (!normalizedToken || normalizedToken.length < 3) return null;

  const regionEntries = Object.entries(REGION_ALIAS_TO_CODE || {})
    .map(([name, code]) => ({ name, code, normalized: normalizeSearchText(name) }))
    .filter((item) => item.normalized && item.code)
    .sort((a, b) => b.normalized.length - a.normalized.length);

  for (const entry of regionEntries) {
    if (!normalizedToken.startsWith(entry.normalized) || normalizedToken === entry.normalized) continue;
    const remainder = normalizedToken.slice(entry.normalized.length);
    if (!remainder || remainder.length < 2) continue;

    const detail = (DETAILED_REGION_MAP || []).find((item) => {
      if (item.region !== entry.code) return false;
      return item.names.some((name) => normalizeSearchText(name) === remainder);
    });

    if (detail) {
      const matchedName = detail.names.find((name) => normalizeSearchText(name) === remainder) || detail.districtName || remainder;
      return {
        regionHint: matchedName,
        region: detail.region,
        dtlRegion: detail.dtlRegion,
        districtName: detail.districtName,
        specific: true,
        compound: true
      };
    }
  }

  return null;
}

function getBroadRegionHintForUnderstanding(value = "") {
  const token = normalizeUnderstandingAreaToken(value);
  const normalizedToken = normalizeSearchText(token);
  if (!normalizedToken) return null;
  const regionCode = REGION_NAME_TO_CODE?.[normalizedToken] || "";
  if (!regionCode) return null;
  return { regionHint: token, region: regionCode, specific: false, broad: true };
}

function getDetailedRegionAliasHint(value = "", selectedRegion = "") {
  const token = normalizeUnderstandingAreaToken(value);
  const normalizedToken = normalizeSearchText(token);
  if (!normalizedToken || normalizedToken.length < 2) return null;
  if (isLikelyFalseAdminRegionHint(normalizedToken)) return null;

  const compound = getCompoundDetailedRegionHint(token, selectedRegion);
  if (compound) return compound;

  const selected = sanitizeRegionCode(selectedRegion || "");
  const broad = getBroadRegionHintForUnderstanding(token);
  if (!selected && broad && !/(?:구|군|동|읍|면)$/u.test(token)) return broad;

  const directPlace = UNDERSTANDING_PLACE_ALIAS_HINTS.find((item) =>
    item.names.some((name) => normalizeSearchText(name) === normalizedToken)
  );
  if (directPlace) {
    return {
      regionHint: directPlace.regionHint || token,
      region: directPlace.region,
      districtName: directPlace.districtName || "",
      specific: true,
      place: true
    };
  }

  const allMatches = getExactDetailedRegionMatchesForUnderstanding(token, "");
  const selectedMatches = selected ? allMatches.filter((item) => item.region === selected) : [];

  // 서구/중구/남구/북구/동구처럼 여러 시도에 있는 구 이름은
  // 선택 지역이 없으면 시도를 확정하지 않는다. 선택 지역이 있어도
  // 그 선택 지역 안에 해당 구가 없으면 다른 시도로 자동 보정하지 않는다.
  if (allMatches.length > 1 && isAmbiguousLocalRegionName(token)) {
    if (!selected) {
      return { regionHint: token, region: "", dtlRegion: "", districtName: token, specific: true, ambiguous: true };
    }
    if (selected && selectedMatches.length === 0) {
      return { regionHint: token, region: "", dtlRegion: "", districtName: token, specific: true, ambiguous: true, invalidForSelected: true };
    }
  }

  const matches = selectedMatches.length ? selectedMatches : allMatches;

  const detail = matches[0];
  if (detail) {
    return {
      regionHint: token,
      region: detail.region,
      dtlRegion: detail.dtlRegion,
      districtName: detail.districtName,
      specific: true
    };
  }

  if (broad) return broad;

  return null;
}

function getLooseAreaAliasHint(value = "", selectedRegion = "") {
  const direct = getDetailedRegionAliasHint(value, selectedRegion);
  if (direct) return direct;

  const token = normalizeUnderstandingAreaToken(value);
  const normalizedToken = normalizeSearchText(token);
  if (!normalizedToken || normalizedToken.length < 2) return null;

  const selected = sanitizeRegionCode(selectedRegion || "");
  const broadRegion = getBroadRegionHintForUnderstanding(token);
  const contextRegion = selected || broadRegion?.region || "";

  const placeMatches = UNDERSTANDING_PLACE_ALIAS_HINTS
    .flatMap((item) => item.names.map((name) => ({ item, name, normalized: normalizeSearchText(name) })))
    .filter(({ item, normalized }) => normalized && normalizedToken.endsWith(normalized) && (!contextRegion || item.region === contextRegion))
    .sort((a, b) => b.normalized.length - a.normalized.length);

  if (placeMatches.length > 0) {
    const { item, name } = placeMatches[0];
    return {
      regionHint: item.regionHint || name,
      region: item.region,
      districtName: item.districtName || "",
      specific: true,
      place: true
    };
  }

  const detailMatches = (DETAILED_REGION_MAP || [])
    .flatMap((item) => item.names.map((name) => ({ item, name, normalized: normalizeSearchText(name) })))
    .filter(({ item, normalized }) => normalized && normalizedToken.endsWith(normalized) && (!contextRegion || item.region === contextRegion))
    .sort((a, b) => b.normalized.length - a.normalized.length);

  if (detailMatches.length > 0) {
    const { item, name } = detailMatches[0];
    return {
      regionHint: name,
      region: item.region,
      dtlRegion: item.dtlRegion,
      districtName: item.districtName,
      specific: true
    };
  }

  return null;
}

function isDetailedRegionAliasOnlyForUnderstanding(message = "", selectedRegion = "") {
  const token = normalizeUnderstandingAreaToken(String(message || "").replace(/[?？!！.。]+$/u, ""));
  return Boolean(getDetailedRegionAliasHint(token, selectedRegion));
}

function setAvailabilityRegionHint(currentHint = "", candidateHint = "", isSpecific = false) {
  const cleaned = normalizeUnderstandingAreaToken(candidateHint);
  if (!cleaned) return currentHint || "";
  if (!currentHint) return cleaned;
  if (isSpecific) return cleaned;
  return currentHint;
}

function looksLikeTitleWithLocationParticle(text = "") {
  const value = String(text || "").trim();
  // “광주에서 온 편지”, “부평에서 온 사람”처럼 지역 조사처럼 보여도 제목 일부인 표현은 보존한다.
  return /^[가-힣0-9]{2,12}(?:에서는|에서|에는|에)\s+온\s+.{1,}$/u.test(value);
}


const TRUSTED_SPACED_LIBRARY_STEMS_FOR_UNDERSTANDING = new Set(["정독"].map((item) => normalizeSearchText(item)));

function isTrustedSpacedLibraryStemForUnderstanding(stem = "") {
  return TRUSTED_SPACED_LIBRARY_STEMS_FOR_UNDERSTANDING.has(normalizeSearchText(stem));
}

function isKnownStandardLibraryNameForUnderstanding(name = "") {
  const text = String(name || "").replace(/\s+/g, " ").trim();
  if (!text) return false;
  const normalized = normalizeSearchText(text);
  const compact = normalizeSearchText(text.replace(/\s+/g, ""));
  if (!normalized && !compact) return false;
  return (standardLibraryDb || []).some((lib) => {
    const libName = normalizeSearchText(lib?.name || "");
    if (!libName) return false;
    return libName === normalized || libName === compact;
  });
}

function isSafeSpacedLibraryNameForUnderstanding(name = "") {
  const text = String(name || "").replace(/\s+/g, " ").trim();
  if (!text || !/\s/u.test(text)) return false;
  if (isKnownStandardLibraryNameForUnderstanding(text)) return true;
  const stem = text.replace(/(?:도서관|작은\s*도서관|문고)$/u, "").trim();
  if (isTrustedSpacedLibraryStemForUnderstanding(stem)) return true;
  return /^(?:국립|시립|구립|군립|도립|교육청|공립|사립|어린이|작은|학교|대학|대학교|공공)\s*.+(?:도서관|문고)$/u.test(text);
}

function looksLikeTrustedSpecificLibraryNameForUnderstanding(name = "") {
  const text = String(name || "").replace(/\s+/g, " ").trim();
  if (!text) return false;
  if (!/(?:도서관|작은\s*도서관|문고)$/u.test(text)) return false;
  if (isKnownStandardLibraryNameForUnderstanding(text)) return true;
  // “정독도서관”, “강남구립못골도서관”처럼 붙여 쓴 공식명은 기본 신뢰한다.
  // “정독 도서관”처럼 띄어 쓴 명칭은 표준 DB 또는 공공/시립/구립 같은 강한 신호가 있을 때만 신뢰한다.
  if (!/\s/u.test(text.replace(/작은\s*도서관/u, "작은도서관"))) return true;
  return isSafeSpacedLibraryNameForUnderstanding(text);
}

function looksLikeLikelySpacedSpecificLibraryStem(stem = "", selectedRegion = "") {
  const token = String(stem || "").replace(/\s+/g, " ").trim();
  if (!token) return false;
  if (getBroadRegionHintForUnderstanding(token) || getDetailedRegionAliasHint(token, selectedRegion)) return true;
  if (/^(?:국립|시립|구립|군립|도립|교육청|공립|사립|어린이|작은|학교|대학|대학교|공공|중앙|대표)/u.test(token)) return true;
  // 자주 띄어 쓰는 공공도서관 축약명. 실제 DB 조회 전 단계의 보수적 보정이다.
  if (/^(?:정독|남산|송파|마포|서대문|양천|노원|강남|강동|강서|강북|종로|중랑|동작|관악|은평|광진|도봉|성북|용산|금천|구로|동대문|서초|성동|영등포|중앙|국회)$/u.test(token)) return true;
  return false;
}

function stripWhichLibraryQualifierFromTitle(value = "") {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  if (!text) return text;
  const stripped = text.replace(/\s+(?:어느|어떤|무슨|어디)\s*$/u, "").trim();
  return stripped || text;
}

function stripGenericLibraryNounSuffixFromTitle(subject = "") {
  const text = String(subject || "").replace(/\s+/g, " ").trim();
  if (!text) return text;
  const stripped = text.replace(/\s+(?:공공\s*)?(?:작은\s*)?도서관(?:에서는|에서|에는|에)?$/u, "").trim();
  return stripped && stripped.length >= 2 ? stripped : text;
}

function hasClearBookAvailabilityLibraryPhrase(message = "") {
  return hasBookAvailabilityActionPhrase(message);
}

function isBareLibraryWhereAmbiguityCandidate(message = "") {
  const text = stripKoreanRequestTail(String(message || "").trim().toLowerCase())
    .replace(/[?？!！.。]+\s*$/u, "")
    .trim();
  if (!text) return false;
  if (hasClearBookAvailabilityLibraryPhrase(text)) return false;
  if (/(?:어느|어떤|무슨|어디)\s*도서관(?:에서|에)?\s*$/u.test(text)) return false;
  return /^.{2,}\s+도서관\s*(?:어디|어딘|어딨|위치|주소)?$/u.test(text);
}

function isExplicitBookAvailabilityLibraryRequest(message = "", extraction = null) {
  const text = stripKoreanRequestTail(String(message || "").trim().toLowerCase()).replace(/[?？!！.。]+\s*$/u, "").trim();
  if (!text || !extraction?.bookTitle) return false;
  // “데미안 있는 도서관”, “신참자 소장한 도서관”, “채식주의자 빌릴 수 있는 곳”은 책 소장 검색으로 확정한다.
  if (/(?:있는|있을)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))|(?:소장한?|소장된|소장\s*중인|보유한?|보유\s*중인|구비(?:된|한)?|비치(?:된|한)?)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))|(?:소장|보유|구비|비치)\s*도서관|대출처|대출\\s*가능(?:한)?\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?|대여\\s*가능(?:한)?\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?|대여\s*할\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?|대여\s*(?:되는|가능한?)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?|빌릴\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))|대출\s*할\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))|빌려\s*볼\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?|구할\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?|(?:빌릴|빌리는)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))|빌려\s*주는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))|찾을\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))/u.test(text)) return true;
  // “종로 산책 도서관에 있어?”처럼 도서관을 일반명사로 쓴 소장 질문도 book_availability로 본다.
  if (/\s+도서관(?:에서|에)\s*있(?:어|어요|나요|니|습니까|을까|을까요|는지|나|음)?\s*$/u.test(text)) return true;
  return false;
}

function isClearLocationPhraseLibraryQueryForUnderstanding(query = "") {
  const text = String(query || "").trim();
  if (!text || !/(?:도서관|작은\s*도서관|문고)/u.test(text)) return false;
  if (/(?:도서관|작은\s*도서관|문고)의\s+.{1,}/u.test(text) && !/(?:위치|주소|운영|이용|개관|휴관|전화|연락처|주차|와이파이|좌석|열람실)/u.test(text)) return false;
  if (hasClearBookAvailabilityLibraryPhrase(text)) return false;
  if (isKnownLocalPlaceLibraryListingQuery(text)) return true;

  const sido = "서울|부산|대구|인천|광주|대전|울산|세종|경기|강원|충북|충남|전북|전남|경북|경남|제주";
  const adminUnit = "[가-힣0-9]{1,8}(?:구|군|시|읍|면|동|리|로|길)";
  const institution = "[가-힣0-9]{1,16}(?:학교|초등학교|중학교|고등학교|대학교|대학|병원|공원|시장|구청|시청|군청|주민센터|행정복지센터|아파트|마을|광장|터미널|공항|박물관|미술관)";
  const locationToken = `(?:${sido}|${adminUnit}|${institution})`;
  const libraryNoun = "(?:공공\\s*)?(?:작은\\s*)?도서관|문고";
  const connector = "(?:\\s*(?:에|에서|의|쪽|근처|주변|인근|가까운|부근))?\\s*";
  const relation = "(?:있는|소재(?:한)?|위치(?:한)?|이용할\\s*수\\s*있는|이용\\s*가능한|갈\\s*수\\s*있는|갈\\s*만한|가기\\s*좋은|가까운|근처|주변|인근)?\\s*";

  if (new RegExp(`${locationToken}${connector}${relation}(?:${libraryNoun})`, "u").test(text)) return true;
  if (new RegExp(`(?:${sido})\\s+(?:${adminUnit}|${institution})(?:에|에서|의)?\\s*(?:있는|소재(?:한)?|위치(?:한)?|가까운|근처|주변|인근)?\\s*(?:${libraryNoun})`, "u").test(text)) return true;
  return false;
}

function isTrustedSpecificLibraryWhereQueryForUnderstanding(message = "") {
  const text = String(message || "").trim();
  const match = text.match(/^(.{2,}?(?:도서관|작은\s*도서관|문고))\s*(?:은|는|가|을|를)?\s*(?:어디|어딘|어딨|위치|주소|찾|검색)\s*[?？!！.。]*$/u);
  if (!match) return false;
  return looksLikeTrustedSpecificLibraryNameForUnderstanding(match[1] || "");
}

function isClearLibrarySearchBeforeAmbiguity(message = "") {
  const text = String(message || "").trim();
  if (!text) return false;
  if (hasClearBookAvailabilityLibraryPhrase(text)) return false;
  const possibleBookLibraryWhere = text.match(/^(.{2,})\s+도서관(?:에서|에)?\s*(?:어디|어딘|어딨|위치|있(?:어|나요|나|음)?)\s*[?？!！.。]*$/u);
  if (possibleBookLibraryWhere?.[1]) {
    const prefix = stripTrailingKoreanParticles(possibleBookLibraryWhere[1] || "");
    if (prefix && !getBroadRegionHintForUnderstanding(prefix) && !getDetailedRegionAliasHint(prefix) && !looksLikeLikelySpacedSpecificLibraryStem(prefix)) return false;
  }
  if (isLibraryRecommendationRequest(text)) return true;
  if (hasNearbyLibrarySignal(text)) return true;
  if (isGenericLocationLibraryQuery(text)) return true;
  if (isClearLocationPhraseLibraryQueryForUnderstanding(text)) return true;
  if (isTrustedSpecificLibraryWhereQueryForUnderstanding(text)) return true;
  return false;
}

function getAmbiguousBookOrLibraryWherePlan(message = "", selectedRegion = "") {
  const text = stripKoreanRequestTail(String(message || "").trim().toLowerCase())
    .replace(/[?？!！.。]+\s*$/u, "")
    .trim();
  if (!text) return null;

  if (hasBookAvailabilityActionPhrase(text)) return null;

  const match = text.match(/^(.{2,})\s+도서관(?:에서|에)?\s*(?:어디|어딘|어딨|위치|있(?:어|나요|나|음)?|찾(?:아|을)?|검색)?\s*$/u);
  if (!match) return null;

  const prefix = stripTrailingKoreanParticles(match[1] || "");
  if (!prefix || prefix.length < 2) return null;

  // “서울 도서관 어디”, “강남구 도서관 어디”는 도서관 지역 검색으로 충분히 명확하다.
  if (getBroadRegionHintForUnderstanding(prefix) || getDetailedRegionAliasHint(prefix, selectedRegion)) return null;

  const bookQuery = normalizeBookSearchKeyword(prefix);
  const libraryQuery = `${prefix} 도서관`;
  if (!bookQuery || bookQuery.length < 2) return null;

  return {
    intent: "ambiguous",
    normalizedQuery: prefix,
    confidence: 0.86,
    source: "rule",
    reason: "도서관이라는 말이 실제 도서관명인지, 책을 소장한 도서관을 묻는 말인지 애매함",
    alternatives: [
      { label: `『${bookQuery}』 소장 도서관 찾기`, intent: "book_availability", normalizedQuery: bookQuery },
      { label: `“${libraryQuery}” 도서관 검색`, intent: "library_search", normalizedQuery: libraryQuery }
    ]
  };
}

function stripLeadingContextFromAvailabilitySubject(subject = "", selectedRegion = "") {
  let cleaned = stripTrailingKoreanParticles(String(subject || "").replace(/\s+/g, " ").trim());
  cleaned = cleaned.replace(/^도서관(?:에서는|에서|에는|에)\s*(.{2,})$/u, "$1").trim();

  let libraryName = "";
  let regionHint = "";
  let regionCode = sanitizeRegionCode(selectedRegion || "");

  const broadRegionWithConnector = new RegExp(`^(${UNDERSTANDING_SIDO_PATTERN})(?:에서는|에서|에는|에)(?:\\s*있는)?\\s+(.{2,})$`, "u");
  const broadRegionBare = new RegExp(`^(${UNDERSTANDING_SIDO_PATTERN})\\s+(.{2,})$`, "u");
  const adminRegionWithConnector = new RegExp(`^(${UNDERSTANDING_ADMIN_UNIT_PATTERN})(?:에서는|에서|에는|에)(?:\\s*있는)?\\s+(.{2,})$`, "u");
  const adminRegionBareMajor = /^([가-힣0-9]+(?:구|군|시))\s+(.{2,})$/u;
  const broadRegionSuffix = new RegExp(`^(.{2,})\\s+(${UNDERSTANDING_SIDO_PATTERN})(?:에서|에|에서는|에는)?$`, "u");
  const adminRegionSuffix = new RegExp(`^(.{2,})\\s+(${UNDERSTANDING_ADMIN_UNIT_PATTERN})(?:에서|에|에서는|에는)?$`, "u");
  const compoundRegionPrefix = /^((?:경기|경기도)\s*광주시?|(?:전북|전라북도)\s*전주시?|(?:경남|경상남도)\s*통영시?|(?:충남|충청남도)\s*천안시?)(?:에서|에)?\s+(.{2,})$/u;
  const compoundRegionSuffix = /^(.{2,})\s+((?:경기|경기도)\s*광주시?|(?:전북|전라북도)\s*전주시?|(?:경남|경상남도)\s*통영시?|(?:충남|충청남도)\s*천안시?)(?:에서|에|에서는|에는)?$/u;
  const broadDetailedRegionPrefix = new RegExp(`^(${UNDERSTANDING_SIDO_PATTERN})\\s+([가-힣0-9]{1,12}(?:구|군|시|읍|면|동))(?:에서는|에서|에는|에)?(?:\\s*있는)?\\s+(.{2,})$`, "u");
  const broadDetailedRegionSuffix = new RegExp(`^(.{2,})\\s+(${UNDERSTANDING_SIDO_PATTERN})\\s+([가-힣0-9]{1,12}(?:구|군|시|읍|면|동))(?:에서|에|에서는|에는)?$`, "u");

  const getContextRegion = () => regionCode || getRegionCodeFromText(regionHint, selectedRegion) || sanitizeRegionCode(selectedRegion || "");

  const looksLikeTitleContinuation = (remaining = "", candidate = "", bareRegion = false) => {
    const rest = String(remaining || "").trim();
    const normalizedCandidate = normalizeSearchText(candidate);
    if (/^온\s+.{1,}$/u.test(rest)) return true;
    if (/^(?:도서관|작은\s*도서관|문고)의\s+.{1,}$/u.test(rest)) return true;
    if (bareRegion && !getContextRegion() && AMBIGUOUS_BOOK_REGION_TOKENS.has(normalizedCandidate) && !/(?:근처|주변|인근|부근|쪽)/u.test(rest)) return true;
    return false;
  };

  const applyRegionCandidate = (candidateRegion = "", isSpecific = false) => {
    const candidate = normalizeUnderstandingAreaToken(candidateRegion);
    if (!candidate || isLikelyFalseAdminRegionHint(candidate)) return false;

    const hint = getDetailedRegionAliasHint(candidate, getContextRegion()) || getCompoundRegionAliasHint(candidate);
    const code = hint?.invalidForSelected ? "" : (hint?.region || getRegionCodeFromText(candidate, getContextRegion()));
    if (!hint && !code) {
      if (!isSpecific) return false;
      regionHint = setAvailabilityRegionHint(regionHint, candidate, true);
      return true;
    }

    regionHint = setAvailabilityRegionHint(regionHint, hint?.regionHint || candidate, Boolean(hint?.specific || isSpecific));
    if (code) regionCode = sanitizeRegionCode(code);
    return true;
  };

  const stripRegionPrefix = () => {
    const broadDetailDongMatch = cleaned.match(new RegExp(`^(${UNDERSTANDING_SIDO_PATTERN})\\s+([가-힣0-9]{1,12}(?:구|군|시))\\s+([가-힣0-9]{1,12}(?:읍|면|동|리))(?:에서는|에서|에는|에)?(?:\\s*있는)?\\s+(.{2,})$`, "u"));
    if (broadDetailDongMatch) {
      const broad = String(broadDetailDongMatch[1] || "").trim();
      const district = String(broadDetailDongMatch[2] || "").trim();
      const detail = String(broadDetailDongMatch[3] || "").trim();
      const remaining = String(broadDetailDongMatch[4] || "").trim();
      const broadCode = getRegionCodeFromText(broad, selectedRegion);
      if (!broadCode && !getDetailedRegionAliasHint(district, selectedRegion)) return false;
      regionHint = setAvailabilityRegionHint(regionHint, detail, true);
      regionCode = sanitizeRegionCode(broadCode || getRegionCodeFromText(district, selectedRegion) || regionCode);
      cleaned = stripTrailingKoreanParticles(remaining);
      return true;
    }

    const broadDetailMatch = cleaned.match(broadDetailedRegionPrefix);
    if (broadDetailMatch) {
      const broad = String(broadDetailMatch[1] || "").trim();
      const detail = String(broadDetailMatch[2] || "").trim();
      const remaining = String(broadDetailMatch[3] || "").trim();
      const broadCode = getRegionCodeFromText(broad, selectedRegion);
      const hint = getDetailedRegionAliasHint(detail, broadCode || selectedRegion);
      if (!broadCode && !hint) return false;
      regionHint = setAvailabilityRegionHint(regionHint, hint?.regionHint || detail, true);
      regionCode = sanitizeRegionCode(hint?.region || broadCode || regionCode);
      cleaned = stripTrailingKoreanParticles(remaining);
      return true;
    }

    const compoundMatch = cleaned.match(compoundRegionPrefix);
    if (compoundMatch) {
      if (!applyRegionCandidate(compoundMatch[1], true)) return false;
      cleaned = stripTrailingKoreanParticles(compoundMatch[2]);
      return true;
    }

    const withConnector = cleaned.match(broadRegionWithConnector) || cleaned.match(adminRegionWithConnector);
    if (withConnector) {
      const candidateRegion = String(withConnector[1] || "").trim();
      const remaining = String(withConnector[2] || "").trim();
      if (looksLikeTitleContinuation(remaining, candidateRegion, false)) return false;
      const isSpecific = new RegExp(`^${UNDERSTANDING_ADMIN_UNIT_PATTERN}$`, "u").test(candidateRegion);
      if (!applyRegionCandidate(candidateRegion, isSpecific)) return false;
      cleaned = stripTrailingKoreanParticles(remaining);
      return true;
    }

    const broadBareMatch = cleaned.match(broadRegionBare);
    if (broadBareMatch) {
      const candidateRegion = String(broadBareMatch[1] || "").trim();
      const remaining = String(broadBareMatch[2] || "").trim();
      if (looksLikeTitleContinuation(remaining, candidateRegion, true)) return false;
      if (!applyRegionCandidate(candidateRegion, false)) return false;
      cleaned = stripTrailingKoreanParticles(remaining);
      return true;
    }

    const adminBareMatch = cleaned.match(adminRegionBareMajor);
    if (adminBareMatch) {
      const candidateRegion = String(adminBareMatch[1] || "").trim();
      const remaining = String(adminBareMatch[2] || "").trim();
      if (!selectedRegion && isAmbiguousLocalRegionName(candidateRegion)) return false;
      if (!applyRegionCandidate(candidateRegion, true)) return false;
      cleaned = stripTrailingKoreanParticles(remaining);
      return true;
    }

    return false;
  };

  const stripLooseAreaPrefix = () => {
    const loosePrefixMatch = cleaned.match(/^(.{2,30}?)(?:\s*(?:근처|주변|인근|부근|쪽)|(?:에서는|에서|에는|에))\s+(.{2,})$/u);
    if (!loosePrefixMatch) return false;
    const candidateRegion = String(loosePrefixMatch[1] || "").trim();
    const remaining = String(loosePrefixMatch[2] || "").trim();
    if (looksLikeTitleContinuation(remaining, candidateRegion, false)) return false;
    const hint = getLooseAreaAliasHint(candidateRegion, getContextRegion());
    if (!hint) {
      if (!/(?:근처|주변|인근|부근|쪽)/u.test(loosePrefixMatch[0] || "")) return false;
      if (!remaining || remaining.length < 2 || /(?:도서관|작은\s*도서관|문고)$/u.test(remaining)) return false;
      regionHint = setAvailabilityRegionHint(regionHint, candidateRegion, true);
      cleaned = stripTrailingKoreanParticles(remaining);
      return true;
    }
    regionHint = setAvailabilityRegionHint(regionHint, hint.regionHint, true);
    if (hint.region) regionCode = sanitizeRegionCode(hint.region);
    cleaned = stripTrailingKoreanParticles(remaining);
    return true;
  };

  const stripBareCompoundAreaPrefix = () => {
    const entries = (UNDERSTANDING_PLACE_ALIAS_HINTS || [])
      .flatMap((item) => item.names.map((name) => ({ item, name: String(name || "").replace(/\s+/g, " ").trim() })))
      .filter(({ name }) => name.includes(" "))
      .sort((a, b) => b.name.length - a.name.length);

    // “경기 성남 분당 데미안”, “경남 창원 마산 데미안”처럼 광역+복합장소+책 제목 구조는
    // 가장 세부적인 장소 힌트를 우선 사용한다.
    const broadEntries = Object.entries(REGION_ALIAS_TO_CODE || {})
      .map(([name, code]) => ({ name: String(name || "").replace(/\s+/g, " ").trim(), code }))
      .filter((entry) => entry.name && entry.code)
      .sort((a, b) => b.name.length - a.name.length);

    for (const broad of broadEntries) {
      for (const { item, name } of entries) {
        if (!name || (item.region && item.region !== broad.code)) continue;
        const prefix = `${broad.name} ${name}`.replace(/\s+/g, " ").trim();
        if (!prefix || !cleaned.startsWith(`${prefix} `)) continue;
        const remaining = cleaned.slice(prefix.length).trim();
        if (!remaining || remaining.length < 2 || /^온\s+.{1,}$/u.test(remaining)) continue;
        regionHint = setAvailabilityRegionHint(regionHint, item.regionHint || name.split(/\s+/u).pop() || name, true);
        regionCode = sanitizeRegionCode(item.region || broad.code || regionCode);
        cleaned = stripTrailingKoreanParticles(remaining);
        return true;
      }
    }

    for (const { item, name } of entries) {
      if (!name || !cleaned.startsWith(`${name} `)) continue;
      const remaining = cleaned.slice(name.length).trim();
      if (!remaining || remaining.length < 2 || /^온\s+.{1,}$/u.test(remaining)) continue;
      regionHint = setAvailabilityRegionHint(regionHint, item.regionHint || name, true);
      if (item.region) regionCode = sanitizeRegionCode(item.region);
      cleaned = stripTrailingKoreanParticles(remaining);
      return true;
    }
    return false;
  };

  const stripLibraryPrefix = () => {
    const libraryPrefixMatch =
      cleaned.match(/^(.{2,}?(?:도서관|작은\s*도서관|문고))(?:에서는|에서|에는|에)\s*(.{2,})$/u)
      || cleaned.match(/^(.{2,}?(?:도서관|작은\s*도서관|문고))\s+(.{2,})$/u);
    if (!libraryPrefixMatch) return false;
    let candidateLibrary = stripTrailingKoreanParticles(libraryPrefixMatch[1]);
    const originalCandidateLibrary = candidateLibrary;
    const leadingRegionForLibrary = candidateLibrary.match(/^([가-힣0-9]{2,12})\s+(.{2,}?(?:도서관|작은\s*도서관|문고))$/u);
    if (leadingRegionForLibrary?.[1] && leadingRegionForLibrary?.[2]) {
      const possibleRegion = leadingRegionForLibrary[1].trim();
      const possibleLibrary = leadingRegionForLibrary[2].trim();
      if (getLooseAreaAliasHint(possibleRegion, getContextRegion()) || getDetailedRegionAliasHint(possibleRegion, getContextRegion()) || getBroadRegionHintForUnderstanding(possibleRegion)) {
        candidateLibrary = `${possibleRegion} ${possibleLibrary}`.replace(/\s+/g, " ").trim();
      }
    }
    if (regionHint && !normalizeSearchText(candidateLibrary).includes(normalizeSearchText(regionHint)) && /^(?:중앙|시립|구립|군립|도립|교육청|공공|대표|어린이|작은)\s*(?:도서관|작은\s*도서관|문고)$/u.test(candidateLibrary)) {
      const withRegion = `${regionHint} ${candidateLibrary}`.replace(/\s+/g, " ").trim();
      candidateLibrary = withRegion;
    }
    if (!looksLikeTrustedSpecificLibraryNameForUnderstanding(candidateLibrary) && !looksLikeTrustedSpecificLibraryNameForUnderstanding(originalCandidateLibrary)) return false;
    libraryName = libraryName || candidateLibrary;
    cleaned = stripTrailingKoreanParticles(libraryPrefixMatch[2]);
    return true;
  };

  const stripRegionSuffix = () => {
    const broadDetailMatch = cleaned.match(broadDetailedRegionSuffix);
    if (broadDetailMatch) {
      const candidateTitle = stripTrailingKoreanParticles(broadDetailMatch[1]);
      const broad = String(broadDetailMatch[2] || "").trim();
      const detail = String(broadDetailMatch[3] || "").trim();
      if (!candidateTitle || candidateTitle.length < 2) return false;
      const broadCode = getRegionCodeFromText(broad, selectedRegion);
      const hint = getDetailedRegionAliasHint(detail, broadCode || selectedRegion);
      if (!broadCode && !hint) return false;
      regionHint = setAvailabilityRegionHint(regionHint, hint?.regionHint || detail, true);
      regionCode = sanitizeRegionCode(hint?.region || broadCode || regionCode);
      cleaned = candidateTitle;
      return true;
    }

    const compoundMatch = cleaned.match(compoundRegionSuffix);
    if (compoundMatch) {
      const candidateTitle = stripTrailingKoreanParticles(compoundMatch[1]);
      if (!candidateTitle || candidateTitle.length < 2) return false;
      if (!applyRegionCandidate(compoundMatch[2], true)) return false;
      cleaned = candidateTitle;
      return true;
    }

    const regionMatch = cleaned.match(broadRegionSuffix) || cleaned.match(adminRegionSuffix);
    if (!regionMatch) return false;
    const candidateTitle = stripTrailingKoreanParticles(regionMatch[1]);
    const candidateRegion = String(regionMatch[2] || "").trim();
    if (!candidateTitle || candidateTitle.length < 2 || !candidateRegion) return false;
    if (!selectedRegion && isAmbiguousLocalRegionName(candidateRegion)) return false;
    const isSpecific = new RegExp(`^${UNDERSTANDING_ADMIN_UNIT_PATTERN}$`, "u").test(candidateRegion);
    if (!applyRegionCandidate(candidateRegion, isSpecific)) return false;
    cleaned = candidateTitle;
    return true;
  };

  const stripLooseAreaSuffix = () => {
    const looseSuffixMatch = cleaned.match(/^(.{2,}?)\s+([가-힣0-9]{2,12})(?:\s*(?:근처|주변|인근|부근|쪽)|(?:에서는|에서|에는|에))?$/u);
    if (!looseSuffixMatch) return false;
    const candidateTitle = stripTrailingKoreanParticles(looseSuffixMatch[1]);
    const candidateRegion = String(looseSuffixMatch[2] || "").trim();
    const hint = getDetailedRegionAliasHint(candidateRegion, getContextRegion());
    if (!hint) {
      if (!/(?:근처|주변|인근|부근|쪽)/u.test(looseSuffixMatch[0] || "")) return false;
      if (!candidateTitle || candidateTitle.length < 2) return false;
      regionHint = setAvailabilityRegionHint(regionHint, candidateRegion, true);
      cleaned = candidateTitle;
      return true;
    }
    if (!candidateTitle || candidateTitle.length < 2) return false;
    regionHint = setAvailabilityRegionHint(regionHint, hint.regionHint, true);
    if (hint.region) regionCode = sanitizeRegionCode(hint.region);
    cleaned = candidateTitle;
    return true;
  };

  const stripLibrarySuffix = () => {
    const librarySuffixMatch = cleaned.match(/^(.{2,})\s+(.{2,}?(?:도서관|작은\s*도서관|문고))(?:에서는|에서|에는|에)?$/u);
    if (!librarySuffixMatch) return false;
    const candidateTitle = stripTrailingKoreanParticles(librarySuffixMatch[1]);
    const candidateLibrary = stripTrailingKoreanParticles(librarySuffixMatch[2]);
    if (!candidateTitle || candidateTitle.length < 2 || !candidateLibrary) return false;
    if (!looksLikeTrustedSpecificLibraryNameForUnderstanding(candidateLibrary)) return false;
    libraryName = libraryName || candidateLibrary;
    cleaned = candidateTitle;
    return true;
  };

  const applyLooseResidualLocation = (locationText = "", titleText = "", allowFallbackPlace = false) => {
    const title = stripTrailingKoreanParticles(String(titleText || "").trim());
    if (!title || title.length < 2) return false;
    if (/^(?:온|사는|살던|떠난|태어난)\s+.{1,}$/u.test(title)) return false;

    const location = normalizeUnderstandingAreaToken(locationText);
    if (!location || location.length < 2) return false;
    const hint = getLooseAreaAliasHint(location, getContextRegion()) || getDetailedRegionAliasHint(location, getContextRegion());
    if (!hint && !allowFallbackPlace) return false;
    const fallbackHint = location.split(/\s+/u).filter(Boolean).pop() || location;

    regionHint = setAvailabilityRegionHint(regionHint, hint?.regionHint || fallbackHint, true);
    if (hint?.region) regionCode = sanitizeRegionCode(hint.region);
    cleaned = title;
    return true;
  };

  const stripResidualLocationPrefix = () => {
    if (looksLikeTitleWithLocationParticle(cleaned)) return false;
    const match = cleaned.match(/^(.{2,50}?)(?:\s*(근처|주변|인근|부근|쪽)|(에서는|에서|에는|에))\s+(.{2,})$/u);
    if (!match) return false;
    const allowFallbackPlace = Boolean(match[2]);
    return applyLooseResidualLocation(match[1], match[4], allowFallbackPlace);
  };

  const stripResidualLocationSuffix = () => {
    const match = cleaned.match(/^(.{2,})\s+(.{2,50}?)(?:\s*(근처|주변|인근|부근|쪽)|(에서는|에서|에는|에))$/u);
    if (!match) return false;
    const title = String(match[1] || "").trim();
    if (looksLikeTitleWithLocationParticle(`${match[2]} ${title}`)) return false;
    const allowFallbackPlace = Boolean(match[3]);
    return applyLooseResidualLocation(match[2], title, allowFallbackPlace);
  };

  const stripAudienceContextPrefix = () => {
    const match = cleaned.match(/^(?:아이랑|아이와|아이와\s*함께|어린이와|초등학생(?:이랑|과)?|청소년(?:이랑|과)?)\s+(.{2,})$/u);
    if (!match) return false;
    const remaining = stripTrailingKoreanParticles(match[1]);
    if (!remaining || remaining.length < 2) return false;
    cleaned = remaining;
    return true;
  };

  const stripTripleLooseAreaPrefix = () => {
    const match = cleaned.match(/^([가-힣0-9]{2,12})\s+([가-힣0-9]{2,12})\s+([가-힣0-9]{2,12})\s+(.{2,})$/u);
    if (!match) return false;
    const first = String(match[1] || "").trim();
    const second = String(match[2] || "").trim();
    const third = String(match[3] || "").trim();
    const remaining = String(match[4] || "").trim();
    if (!remaining || remaining.length < 2) return false;
    const broadCode = getRegionCodeFromText(first, selectedRegion) || selectedRegion || "";
    const candidates = [
      `${first} ${second} ${third}`,
      `${second} ${third}`,
      third
    ];
    let hint = null;
    for (const candidate of candidates) {
      hint = getLooseAreaAliasHint(candidate, broadCode) || getDetailedRegionAliasHint(candidate, broadCode);
      if (hint) break;
    }
    if (!hint && broadCode && /(?:읍|면|동|리)$/u.test(third) && (/(?:구|군|시)$/u.test(second) || getLooseAreaAliasHint(second, broadCode) || getDetailedRegionAliasHint(second, broadCode))) {
      hint = { regionHint: third, region: broadCode, specific: true };
    }
    if (!hint) return false;
    if (looksLikeTitleContinuation(remaining, `${first} ${second} ${third}`, true)) return false;
    regionHint = setAvailabilityRegionHint(regionHint, hint.regionHint || third, true);
    if (hint.region || broadCode) regionCode = sanitizeRegionCode(hint.region || broadCode);
    cleaned = stripTrailingKoreanParticles(remaining);
    return true;
  };

  const stripBroadCompoundLooseAreaPrefix = () => {
    const match = cleaned.match(new RegExp(`^(${UNDERSTANDING_SIDO_PATTERN})\\s+([가-힣0-9]{2,12})\\s+([가-힣0-9]{2,12})\\s+(.{2,})$`, "u"));
    if (!match) return false;
    const broad = String(match[1] || "").trim();
    const firstLocal = String(match[2] || "").trim();
    const secondLocal = String(match[3] || "").trim();
    const remaining = String(match[4] || "").trim();
    if (!remaining || remaining.length < 2) return false;
    const broadCode = getRegionCodeFromText(broad, selectedRegion) || getBroadRegionHintForUnderstanding(broad)?.region || "";
    const combined = `${firstLocal} ${secondLocal}`.trim();
    const hint = getLooseAreaAliasHint(combined, broadCode || selectedRegion)
      || getDetailedRegionAliasHint(combined, broadCode || selectedRegion)
      || getLooseAreaAliasHint(secondLocal, broadCode || selectedRegion)
      || getDetailedRegionAliasHint(secondLocal, broadCode || selectedRegion);
    if (!hint && !broadCode) return false;
    regionHint = setAvailabilityRegionHint(regionHint, hint?.regionHint || secondLocal, true);
    regionCode = sanitizeRegionCode(hint?.region || broadCode || regionCode);
    cleaned = stripTrailingKoreanParticles(remaining);
    return true;
  };


  const stripKnownBareAreaPrefix = () => {
    const match = cleaned.match(/^([가-힣0-9]{2,12}(?:동|읍|면|리|구)?|[가-힣0-9]{2,12})\s+(.{2,})$/u);
    if (!match) return false;
    const candidateRegion = String(match[1] || "").trim();
    const remaining = String(match[2] || "").trim();
    if (!remaining || remaining.length < 2) return false;
    if (/^(?:산책|아리랑|사람들|온\s+.{1,}|앞은\s+.{1,}|도서관의\s+.{1,})/u.test(remaining)) return false;
    const hint = getLooseAreaAliasHint(candidateRegion, getContextRegion()) || getDetailedRegionAliasHint(candidateRegion, getContextRegion());
    if (!hint) return false;
    regionHint = setAvailabilityRegionHint(regionHint, hint.regionHint || candidateRegion, true);
    if (hint.region) regionCode = sanitizeRegionCode(hint.region);
    cleaned = stripTrailingKoreanParticles(remaining);
    return true;
  };

  const stripCompoundLooseAreaPrefix = () => {
    const match = cleaned.match(/^([가-힣0-9]{2,12})\s+([가-힣0-9]{2,12})\s+(.{2,})$/u);
    if (!match) return false;
    const combined = `${match[1]} ${match[2]}`.trim();
    const remaining = String(match[3] || "").trim();
    if (!remaining || remaining.length < 2) return false;
    if (looksLikeTitleContinuation(remaining, combined, true)) return false;
    const hint = getLooseAreaAliasHint(combined, getContextRegion()) || getDetailedRegionAliasHint(combined, getContextRegion());
    if (!hint) return false;
    regionHint = setAvailabilityRegionHint(regionHint, hint.regionHint || match[2], true);
    if (hint.region) regionCode = sanitizeRegionCode(hint.region);
    cleaned = stripTrailingKoreanParticles(remaining);
    return true;
  };

  // 지역/도서관명이 제목 앞뒤에 붙을 수 있어 접두어와 접미어를 번갈아 제거한다.
  // 단, “광주 아리랑”, “잠실동 사람들”처럼 제목 일부일 수 있는 무접속 지명은 보수적으로 보존한다.
  for (let i = 0; i < 5; i += 1) {
    const before = cleaned;
    stripAudienceContextPrefix();
    stripBroadCompoundLooseAreaPrefix();
    stripTripleLooseAreaPrefix();
    stripBroadCompoundLooseAreaPrefix();
    stripCompoundLooseAreaPrefix();
    stripKnownBareAreaPrefix();
    stripRegionPrefix();
    stripLooseAreaPrefix();
    stripBareCompoundAreaPrefix();
    stripResidualLocationPrefix();
    stripLibraryPrefix();
    stripLibrarySuffix();
    stripRegionSuffix();
    stripLooseAreaSuffix();
    stripResidualLocationSuffix();
    if (before === cleaned) break;
  }

  if (regionHint) {
    cleaned = String(cleaned || "").replace(/^(?:있는|소재한|위치한)\s+(.{1,})$/u, "$1").trim();
  }

  return { bookTitle: cleaned, libraryName, regionHint, region: regionCode };
}

function isLibraryOnlyAvailabilitySubject(subject = "", selectedRegion = "") {
  const text = String(subject || "").trim();
  if (!text) return true;
  if (/(?:도서관|작은\s*도서관|문고)$/u.test(text)) return true;
  if (isStrongLibrarySearchIntent(text)) return true;
  if (isAmbiguousRegionOnlyQueryForUnderstanding(text, selectedRegion)) return true;
  return false;
}


function extractTrailingWhereTitleCandidate(message = "") {
  const text = stripKoreanRequestTail(String(message || "").trim().toLowerCase())
    .replace(/[?？!！.。]+\s*$/u, "")
    .trim();
  if (!text) return "";

  const patterns = [
    /^(.+)\s+어디(?:에서|서|에)?\s*$/u,
    /^(.+)\s+어딘(?:데|지|가요?|가)?\s*$/u,
    /^(.+)\s+어딨(?:어|어요|나요|니|냐|습니까|는데)?\s*$/u
  ];

  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (!match?.[1]) continue;
    const candidate = stripTrailingKoreanParticles(match[1].trim());
    if (candidate && (Array.from(candidate).length >= 1) && !isLibraryOnlyAvailabilitySubject(candidate, "")) {
      return candidate;
    }
  }
  return "";
}


function getGenericLibraryRegionPrefixInfo(prefix = "", selectedRegion = "") {
  const raw = String(prefix || "").replace(/\s+/g, " ").trim();
  const token = normalizeUnderstandingAreaToken(raw);
  if (!token) return null;
  const broadDetailDong = token.match(new RegExp(`^(${UNDERSTANDING_SIDO_PATTERN})\\s+([가-힣0-9]{1,12}(?:구|군|시))\\s+([가-힣0-9]{1,12}(?:읍|면|동|리))$`, "u"));
  if (broadDetailDong) {
    const broadCode = getRegionCodeFromText(broadDetailDong[1], selectedRegion);
    return { regionHint: broadDetailDong[3], region: broadCode || getRegionCodeFromText(broadDetailDong[2], selectedRegion) || "", specific: true };
  }
  const broadDetail = token.match(new RegExp(`^(${UNDERSTANDING_SIDO_PATTERN})\\s+([가-힣0-9]{1,12}(?:구|군|시|읍|면|동))$`, "u"));
  if (broadDetail) {
    const broadCode = getRegionCodeFromText(broadDetail[1], selectedRegion);
    const localHint = broadDetail[2];
    if (broadCode && isAmbiguousLocalRegionName(localHint) && !isValidBroadRegionLocalPair(broadCode, localHint)) {
      return { regionHint: localHint, region: "", specific: true, ambiguous: true, invalidBroadLocalPair: true };
    }
    const hint = getDetailedRegionAliasHint(localHint, broadCode || selectedRegion);
    return { regionHint: hint?.regionHint || localHint, region: hint?.region || broadCode || "", specific: true, ambiguous: Boolean(hint?.ambiguous) };
  }

  // “마포 중앙”처럼 특정 도서관명 stem일 수 있는 다어절 표현은 지역 prefix로 단정하지 않는다.
  if (/\s/u.test(token)) return null;

  const broadCode = getRegionCodeFromText(token, selectedRegion);
  if (broadCode) return { regionHint: token, region: broadCode, specific: false };
  if (new RegExp(`^${UNDERSTANDING_ADMIN_UNIT_PATTERN}$`, "u").test(token)) {
    const hint = getDetailedRegionAliasHint(token, selectedRegion);
    return {
      regionHint: hint?.regionHint || token,
      region: hint?.invalidForSelected ? "" : (hint?.region || getRegionCodeFromText(token, selectedRegion) || ""),
      specific: true,
      ambiguous: Boolean(hint?.ambiguous || hint?.invalidForSelected || (!selectedRegion && isAmbiguousLocalRegionName(token))),
      invalidForSelected: Boolean(hint?.invalidForSelected)
    };
  }
  const detailed = getDetailedRegionAliasHint(token, selectedRegion) || getLooseAreaAliasHint(token, selectedRegion);
  if (detailed) return { regionHint: detailed.regionHint || token, region: detailed.invalidForSelected ? "" : (detailed.region || ""), specific: true, ambiguous: Boolean(detailed.ambiguous || detailed.invalidForSelected || (!selectedRegion && isAmbiguousLocalRegionName(token))), invalidForSelected: Boolean(detailed.invalidForSelected) };
  return null;
}

function looksLikeSpecificLibraryNameCandidateForAvailability(name = "", selectedRegion = "") {
  const libraryName = String(name || "").replace(/\s+/g, " ").trim();
  if (!libraryName || !/(?:도서관|작은\s*도서관|문고)$/u.test(libraryName)) return false;
  if (looksLikeTrustedSpecificLibraryNameForUnderstanding(libraryName) || isSafeSpacedLibraryNameForUnderstanding(libraryName) || isKnownStandardLibraryNameForUnderstanding(libraryName)) return true;
  const stem = libraryName.replace(/(?:도서관|작은\s*도서관|문고)$/u, "").trim();
  if (!stem) return false;
  if (looksLikeLikelySpacedSpecificLibraryStem(stem, selectedRegion)) return true;
  const parts = stem.split(/\s+/u).filter(Boolean);
  if (parts.length >= 2) {
    const first = parts[0];
    const rest = parts.slice(1).join(" ");
    const firstLooksLocal = Boolean(getBroadRegionHintForUnderstanding(first) || getDetailedRegionAliasHint(first, selectedRegion) || getLooseAreaAliasHint(first, selectedRegion) || looksLikeLikelySpacedSpecificLibraryStem(first, selectedRegion));
    if (firstLooksLocal && /^(?:중앙|시립|구립|군립|도립|대표|공공|어린이|작은|정보|교육|문화|디지털|마을|시민|종합)(?:\s|$)/u.test(rest)) return true;
  }
  return false;
}

function getGenericLibraryBookAvailabilityPlan(message = "", selectedRegion = "") {
  const text = stripKoreanRequestTail(String(message || "").trim().toLowerCase()).replace(/[?？!！.。]+$/u, "").replace(/\s+/g, " ").trim();
  if (!text) return null;
  const action = "(?:있(?:어|어요|나|냐|나요|습니까|니|을까|을까요|는지|음)?|소장|보유|구비|비치|대출\\s*가능(?:해|한가요|한|한지|할지|하나요|합니까)?|대출가능|대출\\s*할\\s*수\\s*있(?:어|어요|나요|니|습니까)?|대출\\s*되는|대출돼|대출되나요|대여\\s*가능|대여|빌릴\\s*수\\s*있(?:어|나요)?)";
  const match = text.match(new RegExp(`^도서관(?:에서는|에서|에는|에)?\\s+(.+?)\\s*${action}\\s*$`, "u"));
  if (!match?.[1]) return null;
  const title = normalizeAvailabilityBookTitleFinal(stripGenericLibraryNounPrefixFromTitle(match[1]), text);
  if (!title || (Array.from(title).length < 2 && !hasClearAvailabilityCueForShortTitle(text))) return null;
  return { bookTitle: title, normalizedQuery: title, libraryName: "", regionHint: "", region: "", confidence: 0.88 };
}

function getRegionGenericLibraryBookAvailabilityPlan(message = "", selectedRegion = "") {
  const text = stripKoreanRequestTail(String(message || "").trim().toLowerCase()).replace(/[?？!！.。]+$/u, "").replace(/\s+/g, " ").trim();
  if (!text) return null;
  const action = "(?:있(?:어|어요|나|냐|나요|습니까|니|을까|을까요|는지|음)?|소장|보유|구비|비치|대출\\s*가능(?:해|한가요|한|한지|할지|하나요|합니까)?|대출가능|대출\\s*할\\s*수\\s*있(?:어|어요|나요|니|습니까)?|대출\\s*되는|대출돼|대출되나요|대여\\s*가능|대여|빌릴\\s*수\\s*있(?:어|나요)?)";
  const match = text.match(new RegExp(`^(.{1,80}?)(?:\\s*(?:에\\s*있는|에서|에는|에서는|에))?\\s+도서관(?:에서는|에서|에는|에)?\\s+(.+?)\\s*${action}\\s*$`, "u"));
  if (!match?.[1] || !match?.[2]) return null;
  const prefix = normalizeUnderstandingAreaToken(match[1]);
  const regionInfo = getGenericLibraryRegionPrefixInfo(prefix, selectedRegion);
  if (!regionInfo) return null;
  const title = normalizeAvailabilityBookTitleFinal(stripGenericLibraryNounPrefixFromTitle(match[2]), text);
  if (!title || (Array.from(title).length < 2 && !hasClearAvailabilityCueForShortTitle(text))) return null;
  return {
    bookTitle: title,
    normalizedQuery: title,
    libraryName: "",
    regionHint: regionInfo.regionHint,
    region: regionInfo.region || "",
    needsRegionClarification: Boolean(regionInfo.ambiguous && !selectedRegion),
    confidence: regionInfo.ambiguous && !selectedRegion ? 0.9 : 0.91
  };
}

function getBookTrailingLibraryAvailabilityPlan(message = "", selectedRegion = "") {
  const text = stripKoreanRequestTail(String(message || "").trim().toLowerCase()).replace(/[?？!！.。]+$/u, "").replace(/\s+/g, " ").trim();
  if (!text) return null;
  const action = "(?:있(?:어|어요|나|냐|나요|습니까|니|을까|을까요|는지|음)?|소장|보유|구비|비치|대출\\s*가능(?:해|한가요|한|한지|할지|하나요|합니까)?|대출가능|대출\\s*할\\s*수\\s*있(?:어|어요|나요|니|습니까)?|대출\\s*되는|대출돼|대출되나요|대여\\s*가능|대여|빌릴\\s*수\\s*있(?:어|나요)?)";
  const match = text.match(new RegExp(`^(.+?)(?:은|는|이|가|을|를)?\\s+(.{2,60}?(?:도서관|작은\\s*도서관|문고))(?:에서는|에서|에는|에)?\\s*${action}\\s*$`, "u"));
  if (!match?.[1] || !match?.[2]) return null;
  const rawTitle = stripAvailabilityObjectParticle(match[1]);
  const rawLibrary = String(match[2] || "").replace(/\s+/g, " ").trim();
  const stem = rawLibrary.replace(/(?:도서관|작은\s*도서관|문고)$/u, "").trim();
  const regionInfo = getGenericLibraryRegionPrefixInfo(stem, selectedRegion);
  const title = normalizeAvailabilityBookTitleFinal(rawTitle, text);
  if (!title || (Array.from(title).length < 2 && !hasClearAvailabilityCueForShortTitle(text))) return null;
  if (regionInfo) return { bookTitle: title, normalizedQuery: title, libraryName: "", regionHint: regionInfo.regionHint, region: regionInfo.region || "", confidence: 0.9 };
  if (looksLikeSpecificLibraryNameCandidateForAvailability(rawLibrary, selectedRegion)) {
    const first = stem.split(/\s+/u)[0] || "";
    const hint = getLooseAreaAliasHint(first, selectedRegion) || getDetailedRegionAliasHint(first, selectedRegion);
    return { bookTitle: title, normalizedQuery: title, libraryName: rawLibrary, regionHint: hint?.regionHint || "", region: hint?.region || "", confidence: 0.91 };
  }
  return null;
}

function getCompactSpecificLibraryBookAvailabilityPlan(message = "", selectedRegion = "") {
  const text = stripKoreanRequestTail(String(message || "").trim().toLowerCase()).replace(/[?？!！.。]+$/u, "").replace(/\s+/g, " ").trim();
  if (!text || /\s/u.test(text)) return null;
  const action = "(?:있(?:어|나|나요|냐|음)?|소장|보유|구비|비치|대출가능|대출|대여가능|대여|빌릴수있(?:어|나요)?)";
  const match = text.match(new RegExp(`^(.{2,60}?도서관)(.{1,80}?)${action}$`, "u"));
  if (!match?.[1] || !match?.[2]) return null;
  const libraryName = match[1];
  if (!looksLikeTrustedSpecificLibraryNameForUnderstanding(libraryName)) return null;
  const title = normalizeAvailabilityBookTitleFinal(match[2], text);
  if (!title || (Array.from(title).length < 2 && !hasClearAvailabilityCueForShortTitle(text))) return null;
  return { bookTitle: title, normalizedQuery: title, libraryName, regionHint: "", region: "", confidence: 0.88 };
}

function getBookAvailabilityExtraction(message = "", selectedRegion = "") {
  const casualText = stripKoreanCasualPrefix(String(message || "").trim().toLowerCase());
  const text = stripKoreanRequestTail(casualText).replace(/[?？!！.。]+\s*$/u, "").trim() || casualText;
  if (!text) return null;
  if (isBareLibraryWhereAmbiguityCandidate(text)) return null;

  const compactSpecificLibraryBook = getCompactSpecificLibraryBookAvailabilityPlan(text, selectedRegion);
  if (compactSpecificLibraryBook) return compactSpecificLibraryBook;

  const genericLibraryBook = getGenericLibraryBookAvailabilityPlan(text, selectedRegion);
  if (genericLibraryBook) return genericLibraryBook;

  const regionGenericLibraryBook = getRegionGenericLibraryBookAvailabilityPlan(text, selectedRegion);
  if (regionGenericLibraryBook) return regionGenericLibraryBook;

  const bookTrailingLibrary = getBookTrailingLibraryAvailabilityPlan(text, selectedRegion);
  if (bookTrailingLibrary) return bookTrailingLibrary;


  // 예: 데미안 있는 도서관 / 중구 데미안 있는 도서관 / 서울 중구 데미안 소장한 도서관
  // “지역 + 책 + 있는 도서관”은 도서관 검색이 아니라 책 소장 검색이다.
  const subjectPlaceAvailabilityMatch = text.match(/^(.*?)\s+(?:있는|있을|소장한?|소장된|보유한?|보유\s*중인|구비(?:된|한)?|비치(?:된|한)?|대출\s*가능(?:한)?|대여\s*가능(?:한)?|빌릴\s*수\s*있는|찾을\s*수\s*있는|구할\s*수\s*있는)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))$/u);
  if (subjectPlaceAvailabilityMatch?.[1]) {
    const rawSubject = String(subjectPlaceAvailabilityMatch[1] || "")
      .replace(/(?:에|에서|에는|에서는)$/u, "")
      .replace(/\s+/g, " ")
      .trim();
    if (rawSubject && !getGenericLibraryRegionPrefixInfo(rawSubject, selectedRegion)) {
      const context = stripLeadingContextFromAvailabilitySubject(rawSubject, selectedRegion);
      const rawTitle = context?.bookTitle || rawSubject;
      const title = normalizeAvailabilityBookTitleFinal(stripAvailabilityObjectParticle(rawTitle), text);
      if (title && (Array.from(title).length >= 1) && !isLibraryOnlyAvailabilitySubject(title, selectedRegion)) {
        return {
          bookTitle: title,
          normalizedQuery: title,
          libraryName: context.libraryName || "",
          regionHint: context.regionHint || "",
          region: context.region || "",
          needsRegionClarification: Boolean(context.regionHint && !context.region && !selectedRegion && isAmbiguousLocalRegionName(context.regionHint)),
          confidence: 0.91
        };
      }
    }
  }

  if (isBookLibraryExistenceAmbiguityCandidate(text, selectedRegion)) return null;

  const compactLibraryExistence = !/\s/u.test(text)
    ? text.match(/^(.{2,50}?(?:도서관|문고))(.{1,60}?)(?:있어|있나|있음|소장|보유|대출가능|대여가능)$/u)
    : null;
  if (compactLibraryExistence?.[1] && compactLibraryExistence?.[2]) {
    const libraryName = stripTrailingKoreanParticles(compactLibraryExistence[1]);
    const title = normalizeAvailabilityBookTitleFinal(compactLibraryExistence[2], text);
    if (title && Array.from(title).length >= 1 && (looksLikeTrustedSpecificLibraryNameForUnderstanding(libraryName) || isSafeSpacedLibraryNameForUnderstanding(libraryName) || /(?:도서관|문고)$/u.test(libraryName))) {
      return { bookTitle: title, normalizedQuery: title, libraryName, regionHint: "", region: "", confidence: 0.88 };
    }
  }

  const genericLibraryContainer = text.match(/^도서관(?:에서는|에서|에는|에)?\s+(.+?)\s*(?:있(?:어|어요|나|냐|나요|습니까|니|을까|을까요|는지|음)|소장|보유|대출\s*가능|대여\s*가능|구비|비치)$/u);
  if (genericLibraryContainer?.[1]) {
    const title = normalizeAvailabilityBookTitleFinal(genericLibraryContainer[1], text);
    if (title && (Array.from(title).length >= 2 || hasClearAvailabilityCueForShortTitle(text)) && !isLibraryOnlyAvailabilitySubject(title, selectedRegion)) {
      return { bookTitle: title, normalizedQuery: title, libraryName: "", regionHint: "", region: "", confidence: 0.9 };
    }
  }

  const compactAvailabilityMatch = !/\s/u.test(text) ? text.match(/^(.{1,40}?)(?:있는|있을|소장한|소장된|보유한|구비된|비치된)도서관(?:어디|어딘|어딨|찾아줘|검색|있(?:어|나|나요|음)?)?$/u) : null;
  if (compactAvailabilityMatch?.[1]) {
    const compactTitle = stripAvailabilityObjectParticle(stripBookAvailabilityActionTail(compactAvailabilityMatch[1] || ""));
    if (compactTitle && (Array.from(compactTitle).length >= 2 || hasClearAvailabilityCueForShortTitle(text))) {
      return {
        bookTitle: compactTitle,
        normalizedQuery: compactTitle,
        libraryName: "",
        regionHint: "",
        region: "",
        confidence: 0.9
      };
    }
  }


  const bookLeadingRegionLibrary = getBookLeadingRegionLibraryAvailabilityPlan(text, selectedRegion);
  if (bookLeadingRegionLibrary) return bookLeadingRegionLibrary;

  const bookLeadingSpecificLibrary = getBookLeadingSpecificLibraryAvailabilityPlan(text, selectedRegion);
  if (bookLeadingSpecificLibrary) return bookLeadingSpecificLibrary;

  const nearbyGenericLibraryBookMatch = text.match(/^(?:내\s*)?(?:근처|주변|인근|부근|가까운)\s+도서관(?:에서는|에서|에는|에)?\s+(.+?)\s*(?:있(?:나|냐|나요|습니까|니|을까|을까요|는지|음|어|어요)?|소장|보유|대출\s*가능|대여\s*가능|구비|비치)?$/u);
  if (nearbyGenericLibraryBookMatch?.[1]) {
    const title = normalizeAvailabilityBookTitleFinal(nearbyGenericLibraryBookMatch[1], text);
    if (title && (Array.from(title).length >= 2 || hasClearAvailabilityCueForShortTitle(text))) {
      return { bookTitle: title, normalizedQuery: title, libraryName: "", regionHint: "", region: "", confidence: 0.86 };
    }
  }

  const broadDetailHasBookMatch = text.match(new RegExp(`^(${UNDERSTANDING_SIDO_PATTERN})\\s+([가-힣0-9]{1,12}(?:구|군|시|읍|면|동))(?:에|에서|에는|에서는)\\s*있는\\s+(.+?)$`, "u"));
  if (broadDetailHasBookMatch?.[1] && broadDetailHasBookMatch?.[2] && broadDetailHasBookMatch?.[3]) {
    const title = normalizeAvailabilityBookTitleFinal(broadDetailHasBookMatch[3], text);
    const broadCode = getRegionCodeFromText(broadDetailHasBookMatch[1], selectedRegion);
    const detail = broadDetailHasBookMatch[2];
    if (title && (Array.from(title).length >= 2 || hasClearAvailabilityCueForShortTitle(text))) {
      return { bookTitle: title, normalizedQuery: title, libraryName: "", regionHint: detail, region: broadCode || getRegionCodeFromText(detail, selectedRegion) || "", confidence: 0.9 };
    }
  }

  const bareRegionLibraryBookMatch = text.match(/^([가-힣0-9]{1,12}(?:구|군|시|읍|면|동))\s+도서관(?:에서는|에서|에는|에)?\s+(.+?)\s*(?:있(?:나|냐|나요|습니까|니|을까|을까요|는지|음|어|어요)?|소장|보유|대출\s*가능|대여\s*가능|구비|비치)?$/u);
  if (bareRegionLibraryBookMatch?.[1] && bareRegionLibraryBookMatch?.[2]) {
    const detail = bareRegionLibraryBookMatch[1];
    const title = normalizeAvailabilityBookTitleFinal(bareRegionLibraryBookMatch[2], text);
    if (title && (Array.from(title).length >= 2 || hasClearAvailabilityCueForShortTitle(text))) {
      const detailHint = getDetailedRegionAliasHint(detail, selectedRegion);
      return {
        bookTitle: title,
        normalizedQuery: title,
        libraryName: "",
        regionHint: detailHint?.regionHint || detail,
        region: getRegionCodeFromText(detail, selectedRegion) || detailHint?.region || "",
        needsRegionClarification: Boolean(detailHint?.ambiguous && !selectedRegion),
        confidence: detailHint?.ambiguous && !selectedRegion ? 0.89 : 0.9
      };
    }
  }

  const compactRegionLibraryBookMatch = text.match(new RegExp(`^(${UNDERSTANDING_SIDO_PATTERN})\\s+([가-힣0-9]{1,12}(?:구|군|시|읍|면|동))도서관(?:에서는|에서|에는|에)?\\s+(.+?)\\s*(?:있(?:나|냐|나요|습니까|니|을까|을까요|는지|음|어|어요)?|소장|보유|대출\\s*가능|대여\\s*가능|구비|비치)?$`, "u"));
  if (compactRegionLibraryBookMatch?.[1] && compactRegionLibraryBookMatch?.[2] && compactRegionLibraryBookMatch?.[3]) {
    const broad = compactRegionLibraryBookMatch[1];
    const detail = compactRegionLibraryBookMatch[2];
    const rawTitle = stripBookAvailabilityActionTail(compactRegionLibraryBookMatch[3]) || compactRegionLibraryBookMatch[3];
    const title = stripAvailabilityObjectParticle(stripTrailingKoreanParticles(stripGenericLibraryNounPrefixFromTitle(rawTitle)));
    const broadCode = getRegionCodeFromText(broad, selectedRegion);
    if (title && (Array.from(title).length >= 2 || hasClearAvailabilityCueForShortTitle(text))) {
      return {
        bookTitle: title,
        normalizedQuery: title,
        libraryName: `${detail}도서관`,
        regionHint: detail,
        region: broadCode || getRegionCodeFromText(detail, selectedRegion) || "",
        confidence: 0.9
      };
    }
  }

  const audienceReadingLibraryMatch = text.match(/^(?:아이랑|아이와|아이와\s*함께|어린이와|초등학생(?:이랑|과)?|청소년(?:이랑|과)?)\s+(.+?)\s+(?:읽을|볼)\s*수\s*있는\s*도서관\s*$/u);
  if (audienceReadingLibraryMatch?.[1]) {
    const bookTitle = normalizeAvailabilityBookTitleFinal(audienceReadingLibraryMatch[1], text);
    if (bookTitle && (Array.from(bookTitle).length >= 2 || hasClearAvailabilityCueForShortTitle(text))) {
      return { bookTitle, normalizedQuery: bookTitle, libraryName: "", regionHint: "", region: "", confidence: 0.87 };
    }
  }

  const earlyWhichLibraryMatch = text.match(/^(.+?)\s*(?:(?:어느|어떤|무슨|어디)\s*도서관|도서관\s*(?:어디|어느|어떤|무슨))(?:에서|에)?(?:\s*(?:있(?:어|어요|나요|니|습니까|을까|을까요|는지|나|음)?|찾(?:아|을)?|검색))?\s*$/u);
  if (earlyWhichLibraryMatch?.[1]) {
    const raw = normalizeAiProvidedBookTitleCandidate(stripBookAvailabilityActionTail(earlyWhichLibraryMatch[1]) || earlyWhichLibraryMatch[1]);
    if (raw && (Array.from(raw).length >= 2 || hasClearAvailabilityCueForShortTitle(text))) {
      const context = stripLeadingContextFromAvailabilitySubject(raw, selectedRegion);
      const bookTitle = stripTrailingKoreanParticles(stripGenericLibraryNounSuffixFromTitle(context.bookTitle || raw));
      if (bookTitle && (Array.from(bookTitle).length >= 2 || hasClearAvailabilityCueForShortTitle(text)) && !(isLibraryOnlyAvailabilitySubject(bookTitle, selectedRegion) && !context.libraryName)) {
        return {
          bookTitle,
          normalizedQuery: bookTitle,
          libraryName: context.libraryName,
          regionHint: context.regionHint,
          region: context.region || "",
          confidence: context.libraryName || context.regionHint ? 0.91 : 0.94
        };
      }
    }
  }

  const spacedLibraryBookMatch = text.match(/^([가-힣A-Za-z0-9]{2,30})\s+도서관(?:에서는|에서|에는|에)?\s+(.+?)\\s*(?:있(?:나|냐|나요|습니까|니|을까|을까요|는지|음|어|어요)?|소장|보유|대출\\s*가능|대여\\s*가능|구비|비치|빌릴\s*수\s*있(?:어|나요)?|대여|대출)?\s*$/u);
  if (spacedLibraryBookMatch?.[1] && spacedLibraryBookMatch?.[2]) {
    const candidateLibrary = `${spacedLibraryBookMatch[1]} 도서관`;
    if (isSafeSpacedLibraryNameForUnderstanding(candidateLibrary) || isKnownStandardLibraryNameForUnderstanding(`${spacedLibraryBookMatch[1]}도서관`)) {
      const bookTitle = normalizeAiProvidedBookTitleCandidate(stripBookAvailabilityActionTail(spacedLibraryBookMatch[2]) || spacedLibraryBookMatch[2]);
      if (bookTitle && (Array.from(bookTitle).length >= 2 || hasClearAvailabilityCueForShortTitle(text))) {
        return {
          bookTitle,
          normalizedQuery: bookTitle,
          libraryName: candidateLibrary,
          regionHint: "",
          region: "",
          confidence: 0.92
        };
      }
    }
  }

  const genericLibraryContainerMatch = text.match(/^(.{2,80}?)\s+도서관(?:에서|에)\s*있(?:어|어요|나요|니|습니까|을까|을까요|는지|나|음)?\s*$/u);
  if (genericLibraryContainerMatch?.[1]) {
    let candidateTitle = stripWhichLibraryQualifierFromTitle(stripTrailingKoreanParticles(stripBookAvailabilityActionTail(genericLibraryContainerMatch[1] || "")));
    // "종로 산책 도서관에 있어?"처럼 도서관이 일반명사인 경우를 책 소장 질문으로 본다.
    // "정독도서관"처럼 붙어 있는 실제 도서관명은 앞단 library_search에서 처리한다.
    if (candidateTitle && /\s/u.test(candidateTitle) && !looksLikeTrustedSpecificLibraryNameForUnderstanding(`${candidateTitle}도서관`) && !isAmbiguousRegionOnlyQueryForUnderstanding(candidateTitle, selectedRegion)) {
      return {
        bookTitle: candidateTitle,
        normalizedQuery: candidateTitle,
        libraryName: "",
        regionHint: "",
        region: "",
        confidence: 0.9
      };
    }
  }

  const genericBookInLibraryMatch = text.match(/^(.{2,})\s+도서관(?:에서|에)\s*있(?:어|어요|나요|니|습니까|을까|을까요|는지|나|음)?\s*$/u);
  if (genericBookInLibraryMatch?.[1]) {
    const title = stripWhichLibraryQualifierFromTitle(stripTrailingKoreanParticles(String(genericBookInLibraryMatch[1] || "").trim()));
    const possibleLibraryName = `${title} 도서관`;
    if (title && (Array.from(title).length >= 2 || hasClearAvailabilityCueForShortTitle(text))
      && !isAmbiguousRegionOnlyQueryForUnderstanding(title, selectedRegion)
      && !looksLikeTrustedSpecificLibraryNameForUnderstanding(possibleLibraryName)) {
      return {
        bookTitle: title,
        normalizedQuery: title,
        libraryName: "",
        regionHint: "",
        region: "",
        confidence: 0.9
      };
    }
  }

  const spacedSpecificLibraryBookMatch = text.match(/^([가-힣A-Za-z0-9]{2,30})\s+도서관(?:에서는|에서|에는|에)?\s+(.+?)\\s*(?:있(?:나|냐|나요|습니까|니|을까|을까요|는지|음|어|어요)?|소장|보유|대출\\s*가능|대여\\s*가능|구비|비치|빌릴\s*수\s*있(?:어|나요)?|대출\s*할\s*수\s*있(?:어|나요)?|대여\s*할\s*수\s*있(?:어|나요)?)?\s*$/u);
  if (spacedSpecificLibraryBookMatch?.[1] && spacedSpecificLibraryBookMatch?.[2]) {
    const prefix = normalizeUnderstandingAreaToken(spacedSpecificLibraryBookMatch[1]);
    const isRegionLikePrefix = Boolean(getBroadRegionHintForUnderstanding(prefix) || getDetailedRegionAliasHint(prefix, selectedRegion) || new RegExp(`^${UNDERSTANDING_ADMIN_UNIT_PATTERN}$`, "u").test(prefix));
    if (!isRegionLikePrefix) {
      const rawTitle = stripBookAvailabilityActionTail(spacedSpecificLibraryBookMatch[2]) || spacedSpecificLibraryBookMatch[2];
      const title = stripTrailingKoreanParticles(stripGenericLibraryNounPrefixFromTitle(rawTitle));
      if (title && (Array.from(title).length >= 2 || hasClearAvailabilityCueForShortTitle(text))) {
        return {
          bookTitle: title,
          normalizedQuery: title,
          libraryName: `${prefix} 도서관`,
          regionHint: "",
          region: "",
          confidence: 0.9
        };
      }
    }
  }

  const regionLibraryConnectorBookMatch = text.match(/^(.{1,40}?)(?:\s*(?:에\s*있는|에서|에는|에서는|에))?\s+도서관(?:에서는|에서|에는|에)\s+(.+?)\s*(?:있(?:나|냐|나요|습니까|니|을까|을까요|는지|음|어|어요)?|소장|보유|대출\s*가능|대여\s*가능|구비|비치|빌릴\s*수\s*있(?:어|나요)?|빌릴\s*수\s*있어|대출\s*할\s*수\s*있(?:어|나요)?|대여\s*할\s*수\s*있(?:어|나요)?)?\s*$/u);
  if (regionLibraryConnectorBookMatch?.[1] && regionLibraryConnectorBookMatch?.[2]) {
    const regionPart = normalizeUnderstandingAreaToken(regionLibraryConnectorBookMatch[1]);
    const rawTitle = stripBookAvailabilityActionTail(regionLibraryConnectorBookMatch[2]) || regionLibraryConnectorBookMatch[2];
    const title = normalizeAvailabilityBookTitleFinal(stripGenericLibraryNounPrefixFromTitle(rawTitle), text);
    const context = stripLeadingContextFromAvailabilitySubject(`${regionPart} ${title}`, selectedRegion);
    const regionLike = context.regionHint || getDetailedRegionAliasHint(regionPart, selectedRegion) || getRegionCodeFromText(regionPart, selectedRegion) || new RegExp(`^${UNDERSTANDING_ADMIN_UNIT_PATTERN}$`, "u").test(regionPart);
    if (title && (Array.from(title).length >= 2 || hasClearAvailabilityCueForShortTitle(text)) && regionLike) {
      return {
        bookTitle: title,
        normalizedQuery: title,
        libraryName: "",
        regionHint: context.regionHint || regionPart,
        region: context.region || getRegionCodeFromText(regionPart, selectedRegion) || "",
        confidence: 0.9
      };
    }
  }

  const regionLibraryBookMatch = text.match(/^(.{1,80}?)(?:\s*(?:에\s*있는|에서|에는|에서는|에))?\s+도서관(?:에서|에)?\s+(.+?)\\s*(?:있(?:나|냐|나요|습니까|니|을까|을까요|는지|음|어|어요)?|소장|보유|대출\\s*가능|대여\\s*가능|구비|비치|빌릴\s*수\s*있(?:어|나요)?)?\s*$/u);
  if (regionLibraryBookMatch?.[1] && regionLibraryBookMatch?.[2]) {
    const regionPart = normalizeUnderstandingAreaToken(regionLibraryBookMatch[1]);
    const titlePart = stripBookAvailabilityActionTail(regionLibraryBookMatch[2]) || regionLibraryBookMatch[2];
    const context = stripLeadingContextFromAvailabilitySubject(`${regionPart} ${titlePart}`, selectedRegion);
    const title = stripTrailingKoreanParticles(stripGenericLibraryNounPrefixFromTitle(titlePart));
    if (title && (Array.from(title).length >= 2 || hasClearAvailabilityCueForShortTitle(text)) && (context.regionHint || getDetailedRegionAliasHint(regionPart, selectedRegion) || getRegionCodeFromText(regionPart, selectedRegion) || new RegExp(`^${UNDERSTANDING_ADMIN_UNIT_PATTERN}$`, "u").test(regionPart))) {
      return {
        bookTitle: title,
        normalizedQuery: title,
        libraryName: "",
        regionHint: context.regionHint || regionPart,
        region: context.region || getRegionCodeFromText(regionPart, selectedRegion) || "",
        confidence: 0.9
      };
    }
  }

  const trailingWhereTitle = extractTrailingWhereTitleCandidate(text);
  if (trailingWhereTitle && !hasObviousAvailabilityRequestResidue(trailingWhereTitle)) {
    const context = stripLeadingContextFromAvailabilitySubject(trailingWhereTitle, selectedRegion);
    const contextTitle = context.bookTitle || trailingWhereTitle;
    // 알 수 없는 "에서/에" 내부 표현은 제목으로 보존한다. 알려진 지역/장소가 분리된 경우만 context를 반영한다.
    const preservedTitle = (context.regionHint || context.libraryName) ? contextTitle : trailingWhereTitle;
    if (preservedTitle && (Array.from(preservedTitle).length >= 2 || hasClearAvailabilityCueForShortTitle(text))) {
      return {
        bookTitle: preservedTitle,
        normalizedQuery: preservedTitle,
        libraryName: context.libraryName,
        regionHint: context.regionHint,
        region: context.region || "",
        confidence: context.libraryName || context.regionHint ? 0.9 : 0.92
      };
    }
  }

  const locatedBookMatch = text.match(/^(.{2,40}?(?:에서는|에서|에는|에))\s*있는\s+(.{2,})$/u);
  if (locatedBookMatch) {
    const contextToken = normalizeUnderstandingAreaToken(locatedBookMatch[1]);
    const maybeBook = stripTrailingKoreanParticles(String(locatedBookMatch[2] || "").trim());
    const knownContext = getLooseAreaAliasHint(contextToken, selectedRegion) || getDetailedRegionAliasHint(contextToken, selectedRegion) || looksLikeTrustedSpecificLibraryNameForUnderstanding(contextToken);
    if (knownContext && maybeBook && maybeBook.length >= 2 && !/(?:도서관|작은\s*도서관|문고)$/u.test(maybeBook)) {
      const context = stripLeadingContextFromAvailabilitySubject(`${contextToken} ${maybeBook}`, selectedRegion);
      let bookTitle = stripWhichLibraryQualifierFromTitle(stripTrailingKoreanParticles(stripGenericLibraryNounSuffixFromTitle(context.bookTitle || "")));
      if ((context.regionHint || context.libraryName) && /^도서관\s+/u.test(bookTitle)) bookTitle = stripBookAvailabilityActionTail(stripGenericLibraryNounPrefixFromTitle(bookTitle)) || stripGenericLibraryNounPrefixFromTitle(bookTitle);
      if (bookTitle && (Array.from(bookTitle).length >= 2 || hasClearAvailabilityCueForShortTitle(text)) && !(isLibraryOnlyAvailabilitySubject(bookTitle, selectedRegion) && !context.libraryName)) {
        return {
          bookTitle,
          normalizedQuery: bookTitle,
          libraryName: context.libraryName,
          regionHint: context.regionHint,
          region: context.region || "",
          confidence: context.libraryName || context.regionHint ? 0.91 : 0.9
        };
      }
    }
  }

  const whichLibraryMatch = text.match(/^(.+?)\s*(?:(?:어느|어떤|무슨|어디)\s*도서관|도서관\s*(?:어디|어느|어떤|무슨))(?:에서|에)?(?:\s*(?:있(?:어|어요|나요|니|습니까|을까|을까요|는지|나|음)?|찾(?:아|을)?|검색))?\s*$/u);
  if (whichLibraryMatch?.[1]) {
    const raw = normalizeBookSearchKeyword(whichLibraryMatch[1]);
    if (raw && raw.length >= 2) {
      const context = stripLeadingContextFromAvailabilitySubject(raw, selectedRegion);
      let bookTitle = stripWhichLibraryQualifierFromTitle(stripTrailingKoreanParticles(stripGenericLibraryNounSuffixFromTitle(context.bookTitle || "")));
      if ((context.regionHint || context.libraryName) && /^도서관\s+/u.test(bookTitle)) bookTitle = stripBookAvailabilityActionTail(stripGenericLibraryNounPrefixFromTitle(bookTitle)) || stripGenericLibraryNounPrefixFromTitle(bookTitle);
      if (bookTitle && (Array.from(bookTitle).length >= 2 || hasClearAvailabilityCueForShortTitle(text)) && !(isLibraryOnlyAvailabilitySubject(bookTitle, selectedRegion) && !context.libraryName)) {
        return {
          bookTitle,
          normalizedQuery: bookTitle,
          libraryName: context.libraryName,
          regionHint: context.regionHint,
          region: context.region || "",
          confidence: context.libraryName || context.regionHint ? 0.91 : 0.94
        };
      }
    }
  }

  const subjectPatterns = [
    /^(.+?)\s+도서관(?:에서|에)\s*있(?:어|어요|나요|니|습니까|을까|을까요|는지|나|음)?\s*$/u,
    /^(.+?)\s*(?:어느|어떤|무슨)\s*도서관(?:에서|에)?\s*있(?:어|어요|나요|니|습니까|을까|을까요|는지|나)?\s*$/u,
    /^(.+?)\s*(?:어느|어떤|무슨)\s*도서관\s*$/u,
    /^(.+?)\s*(?:어느|어떤|무슨)\s*도서관\s*$/u,
    /^(.+?)\s*어디\s*(?:에서|서)?\s*(?:볼|읽을|찾을|구할)\s*수\s*있(?:어|어요|나요|니|습니까|을까|을까요|는지|나)?\s*$/u,
    /^(.+?)\s*어디\s*(?:에서|서|에)?\s*(?:있(?:어|어요|나요|니|습니까|을까|을까요|는지|나|냐)?|찾을\s*수\s*있(?:어|어요|나요|니|을까|을까요)?|위치(?:해)?|야|임|인가요?|일까|죠)?\s*$/u,
    /^(.+?)\s*어딘\s*(?:데|지|가요?|가)\s*$/u,
    /^(.+?)\s*어딨\s*(?:어|어요|나요|니|냐|습니까|는데)?\s*$/u,
    /^(.+?)\s*(?:(?:소장한?|소장된|소장\s*중인|보유한?|보유\s*중인|구비(?:된|한)?|비치(?:된|한)?)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))|(?:소장|보유|구비|비치)\s*도서관|대출처|(?:빌릴|빌리는)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))|빌려\s*주는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))|찾을\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。])))\s*$/u,
    /^(.+?)\\s*(?:있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))|있을\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))|소장한?\s*도서관|소장\s*도서관|소장된\s*도서관|보유\s*도서관|구비\s*도서관|비치\s*도서관|대출\\s*가능(?:한)?\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?|대여\\s*가능(?:한)?\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?|대여\s*할\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?|대여\s*(?:되는|가능한?)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?|빌릴\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?|대출\s*할\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?|빌려\s*볼\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?|구할\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?)\s*$/u,
    /^(.+?)\s*(?:소장|대출)\s*여부\s*$/u,
    /^(.+?)\s*(?:어디(?:에서|서)?\s*)?(?:볼|읽을|찾을|구할)\s*수\s*있(?:어|어요|나요|니|습니까|을까|을까요|는지|나)?\s*$/u,
    /^(.+?)\s*(?:어디(?:에서|서)?\s*)?(?:빌릴\s*수\s*있(?:어|어요|나요|니|습니까|을까|을까요|는지|나)?|빌려\s*볼\s*수\s*있(?:어|어요|나요|니|습니까|을까|을까요|는지|나)?|빌려\s*(?:요|도)?|대여\\s*가능(?:해|한가요|할까요|한지|할지|한)?|대여\s*할\s*수\s*있(?:어|어요|나요|니|습니까|을까|을까요|는지|나)?|대여\s*(?:되는|돼|되나요|가능)|대출\\s*가능(?:해|한가요|할까요|한지|할지)?|대출\s*할\s*수\s*있(?:어|어요|나요|니|습니까|을까|을까요|는지|나)?)\s*$/u,
    /^(.+?)\s*(?:구비|구비된|비치|비치된|대출처|소장|보유)\s*$/u,
    /^(.+?)\s*있(?:나|냐|나요|습니까|니|을까|을까요|는지|음)\s*$/u,
    /^(.+?)\s*있(?:어|어요)\s*$/u,
    /^(.+?)\s*없(?:나|나요|습니까|니|을까|을까요|는지|어|어요)\s*$/u
  ];

  let rawSubject = "";
  const locationHasBookMatch = text.match(/^(.{2,60}?)(?:에서는|에서|에는|에)\s*있는\s+(.{2,})$/u);
  if (locationHasBookMatch) {
    const locationPart = stripTrailingKoreanParticles(locationHasBookMatch[1] || "");
    const titlePart = stripTrailingKoreanParticles(locationHasBookMatch[2] || "");
    if (locationPart && titlePart && titlePart.length >= 2 && !/(?:도서관|작은\s*도서관|문고)$/u.test(titlePart) && !isLibraryServiceFaqIntent(text)) {
      rawSubject = `${locationPart} ${titlePart}`;
    }
  }

  if (!rawSubject) {
    const directPlaceMatch = text.match(/^(.+?)\s*(?:(?:소장한?|소장된|소장\s*중인|보유한?|보유\s*중인|구비(?:된|한)?|비치(?:된|한)?)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))|(?:소장|보유|구비|비치)\s*도서관|대출처|대여\\s*가능(?:한)?\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?|대여\s*할\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?|대여\s*(?:되는|가능한?)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?|빌려\s*볼\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?|구할\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))?|(?:빌릴|빌리는)\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))|빌려\s*주는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。]))|찾을\s*수\s*있는\s*(?:도서관|곳|데(?=$|\s|[?？!！.。])))\s*$/u);
    if (directPlaceMatch?.[1]) rawSubject = directPlaceMatch[1];
  }

  if (!rawSubject) {
    const looseActionMatch = text.match(/^(.+?)\s*(?:대여처|소장처|보유처|대출처|(?:어디(?:에서|서)?\s*)?(?:구해|대여해|대출해|빌려)|(?:대여|대출)\s*(?:찾(?:아|기)?|검색)?)\s*$/u);
    if (looseActionMatch?.[1]) rawSubject = looseActionMatch[1];
  }

  if (!rawSubject) {
    for (const pattern of subjectPatterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        rawSubject = match[1];
        break;
      }
    }
  }

  if (!rawSubject) return null;

  let normalizedSubject = stripAvailabilityObjectParticle(normalizeBookSearchKeyword(rawSubject));
  if (!normalizedSubject || (Array.from(normalizedSubject).length < 2 && !hasClearAvailabilityCueForShortTitle(text))) return null;

  const context = stripLeadingContextFromAvailabilitySubject(normalizedSubject, selectedRegion);
  let bookTitle = stripAvailabilityObjectParticle(stripWhichLibraryQualifierFromTitle(stripTrailingKoreanParticles(stripGenericLibraryNounSuffixFromTitle(context.bookTitle || ""))));
  if ((context.regionHint || context.libraryName) && /^도서관(?:에서|에는|에서|에)?\s+/u.test(bookTitle)) {
    bookTitle = stripBookAvailabilityActionTail(stripGenericLibraryNounPrefixFromTitle(bookTitle)) || stripGenericLibraryNounPrefixFromTitle(bookTitle);
  }
  bookTitle = normalizeAvailabilityBookTitleFinal(bookTitle, text);
  if (!bookTitle || (Array.from(bookTitle).length < 2 && !hasClearAvailabilityCueForShortTitle(text))) return null;
  if (isLibraryOnlyAvailabilitySubject(bookTitle, selectedRegion) && !context.libraryName) return null;

  return {
    bookTitle,
    normalizedQuery: bookTitle,
    libraryName: context.libraryName,
    regionHint: context.regionHint,
    region: context.region || "",
    confidence: context.libraryName || context.regionHint ? 0.91 : 0.94
  };
}

function isBookAvailabilityQuestionForUnderstanding(message = "", selectedRegion = "") {
  return Boolean(getBookAvailabilityExtraction(message, selectedRegion));
}

function normalizeUnderstandingPlan(plan = {}, originalMessage = "", selectedRegion = "") {
  const original = String(originalMessage || "").trim();
  const rawIntent = String(plan.intent || "").trim();
  const intent = QUERY_UNDERSTANDING_VALID_INTENTS.has(rawIntent) ? rawIntent : "unknown";
  const confidence = clampConfidence(plan.confidence, intent === "unknown" ? 0.2 : 0.7);
  let normalizedQuery = sanitizeQuery(plan.normalizedQuery || plan.query || original, 180);
  let bookTitle = sanitizeQuery(plan.bookTitle || "", 120);
  let libraryName = sanitizeQuery(plan.libraryName || "", 120);
  let regionHint = sanitizeQuery(plan.regionHint || "", 80);
  let bookTitleCandidates = buildBookTitleCandidates(plan.bookTitleCandidates || [], bookTitle, normalizedQuery);

  if (intent === "book_availability") {
    const source = String(plan.source || "").trim().toLowerCase();
    const extracted = getBookAvailabilityExtraction(original, selectedRegion);
    const providedQuery = source === "ai" || plan.preserveTitle
      ? normalizeAiProvidedBookTitleCandidate(bookTitle || normalizedQuery || "")
      : normalizeBookSearchKeyword(bookTitle || normalizedQuery || "");

    if ((source === "ai" || plan.preserveTitle) && providedQuery && !hasObviousAvailabilityRequestResidue(providedQuery) && !hasAvailabilityHintLeak({ normalizedQuery: providedQuery, bookTitle: providedQuery, regionHint, libraryName })) {
      const planHasRegionHint = Object.prototype.hasOwnProperty.call(plan, "regionHint");
      const planHasLibraryName = Object.prototype.hasOwnProperty.call(plan, "libraryName");
      normalizedQuery = providedQuery;
      bookTitle = providedQuery;
      // AI가 책 제목과 지역/도서관 경계를 판단한 경우, 규칙 추출값을 자동 병합하지 않는다.
      // 잘못된 regionHint/libraryName이 다시 섞이면 AI 판단 보존 목적이 깨진다.
      void planHasRegionHint;
      void planHasLibraryName;
    } else if (extracted) {
      normalizedQuery = normalizeAvailabilityBookTitleFinal(extracted.normalizedQuery || extracted.bookTitle, original);
      bookTitle = normalizeAvailabilityBookTitleFinal(extracted.bookTitle || normalizedQuery, original);
      libraryName = libraryName || extracted.libraryName || "";
      regionHint = regionHint || extracted.regionHint || "";
    } else {
      normalizedQuery = normalizeBookSearchKeyword(normalizedQuery || original);
      bookTitle = bookTitle || normalizedQuery;
    }
  } else if (intent === "book_search") {
    const source = String(plan.source || "").trim().toLowerCase();
    const preserved = source === "ai"
      ? normalizeAiProvidedBookTitleCandidate(bookTitle || normalizedQuery || original)
      : normalizePlainBookSearchKeyword(bookTitle || normalizedQuery || original);
    normalizedQuery = preserved || normalizedQuery || original;
    bookTitle = bookTitle ? normalizeAiProvidedBookTitleCandidate(bookTitle) : normalizedQuery;
  } else if (intent === "book_info") {
    normalizedQuery = extractBookTitleFromQuestion(normalizedQuery || original) || normalizedQuery || original;
    bookTitle = bookTitle || normalizedQuery;
  } else if (intent === "popular_books") {
    normalizedQuery = extractPopularBooksQueryForUnderstanding(normalizedQuery || original);
    if (!regionHint && normalizedQuery && (getRegionCodeFromText(normalizedQuery) || isAmbiguousLocalRegionName(normalizedQuery))) {
      regionHint = normalizedQuery;
    }
  }

  if (intent === "book_availability" || intent === "book_search") {
    bookTitleCandidates = buildBookTitleCandidates(bookTitleCandidates, bookTitle, normalizedQuery, original);
  }

  if (!["book_availability", "book_search", "book_info"].includes(intent)) {
    bookTitleCandidates = [];
  }

  if (!normalizedQuery && !["faq", "unknown", "ambiguous", "popular_books"].includes(intent)) {
    normalizedQuery = original;
  }


  if (intent === "book_availability" && !selectedRegion && !sanitizeRegionCode(plan.region || "") && regionHint && isAmbiguousLocalRegionName(regionHint)) {
    const clarificationPlan = buildAmbiguousLocalRegionBookAvailabilityPlan(regionHint, bookTitle || normalizedQuery, original, selectedRegion, { libraryName });
    if (clarificationPlan) return normalizeUnderstandingPlan(clarificationPlan, original, selectedRegion);
  }

  const guardrailPlan = applyAmbiguousLocalRegionGuardrail({ ...plan, intent, normalizedQuery, bookTitle, libraryName, regionHint, region: sanitizeRegionCode(plan.region || "") }, original, selectedRegion);
  if (guardrailPlan) return normalizeUnderstandingPlan(guardrailPlan, original, selectedRegion);

  const alternatives = Array.isArray(plan.alternatives)
    ? plan.alternatives
        .slice(0, 8)
        .map((item) => ({
          intent: QUERY_UNDERSTANDING_VALID_INTENTS.has(String(item?.intent || "")) ? String(item.intent) : "unknown",
          label: sanitizeQuery(item?.label || "", 80),
          normalizedQuery: sanitizeQuery(item?.normalizedQuery || item?.query || normalizedQuery || original, 120),
          bookTitle: sanitizeQuery(item?.bookTitle || ((String(item?.intent || "") === "book_availability" || String(item?.intent || "") === "book_search") ? (item?.normalizedQuery || item?.query || "") : ""), 120),
          libraryName: sanitizeQuery(item?.libraryName || "", 120),
          regionHint: sanitizeQuery(item?.regionHint || "", 80),
          region: sanitizeRegionCode(item?.region || ""),
          bookTitleCandidates: (String(item?.intent || "") === "book_availability" || String(item?.intent || "") === "book_search") ? buildBookTitleCandidates(item?.bookTitleCandidates || [], item?.bookTitle || item?.normalizedQuery || item?.query || "") : [],
          filters: Array.isArray(item?.filters) ? item.filters.slice(0, 4).map((filter) => ({
            field: sanitizeQuery(filter?.field || "", 40),
            op: sanitizeQuery(filter?.op || "", 40),
            values: Array.isArray(filter?.values) ? filter.values.slice(0, 6).map((value) => sanitizeQuery(value || "", 60)).filter(Boolean) : []
          })).filter((filter) => filter.field && filter.op && filter.values.length > 0) : []
        }))
        .filter((item) => item.intent !== "unknown" && item.label)
    : [];

  const hintedRegionCode = regionHint ? getRegionCodeFromText(regionHint, selectedRegion) : "";
  const effectiveRegion = intent === "ambiguous"
    ? sanitizeRegionCode(plan.region || hintedRegionCode || "")
    : sanitizeRegionCode(plan.region || hintedRegionCode || selectedRegion || "");

  const apiRoute = QUERY_UNDERSTANDING_VALID_API_ROUTES.has(String(plan.apiRoute || ""))
    ? String(plan.apiRoute)
    : ({
        book_search: "books",
        book_availability: "books_then_holdings",
        library_search: "libraries",
        popular_books: "popular_books",
        book_recommendation: "book_recommendations",
        book_info: "assist",
        faq: "assist",
        ambiguous: "clarify",
        unknown: "none"
      }[intent] || "none");
  const needsClarification = Boolean(plan.needsClarification || intent === "ambiguous");
  const filters = Array.isArray(plan.filters)
    ? plan.filters.slice(0, 4).map((item) => ({
        field: sanitizeQuery(item?.field || "", 40),
        op: sanitizeQuery(item?.op || "", 40),
        values: Array.isArray(item?.values) ? item.values.slice(0, 6).map((value) => sanitizeQuery(value || "", 60)).filter(Boolean) : []
      })).filter((item) => item.field && item.op && item.values.length > 0)
    : [];

  return {
    intent,
    apiRoute,
    normalizedQuery,
    bookTitle,
    bookTitleCandidates,
    libraryName,
    regionHint,
    region: effectiveRegion,
    confidence,
    source: sanitizeQuery(plan.source || "rule", 30),
    reason: sanitizeQuery(plan.reason || "", 220),
    needsClarification,
    clarificationMessage: sanitizeQuery(plan.clarificationMessage || "", 160),
    filters,
    alternatives
  };
}

function extractSpecificLibraryInfoQuery(message = "") {
  const text = String(message || "").trim();
  if (!text) return "";
  const match = text.match(/^(.{2,}?(?:도서관|작은\s*도서관|문고))\s*(?:의|은|는|이|가)?\s*(?:운영\s*시간|개관\s*시간|이용\s*시간|몇\s*시|휴관일|휴관|쉬는\s*날|(?:오늘|내일)?\s*쉬(?:어|나요|니|는지)?|(?:오늘|내일)?\s*닫(?:았|아|나요|니)?|문\s*닫|전화\s*번호|전화번호|연락처|주소|위치|가는\s*법|찾아\s*가|오늘\s*열|내일\s*열|문\s*열|열렸|열려|열었|열어|운영\s*해|운영\s*하|행사|프로그램|홈페이지|웹\s*사이트|사이트|예약|전자\s*책|전자도서|주차|주차\s*가능|와이파이|wifi|wi\s*-?\s*fi|프린터|프린트|출력|인쇄|스캔|복사|노트북|pc|컴퓨터|열람실|좌석|식당|카페|사물함|보관함|스터디\s*룸|스터디룸|프린트|프린터|출력|인쇄|스캔|복사|노트북|pc|컴퓨터|전자\s*책|전자도서|홈페이지|사이트|예약).*$/u);
  return stripTrailingKoreanParticles(match?.[1] || "");
}

function isSpecificLibraryInfoRequest(message = "") {
  return Boolean(extractSpecificLibraryInfoQuery(message));
}


const UNSUPPORTED_DIGITAL_BOOK_CONDITION_PATTERN = "전자\\s*책|전자도서|전자\\s*도서|ebook|e\\s*[-‐‑‒–—－]?\\s*book|e\\s*[-‐‑‒–—－]?\\s*북|이북|오디오북|오디오\\s*북";
const LARGE_PRINT_BOOK_CONDITION_PATTERN = "큰\\s*글자(?:판)?|큰글자(?:판)?|큰\\s*활자(?:본)?|큰활자(?:본)?|큰\\s*글씨|큰글씨";
const AUDIENCE_BOOK_CONDITION_PATTERN = "초등학생|어린이|청소년";
const BOOK_FORMAT_OR_AUDIENCE_CONDITION_PATTERN = `${UNSUPPORTED_DIGITAL_BOOK_CONDITION_PATTERN}|${LARGE_PRINT_BOOK_CONDITION_PATTERN}|${AUDIENCE_BOOK_CONDITION_PATTERN}`;

function normalizeConditionLabel(condition = "") {
  return String(condition || "").replace(/\s+/g, " ").replace(/(?:으로|로)$/u, "").trim();
}

function getConditionType(condition = "") {
  const label = normalizeConditionLabel(condition);
  if (new RegExp(`^(?:${UNSUPPORTED_DIGITAL_BOOK_CONDITION_PATTERN})$`, "u").test(label)) return "unsupportedDigital";
  if (new RegExp(`^(?:${LARGE_PRINT_BOOK_CONDITION_PATTERN})$`, "u").test(label)) return "largePrint";
  if (new RegExp(`^(?:${AUDIENCE_BOOK_CONDITION_PATTERN})$`, "u").test(label)) return "audience";
  return "unknown";
}

function getConditionedBookAmbiguityPlan(message = "") {
  const text = stripKoreanRequestTail(String(message || "").trim().toLowerCase()).replace(/[?？!！.。]+$/u, "").trim();
  if (!text) return null;
  const conditionPattern = `(?:${BOOK_FORMAT_OR_AUDIENCE_CONDITION_PATTERN})(?:으로|로)?`;
  const tailCue = "(?:어디|어딘|어딨|있(?:어|어요|나|나요|니|냐|습니까|을까|을까요|는지)?|볼\\s*수|읽을\\s*수|소장|보유|대출|대여|빌릴|구비|비치)";
  let condition = "";
  let title = "";

  let match = text.match(new RegExp(`^(${conditionPattern})\\s+(.+?)\\s*${tailCue}.*$`, "u"));
  if (match?.[1] && match?.[2]) {
    condition = normalizeConditionLabel(match[1]);
    title = normalizeAiProvidedBookTitleCandidate(stripBookAvailabilityActionTail(match[2]) || match[2]);
  }

  if (!title) {
    match = text.match(new RegExp(`^(.+?)\\s+(${conditionPattern})\\s*${tailCue}.*$`, "u"));
    if (match?.[1] && match?.[2]) {
      title = normalizeAiProvidedBookTitleCandidate(stripBookAvailabilityActionTail(match[1]) || match[1]);
      condition = normalizeConditionLabel(match[2]);
    }
  }

  if (!title || Array.from(title).length < 2) return null;
  if (isLibraryOnlyAvailabilitySubject(title, "")) return null;
  const conditionLabel = normalizeConditionLabel(condition);
  const conditionType = getConditionType(conditionLabel);
  if (conditionType === "unsupportedDigital" && isUnsupportedDigitalTitleLike(text)) {
    return null;
  }

  if (conditionType === "largePrint") {
    const primary = `${title} ${conditionLabel}`.replace(/\s+/g, " ").trim();
    return {
      intent: "book_availability",
      apiRoute: "books_then_holdings",
      normalizedQuery: primary,
      bookTitle: primary,
      bookTitleCandidates: buildBookTitleCandidates(primary, `${conditionLabel} ${title}`, title),
      confidence: 0.86,
      source: "rule",
      reason: "큰글자/큰활자 판본은 도서 검색어에 조건을 포함해 우선 검색함",
      preserveTitle: true,
      needsClarification: false
    };
  }

  if (conditionType === "unsupportedDigital") {
    return {
      intent: "ambiguous",
      normalizedQuery: title,
      bookTitle: title,
      bookTitleCandidates: buildBookTitleCandidates(title, text),
      confidence: 0.84,
      source: "rule",
      reason: "전자책/오디오북은 현재 소장 도서관 API에서 직접 필터링하기 어려워 일반 소장 검색 또는 이용안내로 분기해야 함",
      needsClarification: true,
      alternatives: [
        { label: `『${title}』 일반 소장 도서관 찾기`, intent: "book_availability", normalizedQuery: title },
        { label: `${conditionLabel || "전자책/오디오북"} 이용 안내 보기`, intent: "faq", normalizedQuery: `${conditionLabel || "전자책 오디오북"} 이용 안내` },
        { label: `“${text}” 제목 그대로 검색`, intent: "book_search", normalizedQuery: text }
      ]
    };
  }

  return {
    intent: "ambiguous",
    normalizedQuery: title,
    bookTitle: title,
    bookTitleCandidates: buildBookTitleCandidates(title, text),
    confidence: 0.82,
    source: "rule",
    reason: "연령/대상 표현이 제목 일부인지 검색 조건인지 애매함",
    needsClarification: true,
    alternatives: [
      { label: `『${title}』 조건을 반영해 찾기`, intent: "book_availability", normalizedQuery: title, bookTitle: title, bookTitleCandidates: buildBookTitleCandidates(title, text) },
      { label: `“${text}” 제목 그대로 검색`, intent: "book_search", normalizedQuery: text }
    ]
  };
}

function getAudienceReadingConditionAmbiguityPlan(message = "") {
  const text = stripKoreanRequestTail(String(message || "").trim().toLowerCase()).replace(/[?？!！.。]+$/u, "").trim();
  if (!text) return null;
  const audience = "(?:아이랑|아이와|아이와\\s*함께|어린이와|초등학생(?:이|이랑|과)?|어린이(?:가|랑|와)?|청소년(?:이|이랑|과)?)";
  const action = "(?:읽을|볼|읽어볼|함께\\s*읽을|같이\\s*읽을)";
  let match = text.match(new RegExp(`^${audience}\\s+${action}\\s*(?:수\\s*있는)?\\s+(.+?)(?:\\s+도서관)?(?:\\s*(?:어디|어딘|어딨|있|소장|대출|대여|빌릴|찾))?$`, "u"));
  if (!match?.[1]) {
    match = text.match(new RegExp(`^${audience}\\s+${action}\\s+(.+?)\\s+(?:어디|어딘|어딨)$`, "u"));
  }
  if (!match?.[1]) return null;
  const title = normalizeAiProvidedBookTitleCandidate(stripBookAvailabilityActionTail(match[1]) || match[1]);
  if (!title || Array.from(title).length < 2 || isLibraryOnlyAvailabilitySubject(title, "")) return null;
  return {
    intent: "ambiguous",
    normalizedQuery: title,
    bookTitle: title,
    bookTitleCandidates: buildBookTitleCandidates(title, text),
    confidence: 0.82,
    source: "rule",
    reason: "아이/초등학생/어린이와 읽는 조건인지 책 제목 일부인지 애매함",
    needsClarification: true,
    alternatives: [
      { label: `『${title}』 소장 도서관 찾기`, intent: "book_availability", normalizedQuery: title, bookTitle: title, bookTitleCandidates: buildBookTitleCandidates(title, text) },
      { label: `“${text}” 제목 그대로 검색`, intent: "book_search", normalizedQuery: text }
    ]
  };
}

function buildRuleBasedQueryUnderstanding(message = "", selectedRegion = "") {
  const text = String(message || "").trim();
  if (!text) return normalizeUnderstandingPlan({ intent: "unknown", confidence: 0 }, text, selectedRegion);

  if (isAmbiguousRegionOnlyQueryForUnderstanding(text, selectedRegion)) {
    return normalizeUnderstandingPlan({
      intent: "ambiguous",
      normalizedQuery: text,
      regionHint: text,
      confidence: 0.92,
      source: "rule",
      reason: "지역명 단독 입력이라 책 제목과 도서관 지역 검색이 모두 가능함",
      alternatives: [
        { label: "책 검색", intent: "book_search", normalizedQuery: text },
        { label: "도서관 검색", intent: "library_search", normalizedQuery: `${text} 도서관` }
      ]
    }, text, selectedRegion);
  }

  if (isSpecificLibraryInfoRequest(text)) {
    const libraryInfoQuery = extractSpecificLibraryInfoQuery(text) || text;
    return normalizeUnderstandingPlan({
      intent: "library_search",
      normalizedQuery: libraryInfoQuery,
      libraryName: libraryInfoQuery,
      confidence: 0.92,
      source: "rule",
      reason: "특정 도서관의 운영시간/휴관일/전화번호/주소 정보 요청"
    }, text, selectedRegion);
  }

  const unsupportedDigitalBookPlan = getUnsupportedDigitalBookPlan(text);
  if (unsupportedDigitalBookPlan) {
    return normalizeUnderstandingPlan(unsupportedDigitalBookPlan, text, selectedRegion);
  }

  const audienceReadingAmbiguity = getAudienceReadingConditionAmbiguityPlan(text);
  if (audienceReadingAmbiguity) {
    return normalizeUnderstandingPlan(audienceReadingAmbiguity, text, selectedRegion);
  }

  const conditionedBookAmbiguity = getConditionedBookAmbiguityPlan(text);
  if (conditionedBookAmbiguity) {
    return normalizeUnderstandingPlan(conditionedBookAmbiguity, text, selectedRegion);
  }

  const loanAvailabilityPlan = getLoanAvailabilityPlan(text, selectedRegion);
  if (loanAvailabilityPlan?.needsRegionClarification) {
    const clarificationPlan = buildAmbiguousLocalRegionBookAvailabilityPlan(loanAvailabilityPlan.regionHint, loanAvailabilityPlan.bookTitle || loanAvailabilityPlan.normalizedQuery, text, selectedRegion);
    if (clarificationPlan) return normalizeUnderstandingPlan(clarificationPlan, text, selectedRegion);
  }
  if (loanAvailabilityPlan) {
    return normalizeUnderstandingPlan(loanAvailabilityPlan, text, selectedRegion);
  }

  if (isLikelyFaqIntent(text)) {
    return normalizeUnderstandingPlan({
      intent: "faq",
      normalizedQuery: text,
      confidence: 0.93,
      source: "rule",
      reason: "대출/반납/연체/회원증/운영시간 등 이용안내성 질문"
    }, text, selectedRegion);
  }

  if (isPopularBooksQuestion(text, selectedRegion)) {
    const popularQuery = extractPopularBooksQueryForUnderstanding(text) || (selectedRegion ? (REGION_CODE_TO_NAME[sanitizeRegionCode(selectedRegion)] || "선택 지역") : text);
    if (!selectedRegion && isAmbiguousLocalRegionName(popularQuery)) {
      const clarificationPlan = buildAmbiguousLocalRegionPopularBooksPlan(popularQuery, text, selectedRegion);
      if (clarificationPlan) return normalizeUnderstandingPlan(clarificationPlan, text, selectedRegion);
    }
    return normalizeUnderstandingPlan({
      intent: "popular_books",
      normalizedQuery: popularQuery,
      regionHint: selectedRegion ? (popularQuery || "") : "",
      region: selectedRegion || "",
      confidence: 0.93,
      source: "rule",
      reason: "인기/대출/베스트 등 지역 또는 도서관 기준 인기대출도서 신호"
    }, text, selectedRegion);
  }

  const largePrintBookPlan = getLargePrintBookPlan(text);
  if (largePrintBookPlan) {
    return normalizeUnderstandingPlan(largePrintBookPlan, text, selectedRegion);
  }

  const clearLibraryListingPlan = getClearLibraryListingPlanForUnderstanding(text, selectedRegion);
  if (clearLibraryListingPlan) {
    return normalizeUnderstandingPlan(clearLibraryListingPlan, text, selectedRegion);
  }

  if (isLibraryRecommendationRequest(text)) {
    return normalizeUnderstandingPlan({
      intent: "library_search",
      normalizedQuery: text,
      confidence: 0.91,
      source: "rule",
      reason: "도서관 자체를 추천/탐색하려는 표현"
    }, text, selectedRegion);
  }


  const libraryOnlyCandidate = text.replace(/\s*(?:어디|어딘데|어디야|어디임|어디에|어디서|위치|주소)\s*[?？!！.。]*$/u, "").trim();
  if (libraryOnlyCandidate && looksLikeTrustedSpecificLibraryNameForUnderstanding(libraryOnlyCandidate) && !hasBookAvailabilityActionPhrase(text)) {
    return normalizeUnderstandingPlan({
      intent: "library_search",
      normalizedQuery: libraryOnlyCandidate,
      libraryName: libraryOnlyCandidate,
      confidence: 0.94,
      source: "rule",
      reason: "명확한 도서관명 위치/정보 검색"
    }, text, selectedRegion);
  }

  const spacedTrustedLibraryMatch = text.match(/^([가-힣A-Za-z0-9]{2,30})\s+도서관\s*(?:어디|어딘데|어디야|어디임|어디에|어디서|위치|주소)?\s*[?？!！.。]*$/u);
  if (spacedTrustedLibraryMatch?.[1]) {
    const spacedLibraryName = `${spacedTrustedLibraryMatch[1]} 도서관`;
    const compactLibraryName = `${spacedTrustedLibraryMatch[1]}도서관`;
    if ((isKnownStandardLibraryNameForUnderstanding(spacedLibraryName) || isKnownStandardLibraryNameForUnderstanding(compactLibraryName) || isSafeSpacedLibraryNameForUnderstanding(spacedLibraryName) || isTrustedSpacedLibraryStemForUnderstanding(spacedTrustedLibraryMatch[1])) && !hasBookAvailabilityActionPhrase(text)) {
      return normalizeUnderstandingPlan({
        intent: "library_search",
        normalizedQuery: spacedLibraryName,
        libraryName: spacedLibraryName,
        confidence: 0.93,
        source: "rule",
        reason: "띄어 쓴 특정 도서관명 위치/정보 검색"
      }, text, selectedRegion);
    }
  }

  const spacedSpecificLibraryWhereMatch = text.match(/^([가-힣0-9]{2,20})\s+도서관\s*(?:은|는|이|가)?\s*(?:어디|어딘|어딨|위치|주소|찾|검색)\s*[?？!！.。]*$/u);
  if (spacedSpecificLibraryWhereMatch?.[1]) {
    const spacedLibraryName = `${spacedSpecificLibraryWhereMatch[1]} 도서관`;
    const compactLibraryName = `${spacedSpecificLibraryWhereMatch[1]}도서관`;
    if (isKnownStandardLibraryNameForUnderstanding(spacedLibraryName) || isKnownStandardLibraryNameForUnderstanding(compactLibraryName) || isSafeSpacedLibraryNameForUnderstanding(spacedLibraryName) || isTrustedSpacedLibraryStemForUnderstanding(spacedSpecificLibraryWhereMatch[1])) {
      return normalizeUnderstandingPlan({
        intent: "library_search",
        normalizedQuery: spacedLibraryName,
        libraryName: spacedLibraryName,
        confidence: 0.91,
        source: "rule",
        reason: "띄어 쓴 특정 도서관명 위치/정보 검색"
      }, text, selectedRegion);
    }
  }
  const leadingRegionLibraryExtraction = getBookLeadingRegionLibraryAvailabilityPlan(text, selectedRegion);
  if (leadingRegionLibraryExtraction) {
    return normalizeUnderstandingPlan({
      intent: "book_availability",
      normalizedQuery: leadingRegionLibraryExtraction.normalizedQuery,
      bookTitle: leadingRegionLibraryExtraction.bookTitle,
      libraryName: leadingRegionLibraryExtraction.libraryName,
      regionHint: leadingRegionLibraryExtraction.regionHint,
      region: leadingRegionLibraryExtraction.region,
      confidence: leadingRegionLibraryExtraction.confidence,
      source: "rule",
      reason: "책 제목 뒤의 지역/도서관 일반명사를 분리한 소장 검색"
    }, text, selectedRegion);
  }

  const leadingSpecificLibraryExtraction = getBookLeadingSpecificLibraryAvailabilityPlan(text, selectedRegion);
  if (leadingSpecificLibraryExtraction) {
    return normalizeUnderstandingPlan({
      intent: "book_availability",
      normalizedQuery: leadingSpecificLibraryExtraction.normalizedQuery,
      bookTitle: leadingSpecificLibraryExtraction.bookTitle,
      libraryName: leadingSpecificLibraryExtraction.libraryName,
      regionHint: leadingSpecificLibraryExtraction.regionHint,
      region: leadingSpecificLibraryExtraction.region,
      confidence: leadingSpecificLibraryExtraction.confidence,
      source: "rule",
      reason: "책 제목 뒤의 특정 도서관명을 분리한 소장 검색"
    }, text, selectedRegion);
  }

  const bookTitleLibraryPredicateAmbiguity = getBookTitleLibraryPredicateAmbiguityPlan(text, selectedRegion);
  if (bookTitleLibraryPredicateAmbiguity) {
    return normalizeUnderstandingPlan(bookTitleLibraryPredicateAmbiguity, text, selectedRegion);
  }

  const availabilityExtraction = getBookAvailabilityExtraction(text, selectedRegion);
  if (availabilityExtraction?.needsRegionClarification) {
    const clarificationPlan = buildAmbiguousLocalRegionBookAvailabilityPlan(availabilityExtraction.regionHint, availabilityExtraction.bookTitle || availabilityExtraction.normalizedQuery, text, selectedRegion, { libraryName: availabilityExtraction.libraryName || "" });
    if (clarificationPlan) return normalizeUnderstandingPlan(clarificationPlan, text, selectedRegion);
  }
  if (!selectedRegion && availabilityExtraction?.libraryName && !availabilityExtraction.region) {
    const ambiguousLibraryRegion = getAmbiguousLocalRegionFromLibraryNameForUnderstanding(availabilityExtraction.libraryName);
    if (ambiguousLibraryRegion) {
      const clarificationPlan = buildAmbiguousLocalRegionBookAvailabilityPlan(ambiguousLibraryRegion, availabilityExtraction.bookTitle || availabilityExtraction.normalizedQuery, text, selectedRegion, { libraryName: availabilityExtraction.libraryName });
      if (clarificationPlan) return normalizeUnderstandingPlan(clarificationPlan, text, selectedRegion);
    }
  }
  if (availabilityExtraction && isExplicitBookAvailabilityLibraryRequest(text, availabilityExtraction)) {
    return normalizeUnderstandingPlan({
      intent: "book_availability",
      normalizedQuery: availabilityExtraction.normalizedQuery,
      bookTitle: availabilityExtraction.bookTitle,
      libraryName: availabilityExtraction.libraryName,
      regionHint: availabilityExtraction.regionHint,
      region: availabilityExtraction.region,
      confidence: availabilityExtraction.confidence,
      source: "rule",
      reason: availabilityExtraction.libraryName
        ? "특정 도서관 안의 책 소장/대출 가능 여부를 묻는 표현"
        : "책 제목의 소장 도서관 또는 대출 가능 위치를 묻는 표현"
    }, text, selectedRegion);
  }

  if (availabilityExtraction) {
    return normalizeUnderstandingPlan({
      intent: "book_availability",
      normalizedQuery: availabilityExtraction.normalizedQuery,
      bookTitle: availabilityExtraction.bookTitle,
      libraryName: availabilityExtraction.libraryName,
      regionHint: availabilityExtraction.regionHint,
      region: availabilityExtraction.region,
      confidence: availabilityExtraction.confidence,
      source: "rule",
      reason: availabilityExtraction.libraryName
        ? "특정 도서관 안의 책 소장/대출 가능 여부를 묻는 표현"
        : "책 제목의 소장 도서관 또는 대출 가능 위치를 묻는 표현"
    }, text, selectedRegion);
  }

  const bareBookTrailingLibraryAmbiguity = getBareBookTrailingLibraryAmbiguityPlan(text, selectedRegion);
  if (bareBookTrailingLibraryAmbiguity) {
    return normalizeUnderstandingPlan(bareBookTrailingLibraryAmbiguity, text, selectedRegion);
  }

  const earlyBookOrLibraryAmbiguity = getAmbiguousBookOrLibraryWherePlan(text, selectedRegion);
  if (earlyBookOrLibraryAmbiguity
    && !hasNearbyLibrarySignal(text)
    && !isLibraryRecommendationRequest(text)
    && !isClearLocationPhraseLibraryQueryForUnderstanding(text)) {
    return normalizeUnderstandingPlan(earlyBookOrLibraryAmbiguity, text, selectedRegion);
  }

  if (isClearLibrarySearchBeforeAmbiguity(text)) {
    return normalizeUnderstandingPlan({
      intent: "library_search",
      normalizedQuery: text,
      libraryName: isExplicitLibraryNameQuery(text) ? text : "",
      confidence: 0.93,
      source: "rule",
      reason: "도서관명/지역/근처 도서관을 찾는 표현"
    }, text, selectedRegion);
  }

  const bookOrLibraryAmbiguity = getAmbiguousBookOrLibraryWherePlan(text, selectedRegion);
  if (bookOrLibraryAmbiguity) {
    return normalizeUnderstandingPlan(bookOrLibraryAmbiguity, text, selectedRegion);
  }


  if (isAmbiguousRegionWhereQueryForUnderstanding(text, selectedRegion)) {
    const regionQuery = text.replace(/\s*(?:어디|어딘데|어디야|어디임|어디에|어디서)\s*[?？!！.。]*$/u, "").trim() || text;
    return normalizeUnderstandingPlan({
      intent: "ambiguous",
      normalizedQuery: regionQuery,
      regionHint: regionQuery,
      confidence: 0.9,
      source: "rule",
      reason: "지역명 뒤에 어디가 붙어 책 제목보다는 지역/도서관 탐색일 가능성이 큼",
      alternatives: [
        { label: "도서관 검색", intent: "library_search", normalizedQuery: `${regionQuery} 도서관` },
        { label: "책 검색", intent: "book_search", normalizedQuery: regionQuery }
      ]
    }, text, selectedRegion);
  }


  if (isLocationPhraseLibraryQuery(text) || isGenericLocationLibraryQuery(text) || isExplicitLibraryNameQuery(text) || isStrongLibrarySearchIntent(text) || hasNearbyLibrarySignal(text)) {
    return normalizeUnderstandingPlan({
      intent: "library_search",
      normalizedQuery: text,
      libraryName: isExplicitLibraryNameQuery(text) ? text : "",
      confidence: 0.93,
      source: "rule",
      reason: "도서관명/지역/근처 도서관을 찾는 표현"
    }, text, selectedRegion);
  }

  if (isRecommendationIntent(text)) {
    return normalizeUnderstandingPlan({
      intent: "book_recommendation",
      normalizedQuery: text,
      confidence: 0.9,
      source: "rule",
      reason: "추천 또는 분위기/상황 기반 도서 요청"
    }, text, selectedRegion);
  }

  if (isBookDescriptionRequest(text)) {
    return normalizeUnderstandingPlan({
      intent: "book_info",
      normalizedQuery: extractBookTitleFromQuestion(text),
      confidence: 0.9,
      source: "rule",
      reason: "책 소개/줄거리/내용 질문"
    }, text, selectedRegion);
  }

  const bareSpecificLibraryBookAmbiguity = getBareSpecificLibraryBookAmbiguityPlan(text);
  if (bareSpecificLibraryBookAmbiguity) {
    return normalizeUnderstandingPlan(bareSpecificLibraryBookAmbiguity, text, selectedRegion);
  }

  if (isLikelyPlainBookQuery(text)) {
    return normalizeUnderstandingPlan({
      intent: "book_search",
      normalizedQuery: normalizePlainBookSearchKeyword(text),
      confidence: 0.86,
      source: "rule",
      reason: "짧은 제목형 도서 검색어"
    }, text, selectedRegion);
  }

  if (/(?:도서관|작은\s*도서관|문고)/u.test(text) && !/[?？]|어디|어딘|어딨|있나|있어|위치|주소|찾아|검색/u.test(text) && !isStrongLibrarySearchIntent(text)) {
    return normalizeUnderstandingPlan({
      intent: "book_search",
      normalizedQuery: normalizePlainBookSearchKeyword(text),
      bookTitle: normalizePlainBookSearchKeyword(text),
      confidence: 0.82,
      source: "rule",
      reason: "도서관이라는 단어가 제목 일부일 수 있는 일반 책 검색어"
    }, text, selectedRegion);
  }

  return null;
}

async function classifyQueryUnderstandingWithAI(message = "", selectedRegion = "") {
  const text = String(message || "").trim();
  if (!text || !openai) return null;

  try {
    const selectedRegionName = selectedRegion ? (REGION_CODE_TO_NAME[selectedRegion] || selectedRegion) : "선택 없음";
    const prompt = [
      "도서관 검색 서비스의 query-understanding 엔진입니다.",
      "사용자의 한국어 자연어 검색을 실제 검색 실행 계획 JSON으로 바꾸세요. raw 정규식은 절대 만들지 말고 안전한 필드 값만 작성하세요.",
      "intent는 다음 중 하나만 사용합니다: book_search, book_availability, library_search, popular_books, book_recommendation, book_info, faq, ambiguous, unknown",
      "book_search: 제목/저자/ISBN 중심으로 책 카드를 찾는 요청. 예: 데미안, 978..., 불편한 편의점",
      "book_availability: 특정 책을 어느 도서관에서 볼 수 있는지/빌릴 수 있는지 묻는 요청. 예: 신참자 어디?, 신참자 종로에서 어디?, 채식주의자 부평에서 어디있음?, 데미안 빌릴 수 있는 곳, 데미안 소장한 곳, 데미안 대여 가능한 곳, 데미안 구비 도서관, 데미안 비치된 곳, 데미안 대출처, 신참자 빌릴 곳, 불편한 편의점 있나, 신참자 있는 도서관 찾아줘, 아이랑 데미안 읽을 수 있는 도서관, 정독 도서관 데미안 있어?, 경기 성남 분당 데미안 어디, 큰글자 데미안 있어?",
      "library_search: 도서관 자체의 위치/지역/근처/명칭 검색. 예: 정독도서관 어디?, 강남구 도서관, 휘문고 근처 도서관",
      "popular_books: 특정 도서관이나 지역에서 많이 빌린 책/인기대출도서/베스트 요청",
      "book_recommendation: 취향, 상황, 기분, 주제에 맞는 책 추천 요청",
      "book_info: 책의 줄거리, 내용, 저자, 어떤 책인지 설명 요청",
      "faq: 서비스 이용 방법, 행사, 문의, 도서관의 날/도서관주간 등 안내성 질문",
      "ambiguous: 지역명 또는 짧은 명사만 있어 책 검색과 도서관 검색이 모두 가능한 경우. 전자책/오디오북은 현재 소장 API에서 직접 검색 조건으로 확정하지 말고 ambiguous 또는 faq 안내로 둡니다. 큰글자는 검색 가능한 판본 조건이므로 bookTitle 후보에 큰글자/큰활자를 포함할 수 있습니다. 어린이/초등학생/청소년 같은 말이 제목 일부인지 검색 조건인지 애매하면 ambiguous로 둡니다.",
      "출력 스키마: {intent, apiRoute, normalizedQuery, bookTitle, bookTitleCandidates, libraryName, regionHint, region, filters, confidence, needsClarification, reason}. apiRoute는 books, books_then_holdings, libraries, popular_books, book_recommendations, assist, clarify, none 중 하나입니다.",
      "normalizedQuery에는 실제 검색 API에 넘길 검색어를 넣습니다. book_availability라면 책 제목만 남기되, 책 제목 안의 '어디/어디서/에서/에/도서관/비치/구비/소장/빌릴 수/도/을/와'는 제목 일부일 수 있으므로 문맥상 제목이면 절대 제거하지 마세요.",
      "book_availability의 normalizedQuery에는 요청 꼬리인 '어디?', '있나?', '있는 도서관', '빌릴 수 있는 곳', '대여 가능', '찾아줘'만 제거합니다. 지역/장소는 regionHint에만 넣고 조건어는 reason에만 설명합니다.",
      "필터가 필요하면 filters 배열에 {field:'libraryAddressOrName', op:'contains_any', values:['중구']}처럼 안전한 contains 조건만 넣고, 정규식 문자열은 절대 넣지 마세요.",
      "서구/중구/남구/북구/동구처럼 여러 지역에 있는 이름은 현재 선택 지역이 없으면 region을 단정하지 마세요.",
      "'경기 광주', '경기도 광주시'는 광주광역시가 아니라 경기 지역 힌트로 판단합니다.",
      "단, '죽음의 수용소에서', '어디서 살 것인가', '어디로 가야 할까', '누가 내 머리에 똥 쌌어', '모든 것은 기본에서 시작한다', '비치코밍', '구비구비 옛이야기', '빌릴 수 없는 책', '아주 희미한 빛으로도', '나는 소망한다 내게 금지된 것을', '종로 산책', '광주 아리랑', '광주에서 온 편지', '잠실동 사람들', '도서관 고양이 듀이', '파과', '태도', '지도', '아무도', '듀이'처럼 지역명/도서관/조사/소장 표현처럼 보이는 말이 책 제목 일부일 수 있으면 regionHint를 비우고 normalizedQuery에 전체 제목을 보존하세요.",
      "'경기 광주', '경기도 광주시'는 광주광역시가 아니라 경기 지역 힌트로 판단합니다. '서구/중구/동구/남구/북구'는 현재 선택 지역이 있으면 그 지역 기준, 없으면 확정하지 않습니다.",
      "불확실하면 confidence를 0.65 이하로 낮추고 ambiguous 또는 unknown을 사용합니다.",
      "도서관 자체를 묻는 '정독도서관 어디?', '정독 도서관 어디?'는 library_search이고, 책 제목을 묻는 '신참자 어디?'는 book_availability입니다. '데미안 도서관 어디'처럼 책 제목+도서관명 모두 가능한 경우는 ambiguous로 두세요.",
      `현재 사용자가 선택한 지역: ${selectedRegionName}`,
      "반드시 JSON만 답하세요. 예: {\"intent\":\"book_availability\",\"normalizedQuery\":\"신참자\",\"confidence\":0.91,\"reason\":\"책 위치 질문\"}"
    ].join("\n");

    const response = await openai.responses.create({
      model: GPT_CLASSIFIER_MODEL,
      input: [
        { role: "system", content: prompt },
        { role: "user", content: text }
      ]
    });

    const parsed = tryParseJsonObject(response.output_text || "");
    if (!parsed || typeof parsed !== "object") return null;
    return normalizeUnderstandingPlan({ ...parsed, source: "ai" }, text, selectedRegion);
  } catch (error) {
    console.error("QUERY_UNDERSTANDING_AI_ERROR:", error.message || error);
    return null;
  }
}

function hasObviousAvailabilityRequestResidue(keyword = "") {
  const text = String(keyword || "").replace(/\s+/g, " ").trim();
  if (!text) return true;
  return /(?:\s|^)(?:어디|어딘|어딨|있나|있나요|있습니까|있을까|있어|있어요|있는\s*도서관|빌릴\s*수\s*있는|빌릴\s*(?:곳|데)|빌리는\s*(?:곳|데)|빌려\s*주는\s*(?:곳|도서관)?|빌려\s*볼\s*수|대출\\s*가능|대여\\s*가능|대출처|대여처|소장처|보유처|구할\s*수\s*있는|찾을\s*수\s*있는|찾아\s*줘|검색\s*해\s*줘)\s*$/u.test(text)
    || /(?:\s|^)(?:소장|보유|구비|비치)\s*(?:도서관|곳|데)\s*$/u.test(text);
}

function hasDirtyAvailabilityKeywordResidue(keyword = "") {
  const text = String(keyword || "").replace(/\s+/g, " ").trim();
  if (!text) return true;
  if (hasObviousAvailabilityRequestResidue(text)) return true;
  // 알려진 지역/장소가 끝에 붙은 경우만 검색어 오염으로 본다.
  const suffixMatch = text.match(/^(.{2,})\s+([가-힣0-9]{2,12})(?:에서|에는|에서는|에|근처|주변|인근|부근|쪽)$/u);
  if (suffixMatch) {
    const hint = getLooseAreaAliasHint(suffixMatch[2]) || getDetailedRegionAliasHint(suffixMatch[2]) || getRegionCodeFromText(suffixMatch[2]);
    if (hint) return true;
  }
  return false;
}

function hasAvailabilityHintLeak(plan = {}) {
  const query = normalizeSearchText(plan.bookTitle || plan.normalizedQuery || "");
  if (!query) return false;
  const hints = [plan.regionHint, plan.libraryName]
    .map((item) => normalizeSearchText(item || ""))
    .filter((item) => item && item.length >= 2);

  return hints.some((hint) => query !== hint && query.includes(hint));
}

function isAcceptableAiAvailabilityPlan(plan = {}) {
  if (!plan || plan.intent !== "book_availability") return true;
  const query = String(plan.bookTitle || plan.normalizedQuery || "").trim();
  if (!query || query.length < 2) return false;
  if (hasAvailabilityHintLeak(plan)) return false;
  if (hasObviousAvailabilityRequestResidue(query)) return false;
  return true;
}

function getAvailabilityKeywordQualityScore(plan = {}) {
  const intent = String(plan?.intent || "");
  const query = String(plan?.bookTitle || plan?.normalizedQuery || "").trim();
  if (intent !== "book_availability" || !query) return 0;
  let score = 1;
  if (hasObviousAvailabilityRequestResidue(query)) score -= 0.65;
  if (isWeakPredicateOnlyAvailabilityTitle(query)) score -= 0.95;
  if (hasAvailabilityHintLeak(plan)) score -= 0.75;
  if (query.length > 40) score -= 0.15;
  if ((plan.regionHint || (plan.libraryName && looksLikeTrustedSpecificLibraryNameForUnderstanding(plan.libraryName))) && !hasAvailabilityHintLeak(plan)) score += 0.12;
  if (plan.libraryName && !looksLikeTrustedSpecificLibraryNameForUnderstanding(plan.libraryName)) score -= 0.45;
  return score;
}

function hasNaturalLanguageLocationContext(message = "") {
  const text = String(message || "").trim();
  if (!text) return false;
  if (/(?:에서|에는|에서는|에|근처|주변|인근|부근|쪽)/u.test(text) && /(?:어디|어딘|어딨|있|빌릴|대출|소장|찾|열어|열었|문\s*열)/u.test(text)) return true;
  if (/(?:어디|어딘|어딨|있|빌릴|대출|소장|찾).*(?:에서|에는|에서는|에|근처|주변|인근|부근|쪽)/u.test(text)) return true;
  if (/^(?:경기|경기도)\s*광주시?\b/u.test(text) || /\b(?:경기|경기도)\s*광주시?\b/u.test(text)) return true;
  if (UNDERSTANDING_PLACE_ALIAS_HINTS.some((item) => item.names.some((name) => new RegExp(`(?:^|\\s)${escapeRegExp(name)}(?:\\s|에서|에는|에서는|에|근처|주변|인근|부근|쪽)`, "u").test(text)))) return true;
  if (getDetailedRegionHint(text)) return true;
  return false;
}

function isMixedNaturalLanguageQueryForAi(message = "", rulePlan = null) {
  const text = String(message || "").trim();
  if (!text || !rulePlan) return false;
  if (!isQuestionLikeForAiUnderstanding(text)) return false;
  if (isSpecificLibraryInfoRequest(text)) return true;
  if (hasNaturalLanguageLocationContext(text)) return true;
  if (rulePlan.intent === "book_availability" && hasDirtyAvailabilityKeywordResidue(rulePlan.normalizedQuery || rulePlan.bookTitle || "")) return true;
  return false;
}

function isQuestionLikeForAiUnderstanding(message = "") {
  const text = String(message || "").trim().toLowerCase();
  if (!text) return false;
  return /[?？]|어디|어딘|어딨|있나|있나요|있습니까|있을까|있어|있어요|없나|소장|보유|대출|대여|구비|비치|빌릴|추천|방법|문의|뭐야|무슨|어떤|근처|주변|가까운|아이랑|아이와|전자책|전자\s*책|전자\s*도서|e\s*-?\s*북|e\s*북|이북|오디오북|큰글자|큰활자본|초등학생|어린이|청소년|아이랑|아이와/u.test(text);
}

function isDeterministicRulePlanForUnderstanding(message = "", rulePlan = null) {
  const text = String(message || "").trim();
  if (!text || !rulePlan) return false;
  if (rulePlan.intent === "faq" || rulePlan.intent === "popular_books" || rulePlan.intent === "book_recommendation" || rulePlan.intent === "book_info") return true;
  if (rulePlan.intent === "library_search" && isSpecificLibraryInfoRequest(text)) return true;
  if (rulePlan.intent === "book_search" && !isQuestionLikeForAiUnderstanding(text) && !hasBookAvailabilityActionPhrase(text)) return true;
  if (rulePlan.intent === "ambiguous" && rulePlan.confidence >= 0.9 && !hasBookAvailabilityActionPhrase(text)) return true;
  return false;
}

function shouldUseAiUnderstanding(message = "", rulePlan = null) {
  if (!openai) return false;
  const text = String(message || "").trim();
  if (!text) return false;
  if (!rulePlan) return true;

  // 명확한 FAQ/인기/단순 제목은 규칙으로 빠르게 처리한다.
  if (isDeterministicRulePlanForUnderstanding(text, rulePlan)) return false;

  // 자연어 질문, 위치·장소 문맥, 소장/대출/보유 표현은 AI가 검색 계획을 먼저 재검토한다.
  if (new RegExp(`^(?:${UNDERSTANDING_SIDO_PATTERN})\\s+[가-힣0-9]{2,12}\\s+[가-힣0-9]{2,12}\\s+.{2,}`, "u").test(text)) return true;
  if (/(?:전자\s*책|전자책|전자\s*도서|e\s*-?\s*북|e\s*북|이북|오디오\s*북|오디오북|큰글자|큰\s*글자|큰활자|큰\s*활자|초등학생|어린이|청소년|아이랑|아이와)/u.test(text) && isQuestionLikeForAiUnderstanding(text)) return true;
  if (/(?:아이랑|아이와|초등학생(?:이)?|어린이(?:가)?|청소년(?:이)?)\s+(?:읽을|볼|읽어볼)/u.test(text)) return true;
  if (hasBookAvailabilityActionPhrase(text)) return true;
  if (/(?:어디|어딘|어딨)\s*[?？!！.。]*$/u.test(text)) return true;
  if (/(?:에서|에는|에서는|에|비치|구비|도서관|빌릴\s*수|소장|보유|대여|대출|도|을|와)\s*(?:어디|어딘|어딨|소장|대여|대출|찾아)/u.test(text)) return true;
  if (isMixedNaturalLanguageQueryForAi(text, rulePlan)) return true;
  if (/^(?:경기|경기도|경남|경상남도|서울|부산|인천|대구|광주|대전|울산|전북|전라북도|전남|전라남도|경북|경상북도|충남|충청남도|충북|충청북도)\s+[가-힣0-9]{2,12}\s+[가-힣0-9]{2,12}\s+.{2,}\s*(?:어디|어딘|어딨|있|대출|대여|소장)/u.test(text)) return true;
  if (hasNaturalLanguageLocationContext(text)) return true;
  if (rulePlan.intent === "book_availability" && hasDirtyAvailabilityKeywordResidue(rulePlan.normalizedQuery || rulePlan.bookTitle || "")) return true;
  if (rulePlan.intent === "book_search" && isQuestionLikeForAiUnderstanding(text)) return true;
  if (rulePlan.intent === "library_search" && isQuestionLikeForAiUnderstanding(text) && /(?:책|도서(?!관)|소설|에세이|어디|있|빌릴|대출|소장|보유|대여|구비|비치)/u.test(text)) return true;

  if (rulePlan.confidence >= 0.9) return false;
  return isQuestionLikeForAiUnderstanding(text);
}

function chooseBetterUnderstandingPlan(rulePlan = null, aiPlan = null, fallbackPlan = null, selectedRegion = "") {
  if (aiPlan?.intent === "book_availability" && !isAcceptableAiAvailabilityPlan(aiPlan)) {
    aiPlan = null;
  }
  if (!aiPlan) return rulePlan || fallbackPlan;

  const aiConfidence = clampConfidence(aiPlan.confidence, 0);
  const ruleConfidence = rulePlan ? clampConfidence(rulePlan.confidence, 0) : 0;

  if (aiPlan.intent === "unknown" && rulePlan) return rulePlan;
  if (!rulePlan) return aiConfidence >= 0.65 ? aiPlan : fallbackPlan;

  // 전자책/e북/오디오북은 현재 소장 API에서 직접 조건 검색하기 어렵다.
  // AI가 안내/FAQ로 판단했으면, 규칙의 잘못된 book_availability를 이길 수 있게 한다.
  if (aiPlan.intent === "faq" && aiConfidence >= 0.72 && /(?:전자\s*책|전자책|전자\s*도서|전자도서|ebook|e\s*-?\s*book|e\s*[-‐‑‒–—－]?\s*북|이북|오디오\s*북|오디오북)/iu.test(String(rulePlan.normalizedQuery || rulePlan.bookTitle || "") + " " + String(rulePlan.reason || ""))) {
    return aiPlan;
  }

  const ruleQueryForDigitalChoice = String(rulePlan.bookTitle || rulePlan.normalizedQuery || "").trim();
  if (aiPlan.intent === "faq" && aiConfidence >= 0.78 && rulePlan.intent === "book_availability" && /(?:전자\s*책|전자책|전자\s*도서|전자도서|ebook|e\s*-?\s*book|e\s*-?\s*북|e\s*북|이북|오디오\s*북|오디오북)/iu.test(ruleQueryForDigitalChoice)) {
    return aiPlan;
  }

  const ruleTitleForChoice = String(rulePlan.bookTitle || rulePlan.normalizedQuery || "").trim();
  if (aiPlan.intent === "ambiguous" && aiConfidence >= 0.78 && rulePlan.intent === "book_availability" && (isWeakPredicateOnlyAvailabilityTitle(ruleTitleForChoice) || (rulePlan.libraryName && !looksLikeTrustedSpecificLibraryNameForUnderstanding(rulePlan.libraryName)))) {
    return aiPlan;
  }

  const ruleQueryForChoice = String(rulePlan.bookTitle || rulePlan.normalizedQuery || "").trim();
  const ruleHasPredicateOnlyTitle = isPredicateOnlyAvailabilityTitle(ruleQueryForChoice);
  const ruleHasUntrustedLibrary = Boolean(rulePlan.libraryName && !looksLikeTrustedSpecificLibraryNameForUnderstanding(rulePlan.libraryName));
  if (aiPlan.intent === "ambiguous" && aiConfidence >= 0.74 && (ruleHasPredicateOnlyTitle || ruleHasUntrustedLibrary || hasDirtyAvailabilityKeywordResidue(ruleQueryForChoice))) {
    return aiPlan;
  }

  if (rulePlan.intent === "ambiguous" && ruleConfidence >= 0.75 && aiConfidence < 0.88) return rulePlan;
  if (aiConfidence < 0.72) return rulePlan;

  if (aiPlan.intent === "book_availability") {
    const aiQuality = getAvailabilityKeywordQualityScore(aiPlan);
    const ruleQuery = String(rulePlan.normalizedQuery || rulePlan.bookTitle || "").trim();
    const ruleLooksDirty = hasDirtyAvailabilityKeywordResidue(ruleQuery) || hasBookAvailabilityActionPhrase(ruleQuery);
    if (["book_search", "library_search"].includes(rulePlan.intent) && aiQuality >= 0.85 && (ruleLooksDirty || aiConfidence >= Math.max(0.76, ruleConfidence - 0.04))) {
      return aiPlan;
    }
  }

  if (ruleConfidence >= 0.88) {
    if (aiPlan.intent === "book_availability" && rulePlan.intent === "library_search" && aiConfidence >= 0.84 && getAvailabilityKeywordQualityScore(aiPlan) >= 0.85) return aiPlan;
    if (aiPlan.intent === rulePlan.intent && aiPlan.intent === "book_availability") {
      const aiQuality = getAvailabilityKeywordQualityScore(aiPlan);
      const ruleQuality = getAvailabilityKeywordQualityScore(rulePlan);
      const aiQuery = String(aiPlan.bookTitle || aiPlan.normalizedQuery || "").trim();
      const ruleQuery = String(rulePlan.bookTitle || rulePlan.normalizedQuery || "").trim();
      if (aiQuality > ruleQuality + 0.08 && aiConfidence >= 0.74) return aiPlan;
      if (aiQuality >= 0.85 && aiQuality >= ruleQuality && aiConfidence >= 0.86 && aiQuery && ruleQuery && aiQuery.length < ruleQuery.length) return aiPlan;
      if (aiQuality >= ruleQuality && aiQuality >= 0.85 && aiConfidence >= 0.9) return aiPlan;
      return rulePlan;
    }
    if (aiConfidence >= 0.9 && !["faq", "ambiguous", "book_availability"].includes(rulePlan.intent)) return aiPlan;
    return rulePlan;
  }

  if (aiPlan.intent === rulePlan.intent) {
    if (aiPlan.intent === "book_availability") {
      const aiQuality = getAvailabilityKeywordQualityScore(aiPlan);
      const ruleQuality = getAvailabilityKeywordQualityScore(rulePlan);
      if (aiQuality > ruleQuality + 0.1 && aiConfidence >= 0.74) return aiPlan;
      if (aiQuality >= ruleQuality && aiQuality >= 0.85 && aiConfidence >= 0.9) return aiPlan;
    }
    return aiConfidence >= ruleConfidence ? aiPlan : rulePlan;
  }

  if (aiConfidence >= ruleConfidence + 0.08) return aiPlan;
  return rulePlan;
}

async function getQueryUnderstandingPlan(message = "", selectedRegion = "") {
  const text = sanitizeQuery(message || "", 300);
  const region = sanitizeRegionCode(selectedRegion || "");
  if (!text) return normalizeUnderstandingPlan({ intent: "unknown", confidence: 0 }, text, region);

  const cacheKey = JSON.stringify({ text: normalizeSearchText(text), region });
  const cached = getTimedCacheValue(queryUnderstandingCache, cacheKey);
  if (cached) return cached;

  const rulePlan = buildRuleBasedQueryUnderstanding(text, region);
  const fallbackPlan = normalizeUnderstandingPlan({
    intent: "unknown",
    normalizedQuery: text,
    confidence: 0.25,
    source: "fallback",
    reason: "규칙과 AI 분류로 충분히 확정하지 못함"
  }, text, region);

  const aiPlan = shouldUseAiUnderstanding(text, rulePlan)
    ? await classifyQueryUnderstandingWithAI(text, region)
    : null;

  const plan = chooseBetterUnderstandingPlan(rulePlan, aiPlan, fallbackPlan, region) || fallbackPlan;

  setTimedCacheValue(queryUnderstandingCache, cacheKey, plan, QUERY_UNDERSTANDING_CACHE_TTL_MS);
  return plan;
}


function buildAssistResponse({ answer, kind = "answer", actionButtons = [] }) {
  return { answer, kind, actionButtons };
}


function formatBookFallback(book) {
  const parts = [];
  const title = String(book?.title || "").trim();
  const author = String(book?.author || "").trim();
  const translator = String(book?.translator || "").trim();
  const illustrator = String(book?.illustrator || "").trim();
  const publisher = String(book?.publisher || "").trim();
  const publicationYear = String(book?.publicationYear || "").trim();

  if (title && author) {
    parts.push(`『${title}』는 ${author}의 책입니다.`);
  } else if (title) {
    parts.push(`『${title}』라는 책입니다.`);
  }

  if (translator) {
    parts.push(`옮긴이는 ${translator}입니다.`);
  }

  if (illustrator) {
    parts.push(`그림은 ${illustrator}입니다.`);
  }

  const details = [];
  if (publisher) details.push(`출판사는 ${publisher}`);
  if (publicationYear) details.push(`출간 정보는 ${publicationYear}`);

  if (details.length > 0) {
    parts.push(`${details.join(", ")} 정도까지는 확인됩니다.`);
  }

  parts.push("상세 소개 데이터는 지금 검색 결과에서 충분히 확인되지 않습니다.");
  return parts.join(" ");
}

function buildContactResponse() {
  return buildAssistResponse({
    kind: "contact",
    answer: "지금 가진 정보에는 해당 내용이 없어 정확히 안내드리기 어렵습니다. 문의하기를 이용해 주세요.",
    actionButtons: [
      { label: "문의하기", action: "contact", url: "https://minervalib.com/?page_id=78" }
    ]
  });
}

function isBookDescriptionRequest(message = "") {
  const text = String(message || "");
  const descriptionSignals = [
    "어떤 책", "무슨 책", "책이야", "책인가", "줄거리", "내용", "소개", "설명", "무슨 내용", "어떤 내용", "에 대해 알려줘", "에 대해 소개", "에 대해 설명"
  ];
  const negativeSignals = ["있는 도서관", "소장 도서관", "빌릴 수", "도서관 어디", "ISBN"];

  return descriptionSignals.some((signal) => text.includes(signal)) &&
    !negativeSignals.some((signal) => text.includes(signal));
}

function isLibraryRecommendationRequest(message = "") {
  const text = String(message || "").trim().toLowerCase();
  if (!text) return false;

  const hasLibraryWord = /(도서관|작은\s*도서관|문고)/u.test(text);
  const hasPlaceSignal = /(추천|갈\s*만한|갈만한|가기\s*좋은|이용하기\s*좋은|아이랑|아이와|어린이|가족|공부하기\s*좋은|조용한|넓은)/u.test(text);
  const hasLocationSignal = /(서울|부산|대구|인천|광주|대전|울산|세종|경기|강원|충북|충남|전북|전남|경북|경남|제주|[가-힣0-9]+구|[가-힣0-9]+시|[가-힣0-9]+군|[가-힣0-9]+읍|[가-힣0-9]+면|[가-힣0-9]+동|근처|주변|인근|가까운)/u.test(text);
  const hasBookSignal = /(책|도서(?!관)|소설|에세이|시집|그림책|만화|자료)/u.test(text);

  if (!hasPlaceSignal || hasBookSignal) return false;

  const hasChildFamilySignal = /(아이랑|아이와|어린이|가족)/u.test(text);
  if (hasChildFamilySignal && !hasLibraryWord && !hasLocationSignal) {
    // “어린이라는 세계”처럼 제목 안에 어린이가 들어간 경우를 도서관 추천으로 오판하지 않는다.
    return /(갈\s*만한|갈만한|가기\s*좋은|갈\s*수\s*있는|곳|장소|근처|주변|인근|가까운|추천)/u.test(text);
  }

  return hasLibraryWord || hasLocationSignal || hasChildFamilySignal;
}

function isRecommendationIntent(message = "") {
  const text = String(message || "").toLowerCase();
  const signals = [
    "추천", "비슷한 책", "비슷한 작품", "같은 책", "같은 느낌", "읽을만한", "읽을 만한",
    "읽기 좋은", "보기 좋은", "볼 만한", "도움 되는", "위로되는", "위로가 되는", "힐링",
    "입문", "처음", "초보", "공부하기 좋은", "골라줘", "추천해줘"
  ];
  const moodSignals = ["우울", "불안", "힘들", "지쳤", "외로", "슬플", "스트레스", "번아웃", "무기력", "자존감"];
  return signals.some((signal) => text.includes(signal)) ||
    (/(책|도서|소설|에세이|시집|그림책|만화)/u.test(text) && moodSignals.some((signal) => text.includes(signal)));
}

async function classifyAssistIntent(message = "") {
  const text = String(message || "").trim();

  if (!text) {
    return { intent: "unknown", confidence: 0 };
  }

  if (isLikelyFaqIntent(text)) return { intent: "faq", confidence: 0.98 };
  if (isStrongLibrarySearchIntent(text)) return { intent: "library_info", confidence: 0.98 };
  if (isBareBookWhereQuestion(text)) return { intent: "book_info", confidence: 0.96 };
  if (isBookDescriptionRequest(text) || isLikelyPlainBookQuery(text)) return { intent: "book_info", confidence: 0.95 };
  if (isRecommendationIntent(text)) return { intent: "recommendation", confidence: 0.95 };

  if (!openai) {
    return { intent: "unknown", confidence: 0.2 };
  }

  try {
    const prompt = [
      "도서관 챗봇의 질문 분류기입니다.",
      "아래 intent 중 하나만 고르세요: faq, library_info, book_info, recommendation, unknown",
      "faq: 이용안내, 서비스소개, 행사, 문의, 정책, 도서관의 날/도서관주간 같은 안내성 질문",
      "library_info: 도서관 위치, 도서관 찾기, 어느 도서관에 있는지, 소장 도서관, 빌릴 수 있는 곳",
      "book_info: 책 소개, 줄거리, 어떤 책인지, 저자/역자/그림 정보",
      "recommendation: 비슷한 책이나 추천 요청",
      "unknown: 위로 분류하기 어려움",
      "반드시 JSON만 답하세요. 예: {\"intent\":\"book_info\",\"confidence\":0.82}"
    ].join("\n");

    const response = await openai.responses.create({
      model: GPT_CLASSIFIER_MODEL,
      input: [
        { role: "system", content: prompt },
        { role: "user", content: text }
      ]
    });

    const parsed = tryParseJsonObject(response.output_text || "");
    const intent = String(parsed?.intent || "").trim();
    const confidence = Number(parsed?.confidence);

    if (["faq", "library_info", "book_info", "recommendation", "unknown"].includes(intent)) {
      return {
        intent,
        confidence: Number.isFinite(confidence) ? confidence : 0.7
      };
    }
  } catch (error) {
    console.error("ASSIST_INTENT_CLASSIFY_ERROR:", error);
  }

  return { intent: "unknown", confidence: 0.2 };
}

/* ------------------------------
 * Naver Book Search
 * ------------------------------ */

function buildNaverBookSearchUrl(keyword) {
  const url = new URL("https://openapi.naver.com/v1/search/book.json");
  url.searchParams.set("query", keyword);
  url.searchParams.set("display", "20");
  url.searchParams.set("start", "1");
  url.searchParams.set("sort", "sim");
  return url.toString();
}

function extractNaverIsbn13(isbn = "") {
  const parts = String(isbn || "").trim().split(/\s+/).filter(Boolean);
  const isbn13 = parts.find((part) => /^97[89]\d{10}$/.test(part));
  if (isbn13) return isbn13;

  const compact = String(isbn || "").replace(/[^0-9Xx]/g, "");
  if (/^97[89]\d{10}$/.test(compact)) return compact;
  return "";
}


function cleanContributorName(text = "") {
  return String(text || "")
    .replace(/\([^)]*\)/g, " ")
    .replace(/\[[^\]]*\]/g, " ")
    .replace(/\b(author|translator|illustrator)\b/gi, " ")
    .replace(/지음|저|글|옮김|역|그림|삽화|편저|엮음|감수|원저/gi, " ")
    .replace(/[:：]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function parseContributorText(rawText = "") {
  const result = {
    author: "",
    translator: "",
    illustrator: ""
  };

  const normalized = String(rawText || "")
    .replace(/옮긴이/g, "옮김")
    .replace(/번역자/g, "번역")
    .replace(/지은이/g, "지음")
    .replace(/글쓴이/g, "글")
    .replace(/그린이/g, "그림");

  const parts = normalized.split(/[;,/]|·/g);

  parts.forEach((p) => {
    const text = p.trim();
    if (!text) return;

    if (/옮김|번역|역자?|translat/i.test(text)) {
      const cleaned = cleanContributorName(text);
      if (cleaned && !result.translator) result.translator = cleaned;
    } else if (/그림|삽화|illust/i.test(text)) {
      const cleaned = cleanContributorName(text);
      if (cleaned && !result.illustrator) result.illustrator = cleaned;
    } else if (/지음|글|저자?|author|원저|편저|엮음/i.test(text)) {
      const cleaned = cleanContributorName(text);
      if (cleaned && !result.author) result.author = cleaned;
    } else {
      const cleaned = cleanContributorName(text);
      if (cleaned && !result.author) result.author = cleaned;
    }
  });

  return result;
}

function normalizeNaverBookResults(raw) {
  const items = Array.isArray(raw?.items) ? raw.items : [];

  return items.map((item, index) => {
    const contributorMeta = parseContributorText(stripHtml(item.author || ""));

    return {
      id: item.link || `book-${index}`,
      title: stripHtml(item.title || "제목 없음"),
      author: contributorMeta.author || stripHtml(item.author || "저자 정보 없음"),
      translator: contributorMeta.translator || "",
      illustrator: contributorMeta.illustrator || "",
      publisher: stripHtml(item.publisher || "출판사 정보 없음"),
      publicationYear: formatPubDate(item.pubdate || ""),
      isbn13: extractNaverIsbn13(item.isbn || ""),
      isbn: String(item.isbn || ""),
      description: stripHtml(item.description || ""),
      image: item.image || "",
      link: item.link || ""
    };
  });
}

async function searchNaverBooks(keyword) {
  if (!NAVER_CLIENT_ID || !NAVER_CLIENT_SECRET) {
    throw new Error("네이버 API 키가 설정되지 않았습니다.");
  }

  const raw = await fetchJson(buildNaverBookSearchUrl(keyword), {
    headers: {
      "X-Naver-Client-Id": NAVER_CLIENT_ID,
      "X-Naver-Client-Secret": NAVER_CLIENT_SECRET
    }
  });

  return normalizeNaverBookResults(raw);
}

/* ------------------------------
 * National Library Search
 * ------------------------------ */

function buildNationalLibraryKeywordSearchUrl(keyword, pageNum = 1, pageSize = 20) {
  const url = new URL("https://www.nl.go.kr/NL/search/openApi/search.do");
  url.searchParams.set("key", NL_API_KEY);
  url.searchParams.set("apiType", "xml");
  url.searchParams.set("kwd", keyword);
  url.searchParams.set("pageNum", String(pageNum));
  url.searchParams.set("pageSize", String(pageSize));
  return url.toString();
}

function buildNationalLibraryIsbnSearchUrl(isbn) {
  const url = new URL("https://www.nl.go.kr/NL/search/openApi/search.do");
  url.searchParams.set("key", NL_API_KEY);
  url.searchParams.set("apiType", "xml");
  url.searchParams.set("detailSearch", "true");
  url.searchParams.set("isbnOp", "isbn");
  url.searchParams.set("isbnCode", isbn);
  url.searchParams.set("pageSize", "5");
  url.searchParams.set("pageNum", "1");
  return url.toString();
}

function nlExtractCandidateItems(parsed) {
  const candidates = [];

  function walk(node) {
    if (!node || typeof node !== "object") return;

    if (Array.isArray(node)) {
      node.forEach(walk);
      return;
    }

    const hasBookishFields =
      "title_info" in node ||
      "author_info" in node ||
      "pub_info" in node ||
      "pub_year_info" in node ||
      "isbn" in node;

    if (hasBookishFields) {
      candidates.push(node);
    }

    Object.values(node).forEach(walk);
  }

  walk(parsed);
  return candidates;
}

function pickNationalLibraryItemValue(item, keys = []) {
  for (const key of keys) {
    const value = item?.[key];
    if (typeof value === "string" && value.trim()) {
      return value.trim();
    }
  }
  return "";
}
function extractFirstXmlTag(xml = "", tagNames = []) {
  for (const tagName of tagNames) {
    const regex = new RegExp(`<${tagName}>([\\s\\S]*?)</${tagName}>`, "i");
    const match = String(xml || "").match(regex);
    if (match?.[1]) return stripHtml(match[1]).trim();
  }
  return "";
}

function normalizeNationalLibraryBookItem(item, index = 0) {
  const title = stripHtml(pickNationalLibraryItemValue(item, ["title_info", "title", "titleInfo"]));
  const authorInfo = stripHtml(pickNationalLibraryItemValue(item, ["author_info", "author", "authorInfo"]));
  const publisher = stripHtml(pickNationalLibraryItemValue(item, ["pub_info", "publisher", "pubInfo"]));
  const pubYear = formatPubDate(pickNationalLibraryItemValue(item, ["pub_year_info", "pub_year", "pubYear"]));
  const isbnRaw = sanitizeIsbn(pickNationalLibraryItemValue(item, ["isbn", "ea_isbn", "set_isbn"]));
  const isbn13 = extractNaverIsbn13(isbnRaw);
  const contributorMeta = parseContributorText(authorInfo);

  return {
    id: `nl-${isbn13 || normalizeSearchText(title) || index}`,
    title: title || "제목 없음",
    author: contributorMeta.author || authorInfo || "저자 정보 없음",
    translator: contributorMeta.translator || "",
    illustrator: contributorMeta.illustrator || "",
    publisher: publisher || "출판사 정보 없음",
    publicationYear: pubYear || "",
    isbn13,
    isbn: isbnRaw || "",
    description: "",
    image: "",
    link: "",
    source: "national-library"
  };
}

async function searchNationalLibraryBooks(keyword) {
  if (!NL_API_KEY) return [];

  try {
    const url = buildNationalLibraryKeywordSearchUrl(keyword, 1, 20);
    const parsed = await fetchXmlLoose(url, "NL API SEARCH");
    const items = nlExtractCandidateItems(parsed);
    return items.map(normalizeNationalLibraryBookItem).filter((item) => item.title);
  } catch (error) {
    console.error("NL_BOOK_SEARCH_ERROR:", error);
    return [];
  }
}

async function fetchNationalLibraryBookByIsbn(isbn) {
  if (!NL_API_KEY || !isbn) return null;

  try {
    const url = buildNationalLibraryIsbnSearchUrl(isbn);
    const response = await fetchWithTimeout(url);
    const xml = await response.text();

    if (!response.ok) {
      throw new Error(`외부 API 호출 실패: ${response.status}`);
    }

    const title = extractFirstXmlTag(xml, ["title_info", "title"]);
    const authorInfo = extractFirstXmlTag(xml, ["author_info", "author"]);
    const publisher = extractFirstXmlTag(xml, ["pub_info", "publisher"]);
    const pubYear = formatPubDate(extractFirstXmlTag(xml, ["pub_year_info", "pub_year"]));
    const isbnRaw = sanitizeIsbn(extractFirstXmlTag(xml, ["isbn", "ea_isbn", "set_isbn"])) || isbn;
    const contributorMeta = parseContributorText(authorInfo);

    if (!title && !authorInfo && !publisher) {
      const parsed = await parseStringPromise(xml, { explicitArray: false, trim: true, mergeAttrs: true });
      const items = nlExtractCandidateItems(parsed);
      if (!items.length) return null;
      return normalizeNationalLibraryBookItem(items[0]);
    }

    return {
      id: `nl-${extractNaverIsbn13(isbnRaw) || isbnRaw || normalizeSearchText(title)}`,
      title: title || "제목 없음",
      author: contributorMeta.author || authorInfo || "저자 정보 없음",
      translator: contributorMeta.translator || "",
      illustrator: contributorMeta.illustrator || "",
      publisher: publisher || "출판사 정보 없음",
      publicationYear: pubYear || "",
      isbn13: extractNaverIsbn13(isbnRaw),
      isbn: isbnRaw || "",
      description: "",
      image: "",
      link: "",
      source: "national-library"
    };
  } catch (error) {
    console.error("NL_BOOK_BY_ISBN_ERROR:", error);
    return null;
  }
}

function mergeBookRecord(baseBook, extraBook = {}) {
  return {
    ...baseBook,
    title: extraBook.title || baseBook.title,
    author: extraBook.author || baseBook.author,
    translator: extraBook.translator || baseBook.translator || "",
    illustrator: extraBook.illustrator || baseBook.illustrator || "",
    publisher: extraBook.publisher || baseBook.publisher,
    publicationYear: extraBook.publicationYear || baseBook.publicationYear,
    isbn13: extraBook.isbn13 || baseBook.isbn13,
    isbn: extraBook.isbn || baseBook.isbn,
    description: baseBook.description || extraBook.description || "",
    image: baseBook.image || extraBook.image || "",
    link: baseBook.link || extraBook.link || "",
    source: baseBook.source || extraBook.source || "naver"
  };
}

function scoreBookCandidateForQuery(book, keyword) {
  const q = normalizeSearchText(keyword);
  const title = normalizeSearchText(book.title);
  const author = normalizeSearchText(book.author);
  const translator = normalizeSearchText(book.translator);
  const illustrator = normalizeSearchText(book.illustrator);

  let score = 0;

  if (title === q) score += 1000;
  else if (title.startsWith(q)) score += 700;
  else if (title.includes(q)) score += 450;

  if (author === q) score += 700;
  else if (author.includes(q)) score += 320;

  if (translator === q) score += 820;
  else if (translator.includes(q)) score += 420;

  if (illustrator === q) score += 650;
  else if (illustrator.includes(q)) score += 280;

  return score;
}

function dedupeBooks(books = []) {
  const uniqueBooks = [];
  const seen = new Set();

  books.forEach((book) => {
    const key =
      book.isbn13 ||
      [
        normalizeSearchText(book.title),
        normalizeSearchText(book.author),
        normalizeSearchText(book.publisher),
        normalizeSearchText(book.publicationYear)
      ].join("|");

    if (!seen.has(key)) {
      seen.add(key);
      uniqueBooks.push(book);
    } else {
      const existingIndex = uniqueBooks.findIndex((item) => {
        const itemKey =
          item.isbn13 ||
          [
            normalizeSearchText(item.title),
            normalizeSearchText(item.author),
            normalizeSearchText(item.publisher),
            normalizeSearchText(item.publicationYear)
          ].join("|");
        return itemKey === key;
      });

      if (existingIndex >= 0) {
        uniqueBooks[existingIndex] = mergeBookRecord(uniqueBooks[existingIndex], book);
      }
    }
  });

  return uniqueBooks;
}

async function enrichBooksWithNationalLibrary(naverBooks = [], limit = NATIONAL_LIBRARY_ENRICH_LIMIT) {
  const targetBooks = naverBooks.slice(0, Math.max(0, limit));
  const untouchedBooks = naverBooks.slice(Math.max(0, limit));

  const enriched = await Promise.all(
    targetBooks.map(async (book) => {
      if (!book.isbn13) return book;
      const extra = await fetchNationalLibraryBookByIsbn(book.isbn13);
      if (!extra) return book;
      return mergeBookRecord(book, extra);
    })
  );

  return [...enriched, ...untouchedBooks];
}

async function searchHybridBooks(keyword, options = {}) {
  const {
    enrichTop = NATIONAL_LIBRARY_ENRICH_LIMIT,
    allowNationalLibraryFallback = true
  } = options;

  const naverBooks = await searchNaverBooks(keyword);

  if (!naverBooks.length && allowNationalLibraryFallback) {
    return searchNationalLibraryBooks(keyword);
  }

  const enrichedNaverBooks = await enrichBooksWithNationalLibrary(naverBooks, enrichTop);
  const merged = dedupeBooks(enrichedNaverBooks);

  return merged.sort((a, b) => {
    const scoreB = scoreBookCandidateForQuery(b, keyword);
    const scoreA = scoreBookCandidateForQuery(a, keyword);
    if (scoreB !== scoreA) return scoreB - scoreA;

    const yearA = Number(String(a.publicationYear || "").slice(0, 4) || 0);
    const yearB = Number(String(b.publicationYear || "").slice(0, 4) || 0);
    return yearB - yearA;
  });
}

/* ------------------------------
 * Abstract book recommendation search
 * ------------------------------ */

const RECOMMENDATION_THEME_DEFS = [
  {
    id: "comfort",
    label: "위로와 회복",
    patterns: [/우울/u, /슬프/u, /힘들/u, /무기력/u, /마음.*가라앉/u, /위로/u],
    queries: ["우울 마음 위로", "마음 치유 에세이", "위로가 되는 책", "힐링 소설"],
    terms: ["우울", "마음", "위로", "치유", "회복", "힐링", "감정"]
  },
  {
    id: "anxiety",
    label: "불안과 마음 안정",
    patterns: [/불안/u, /걱정/u, /초조/u, /긴장/u],
    queries: ["불안 심리", "마음 안정", "걱정 내려놓기", "명상 에세이"],
    terms: ["불안", "걱정", "마음", "안정", "명상", "심리"]
  },
  {
    id: "loneliness",
    label: "외로움과 관계",
    patterns: [/외로/u, /혼자/u, /관계/u, /사람.*힘/u],
    queries: ["외로움 위로", "혼자 마음 에세이", "관계 심리", "사람 관계 책"],
    terms: ["외로움", "혼자", "관계", "사람", "마음", "위로"]
  },
  {
    id: "burnout",
    label: "스트레스와 번아웃",
    patterns: [/스트레스/u, /번아웃/u, /지쳤/u, /피곤/u, /휴식/u],
    queries: ["번아웃 회복", "스트레스 관리", "마음 휴식 에세이", "쉼이 필요한 순간"],
    terms: ["스트레스", "번아웃", "회복", "휴식", "쉼", "마음"]
  },
  {
    id: "selfesteem",
    label: "자존감과 자기돌봄",
    patterns: [/자존감/u, /자신감/u, /나를.*사랑/u, /자기.*돌봄/u],
    queries: ["자존감", "자기돌봄", "나를 사랑하는 법", "마음 자존감"],
    terms: ["자존감", "자기돌봄", "자신감", "나", "마음"]
  },
  {
    id: "sleep",
    label: "잠과 밤의 독서",
    patterns: [/잠\s*안/u, /불면/u, /수면/u, /밤에/u],
    queries: ["잠 수면", "불면증", "밤에 읽는 에세이", "잠들기 전 책"],
    terms: ["잠", "수면", "불면", "밤", "휴식"]
  },
  {
    id: "beginner",
    label: "입문과 기초",
    patterns: [/입문/u, /처음/u, /초보/u, /기초/u, /쉽게/u, /공부/u],
    queries: ["입문 기초", "처음 시작하는", "쉽게 배우는", "기초 교양"],
    terms: ["입문", "기초", "처음", "초보", "쉽게", "교양"]
  },
  {
    id: "children",
    label: "어린이·청소년",
    patterns: [/초등학생/u, /청소년/u, /아이/u, /어린이/u, /중학생/u, /고등학생/u],
    queries: ["초등학생 추천도서", "청소년 추천도서", "어린이 문학", "청소년 문학"],
    terms: ["초등학생", "청소년", "어린이", "아이", "문학"]
  }
];

const RECOMMENDATION_GENRE_DEFS = [
  { label: "소설", pattern: /소설/u, terms: ["소설"] },
  { label: "에세이", pattern: /에세이|산문/u, terms: ["에세이", "산문"] },
  { label: "시", pattern: /시집|시\s/u, terms: ["시집", "시"] },
  { label: "그림책", pattern: /그림책/u, terms: ["그림책"] },
  { label: "만화", pattern: /만화|웹툰/u, terms: ["만화"] },
  { label: "인문", pattern: /인문|철학/u, terms: ["인문", "철학"] },
  { label: "경제", pattern: /경제|투자|재테크/u, terms: ["경제", "투자", "재테크"] },
  { label: "과학", pattern: /과학/u, terms: ["과학"] },
  { label: "역사", pattern: /역사/u, terms: ["역사"] }
];

function compactUnique(values = [], limit = Infinity) {
  const seen = new Set();
  const result = [];

  for (const value of values) {
    const text = String(value || "").replace(/\s+/g, " ").trim();
    const key = normalizeSearchText(text);
    if (!text || !key || seen.has(key)) continue;
    seen.add(key);
    result.push(text);
    if (result.length >= limit) break;
  }

  return result;
}

function stripRecommendationPromptWords(query = "") {
  return String(query || "")
    .replace(/책|도서|자료|읽을거리/g, " ")
    .replace(KOREAN_REQUEST_TAIL_PATTERN, " ")
    .replace(/골라\s*(?:줘|주세요|줄래요?|주실래요?)?|추천\s*좀/g, " ")
    .replace(/읽을\s*만한|읽기\s*좋은|보기\s*좋은|볼\s*만한|도움\s*되는|공부하기\s*좋은/g, " ")
    .replace(/할\s*때|일\s*때|때/g, " ")
    .replace(/[?？!！]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function buildRecommendationSearchPlan(rawQuery = "") {
  const query = String(rawQuery || "").trim();
  const themeMatches = RECOMMENDATION_THEME_DEFS.filter((theme) =>
    theme.patterns.some((pattern) => pattern.test(query))
  );
  const genreMatches = RECOMMENDATION_GENRE_DEFS.filter((genre) => genre.pattern.test(query));
  const cleanedQuery = stripRecommendationPromptWords(query);

  const themeQueries = themeMatches.flatMap((theme) => theme.queries);
  const themeTerms = themeMatches.flatMap((theme) => theme.terms);
  const genreTerms = genreMatches.flatMap((genre) => genre.terms);
  const labels = [...themeMatches.map((theme) => theme.label), ...genreMatches.map((genre) => genre.label)];

  let searchQueries = [];

  if (themeQueries.length) {
    const primaryGenre = genreMatches[0]?.label || "";
    searchQueries = themeQueries.map((item) => primaryGenre && !item.includes(primaryGenre) ? `${item} ${primaryGenre}` : item);
  }

  if (cleanedQuery && normalizeSearchText(cleanedQuery).length >= 2) {
    searchQueries.unshift(`${cleanedQuery} 책`);
    if (/입문|처음|초보|기초|공부/u.test(query) && !/입문|기초/u.test(cleanedQuery)) {
      searchQueries.unshift(`${cleanedQuery} 입문`);
    }
  }

  if (!searchQueries.length) {
    searchQueries = ["읽을만한 책", "추천도서", "베스트셀러", "에세이 추천"];
  }

  return {
    originalQuery: query,
    cleanedQuery,
    searchQueries: compactUnique(searchQueries, BOOK_RECOMMENDATION_MAX_SEARCH_QUERIES),
    terms: compactUnique([cleanedQuery, ...themeTerms, ...genreTerms].filter(Boolean), 20),
    labels: compactUnique(labels, 5)
  };
}

function scoreBookForRecommendation(book, plan) {
  const haystack = normalizeSearchText([
    book.title,
    book.author,
    book.publisher,
    book.description,
    book.publicationYear
  ].filter(Boolean).join(" "));

  let score = 0;
  const matchedTerms = [];

  for (const term of plan.terms || []) {
    const normalizedTerm = normalizeSearchText(term);
    if (!normalizedTerm || normalizedTerm.length < 2) continue;

    if (haystack.includes(normalizedTerm)) {
      matchedTerms.push(term);
      score += normalizedTerm.length >= 4 ? 90 : 55;
    }
  }

  if (book.description) score += 20;
  if (book.isbn13) score += 10;

  const year = Number(String(book.publicationYear || "").slice(0, 4) || 0);
  if (year >= 2020) score += 12;
  else if (year >= 2015) score += 8;
  else if (year >= 2010) score += 4;

  return { score, matchedTerms: compactUnique(matchedTerms, 4) };
}

function buildRecommendationReason(book, plan, matchedTerms = []) {
  if (matchedTerms.length > 0) {
    return `${matchedTerms.slice(0, 3).join(", ")} 키워드와 맞아서 골랐어요.`;
  }

  if (plan.labels?.length) {
    return `${plan.labels.slice(0, 3).join(", ")} 분위기에 맞춰 찾은 후보예요.`;
  }

  const fallback = plan.cleanedQuery || plan.originalQuery;
  return fallback ? `“${fallback}” 기준으로 찾은 후보예요.` : "추천도서 검색 결과를 바탕으로 고른 후보예요.";
}

async function getBookRecommendations(rawQuery = "") {
  const plan = buildRecommendationSearchPlan(rawQuery);
  const cacheKey = normalizeSearchText([plan.originalQuery, ...plan.searchQueries].join("|"));
  const cached = getTimedCacheValue(bookRecommendationCache, cacheKey);
  if (cached) return cached;

  const collected = [];
  let lastError = null;

  for (const searchQuery of plan.searchQueries) {
    try {
      const books = await searchHybridBooks(searchQuery, {
        enrichTop: 0,
        allowNationalLibraryFallback: true
      });
      collected.push(...books);
    } catch (error) {
      lastError = error;
      console.error("BOOK_RECOMMENDATION_QUERY_ERROR:", { searchQuery, message: error.message });
    }
  }

  if (!collected.length && lastError) {
    throw lastError;
  }

  const scored = dedupeBooks(collected)
    .map((book) => {
      const { score, matchedTerms } = scoreBookForRecommendation(book, plan);
      return {
        ...book,
        recommendationScore: score,
        recommendationReason: buildRecommendationReason(book, plan, matchedTerms)
      };
    })
    .sort((a, b) => {
      if ((b.recommendationScore || 0) !== (a.recommendationScore || 0)) {
        return (b.recommendationScore || 0) - (a.recommendationScore || 0);
      }
      const yearA = Number(String(a.publicationYear || "").slice(0, 4) || 0);
      const yearB = Number(String(b.publicationYear || "").slice(0, 4) || 0);
      return yearB - yearA;
    })
    .slice(0, BOOK_RECOMMENDATION_RESULT_LIMIT);

  const hasMoodQuery = /(우울|불안|힘들|지쳤|외로|슬플|무기력|스트레스|번아웃)/u.test(plan.originalQuery);
  const result = {
    books: scored,
    plan,
    message: plan.labels.length
      ? `“${plan.originalQuery}”에 맞춰 ${plan.labels.slice(0, 3).join(", ")} 키워드로 찾아봤어요.`
      : `“${plan.originalQuery}”에 맞춰 추천 도서 후보를 찾아봤어요.`,
    note: hasMoodQuery
      ? "이 결과는 독서 추천 검색이에요. 마음이 오래 힘들거나 일상에 지장이 있다면 가까운 사람이나 전문가에게 도움을 청하는 것도 좋아요."
      : "추천 결과는 서지 검색을 바탕으로 한 후보라, 실제 선호와 다를 수 있어요."
  };

  setTimedCacheValue(bookRecommendationCache, cacheKey, result, BOOK_RECOMMENDATION_CACHE_TTL_MS);
  return result;
}

/* ------------------------------
 * OpenAI book explanation
 * ------------------------------ */

function buildBookExplainMessages(book, userMessage) {
  const description = String(book.description || "").trim();
  return [
    {
      role: "system",
      content: [
        "너는 도서관 안내 서비스의 책 설명 도우미다.",
        "반드시 제공된 책 정보만 바탕으로 답해.",
        "없는 내용은 절대 추가하지 마.",
        "추측하거나 해석을 덧붙이지 마.",
        '존댓말로 2~4문장으로 짧게 설명해. 문장 끝은 "-입니다", "-합니다", "-요"처럼 자연스러운 높임말을 써.'
      ].join(" ")
    },
    {
      role: "developer",
      content: [
        `제목: ${book.title || ""}`,
        `저자: ${book.author || ""}`,
        `역자: ${book.translator || ""}`,
        `그림: ${book.illustrator || ""}`,
        `출판사: ${book.publisher || ""}`,
        `출간일: ${book.publicationYear || ""}`,
        `책 소개: ${description}`
      ].join("\n")
    },
    {
      role: "user",
      content: userMessage
    }
  ];
}

async function getOpenAIBookExplanation(book, userMessage) {
  if (!openai) return null;

  // description 없을 때는 기본 서지정보만으로 간략 소개 요청
  const hasDescription = Boolean(String(book.description || "").trim());
  const messages = hasDescription
    ? buildBookExplainMessages(book, userMessage)
    : [
        {
          role: "system",
          content: [
            "너는 도서관 안내 서비스의 책 설명 도우미다.",
            "제공된 서지정보(제목, 저자, 출판사, 출간일)만을 바탕으로 책을 간략히 소개해.",
            "상세 소개 데이터가 없으므로, 제목과 저자 정보로 유추할 수 있는 수준의 간단한 안내만 해.",
            "추측이나 없는 내용은 덧붙이지 마. 모르면 모른다고 해.",
            '존댓말로 2~3문장으로 짧게. 문장 끝은 "-입니다", "-합니다"처럼 자연스러운 높임말을 써.'
          ].join(" ")
        },
        {
          role: "developer",
          content: [
            `제목: ${book.title || ""}`,
            `저자: ${book.author || ""}`,
            `역자: ${book.translator || ""}`,
            `출판사: ${book.publisher || ""}`,
            `출간일: ${book.publicationYear || ""}`
          ].join("\n")
        },
        { role: "user", content: userMessage }
      ];

  try {
    const response = await openai.responses.create({
      model: "gpt-4o-mini",
      input: messages
    });
    const text = String(response.output_text || "").trim();
    return text || null;
  } catch (err) {
    console.error("GPT_BOOK_EXPLAIN_ERROR:", err.message);
    return null;
  }
}

/* ------------------------------
 * Data4Library
 * ------------------------------ */

function buildLibrarySearchUrl(isbn13, region = "", pageNo = 1, pageSize = 100) {
  const url = new URL("http://data4library.kr/api/libSrchByBook");
  url.searchParams.set("authKey", DATA4LIBRARY_API_KEY);
  url.searchParams.set("isbn", isbn13);
  if (region) {
    url.searchParams.set("region", region);
  }
  url.searchParams.set("pageNo", String(pageNo));
  url.searchParams.set("pageSize", String(pageSize));
  return url.toString();
}

function buildLibraryKeywordSearchUrl(region = "", pageNo = 1, pageSize = 100, dtlRegion = "") {
  const url = new URL("http://data4library.kr/api/libSrch");
  url.searchParams.set("authKey", DATA4LIBRARY_API_KEY);
  if (region) {
    url.searchParams.set("region", region);
  }
  if (dtlRegion) {
    url.searchParams.set("dtl_region", dtlRegion);
  }
  url.searchParams.set("pageNo", String(pageNo));
  url.searchParams.set("pageSize", String(pageSize));
  return url.toString();
}

function normalizeLibraryResults(raw) {
  const libs = forceArray(raw?.response?.libs?.lib);

  return libs.map((lib, index) => ({
    id: lib?.libCode || `lib-${index}`,
    name: lib?.libName || "도서관명 없음",
    address: lib?.address || "주소 정보 없음",
    tel: lib?.tel || "전화번호 정보 없음",
    homepage: lib?.homepage || "",
    closed: lib?.closed || ""
  }));
}

function normalizeLibrarySearchResults(raw) {
  const libs = forceArray(raw?.response?.libs?.lib);

  return libs.map((lib, index) => ({
    id: lib?.libCode || `lib-${index}`,
    name: lib?.libName || "도서관명 없음",
    address: lib?.address || "주소 정보 없음",
    tel: lib?.tel || "전화번호 정보 없음",
    homepage: lib?.homepage || "",
    closed: lib?.closed || ""
  }));
}

function readPageInfo(raw) {
  const response = raw?.response || {};
  const pageNo = Number(response.pageNo || 1);
  const pageSize = Number(response.pageSize || 100);
  const numFound = Number(response.numFound || 0);
  const resultNum = Number(response.resultNum || 0);
  const totalPages = numFound > 0 ? Math.ceil(numFound / Math.max(pageSize, 1)) : 1;

  return {
    pageNo,
    pageSize,
    numFound,
    resultNum,
    totalPages: Math.max(totalPages, 1)
  };
}

async function fetchPagedLibraryKeywordResults(region = "", maxPages = 12, dtlRegion = "") {
  const pageSize = 100;
  const cacheKey = `${region || "nationwide"}::${dtlRegion || "all"}::${maxPages}`;
  const cached = getTimedCacheValue(libraryKeywordFetchCache, cacheKey);
  if (cached) return cached;

  const all = [];
  let totalPages = 1;

  for (let pageNo = 1; pageNo <= Math.min(totalPages, maxPages); pageNo += 1) {
    const requestUrl = buildLibraryKeywordSearchUrl(region, pageNo, pageSize, dtlRegion);
    console.log("[LIB KEYWORD REQUEST]", { region, dtlRegion, pageNo, requestUrl: maskAuthKeyInUrl(requestUrl) });

    const data = await fetchXml(requestUrl);

    console.log("[LIB KEYWORD RESPONSE KEYS]", Object.keys(data || {}));

    const pageInfo = readPageInfo(data);
    totalPages = pageInfo.totalPages;
    const libs = normalizeLibrarySearchResults(data);

    console.log("[LIB KEYWORD PAGE RESULT]", {
      region,
      dtlRegion,
      pageNo,
      numFound: pageInfo.numFound,
      resultNum: pageInfo.resultNum,
      libsLength: libs.length
    });

    all.push(...libs);

    if (libs.length < pageSize && pageNo >= totalPages) {
      break;
    }
  }

  const deduped = dedupeLibraries(all);
  setTimedCacheValue(libraryKeywordFetchCache, cacheKey, deduped, LIBRARY_KEYWORD_FETCH_CACHE_TTL_MS);
  return deduped;
}

async function runWithConcurrency(items = [], concurrency = 3, mapper) {
  const results = new Array(items.length);
  let cursor = 0;

  async function worker() {
    while (cursor < items.length) {
      const currentIndex = cursor;
      cursor += 1;
      results[currentIndex] = await mapper(items[currentIndex], currentIndex);
    }
  }

  const workerCount = Math.min(Math.max(1, concurrency), Math.max(1, items.length));
  await Promise.all(Array.from({ length: workerCount }, () => worker()));
  return results;
}

async function fetchLibraryByBookPage(isbn, region = "", pageNo = 1, pageSize = 100) {
  const requestUrl = buildLibrarySearchUrl(isbn, region, pageNo, pageSize);
  console.log("[LIB BY BOOK REQUEST]", { isbn, region, pageNo, requestUrl: maskAuthKeyInUrl(requestUrl) });

  const data = await fetchXml(requestUrl);
  const pageInfo = readPageInfo(data);
  const libs = normalizeLibraryResults(data);

  console.log("[LIB BY BOOK PAGE RESULT]", {
    isbn,
    region,
    pageNo,
    numFound: pageInfo.numFound,
    resultNum: pageInfo.resultNum,
    libsLength: libs.length
  });

  return { pageNo, pageInfo, libs };
}

async function fetchPagedLibrariesByBookInRegion(isbn, region = "", maxPages = null) {
  const pageSize = 100;
  const resolvedMaxPages = Math.max(1, maxPages || LIBRARY_BY_BOOK_MAX_PAGES_WITH_REGION);

  const firstPage = await fetchLibraryByBookPage(isbn, region, 1, pageSize);
  const totalPages = Math.max(1, firstPage.pageInfo.totalPages || 1);
  const pagesToFetch = Math.min(totalPages, resolvedMaxPages);
  const remainingPages = [];

  for (let pageNo = 2; pageNo <= pagesToFetch; pageNo += 1) {
    remainingPages.push(pageNo);
  }

  const remainingResults = remainingPages.length > 0
    ? await runWithConcurrency(
        remainingPages,
        LIBRARY_BY_BOOK_FETCH_CONCURRENCY,
        (pageNo) => fetchLibraryByBookPage(isbn, region, pageNo, pageSize)
      )
    : [];

  const pageResults = [firstPage, ...remainingResults].sort((a, b) => a.pageNo - b.pageNo);
  const libraries = pageResults.flatMap((item) => item.libs);

  return {
    libraries,
    region,
    totalCount: firstPage.pageInfo.numFound || libraries.length,
    totalPages,
    fetchedPages: pageResults.length,
    fetchedCount: libraries.length,
    partial: pagesToFetch < totalPages
  };
}

async function fetchNationwideLibrariesByBook(isbn) {
  const regionResults = await runWithConcurrency(
    DATA4LIBRARY_REGION_CODES,
    LIBRARY_BY_BOOK_NATIONWIDE_REGION_CONCURRENCY,
    async (region) => {
      try {
        return await fetchPagedLibrariesByBookInRegion(
          isbn,
          region,
          LIBRARY_BY_BOOK_MAX_PAGES_PER_REGION_NATIONWIDE
        );
      } catch (error) {
        console.error("LIB BY BOOK NATIONWIDE REGION ERROR:", { isbn, region, message: error.message });
        return { region, error: error.message, libraries: [], totalCount: 0, totalPages: 0, fetchedPages: 0, fetchedCount: 0, partial: true };
      }
    }
  );

  const successfulResults = regionResults.filter((item) => !item.error);
  const regionErrors = regionResults.filter((item) => item.error).map((item) => ({ region: item.region, error: item.error }));

  if (!successfulResults.length && regionErrors.length) {
    throw new Error(regionErrors[0].error || "전국 소장도서 조회에 실패했습니다.");
  }

  const libraries = regionResults.flatMap((item) => item.libraries || []);

  return {
    libraries,
    totalCount: regionResults.reduce((sum, item) => sum + (Number(item.totalCount) || 0), 0),
    totalPages: regionResults.reduce((sum, item) => sum + (Number(item.totalPages) || 0), 0),
    fetchedPages: regionResults.reduce((sum, item) => sum + (Number(item.fetchedPages) || 0), 0),
    fetchedCount: libraries.length,
    partial: regionResults.some((item) => item.partial) || regionErrors.length > 0,
    regionsSearched: DATA4LIBRARY_REGION_CODES.length,
    regionErrors
  };
}

async function fetchPagedLibrariesByBook(isbn, region = "", maxPages = null) {
  if (!region) {
    return fetchNationwideLibrariesByBook(isbn);
  }

  return fetchPagedLibrariesByBookInRegion(isbn, region, maxPages);
}




const DETAILED_REGION_MAP = [
  // 서울 (11)
  { names: ["종로구", "종로"], region: "11", dtlRegion: "11010", districtName: "종로구", exclude: ["태종로"] },
  { names: ["중구"], region: "11", dtlRegion: "11020", districtName: "중구" },
  { names: ["용산구", "용산"], region: "11", dtlRegion: "11030", districtName: "용산구" },
  { names: ["성동구", "성동"], region: "11", dtlRegion: "11040", districtName: "성동구" },
  { names: ["광진구", "광진"], region: "11", dtlRegion: "11050", districtName: "광진구" },
  { names: ["동대문구", "동대문"], region: "11", dtlRegion: "11060", districtName: "동대문구" },
  { names: ["중랑구", "중랑"], region: "11", dtlRegion: "11070", districtName: "중랑구" },
  { names: ["성북구", "성북"], region: "11", dtlRegion: "11080", districtName: "성북구" },
  { names: ["강북구", "강북"], region: "11", dtlRegion: "11090", districtName: "강북구" },
  { names: ["도봉구", "도봉"], region: "11", dtlRegion: "11100", districtName: "도봉구" },
  { names: ["노원구", "노원"], region: "11", dtlRegion: "11110", districtName: "노원구" },
  { names: ["은평구", "은평"], region: "11", dtlRegion: "11120", districtName: "은평구" },
  { names: ["서대문구", "서대문"], region: "11", dtlRegion: "11130", districtName: "서대문구" },
  { names: ["마포구", "마포"], region: "11", dtlRegion: "11140", districtName: "마포구" },
  { names: ["양천구", "양천"], region: "11", dtlRegion: "11150", districtName: "양천구" },
  { names: ["강서구", "강서"], region: "11", dtlRegion: "11160", districtName: "강서구" },
  { names: ["구로구", "구로"], region: "11", dtlRegion: "11170", districtName: "구로구" },
  { names: ["금천구", "금천"], region: "11", dtlRegion: "11180", districtName: "금천구" },
  { names: ["영등포구", "영등포"], region: "11", dtlRegion: "11190", districtName: "영등포구" },
  { names: ["동작구", "동작"], region: "11", dtlRegion: "11200", districtName: "동작구" },
  { names: ["관악구", "관악"], region: "11", dtlRegion: "11210", districtName: "관악구" },
  { names: ["서초구", "서초"], region: "11", dtlRegion: "11220", districtName: "서초구" },
  { names: ["강남구", "강남"], region: "11", dtlRegion: "11230", districtName: "강남구" },
  { names: ["송파구", "송파"], region: "11", dtlRegion: "11240", districtName: "송파구" },
  { names: ["강동구", "강동"], region: "11", dtlRegion: "11250", districtName: "강동구" },
  // 부산 (21)
  { names: ["중구"], region: "21", dtlRegion: "21010", districtName: "중구" },
  { names: ["서구"], region: "21", dtlRegion: "21020", districtName: "서구" },
  { names: ["동구"], region: "21", dtlRegion: "21030", districtName: "동구" },
  { names: ["영도구", "영도"], region: "21", dtlRegion: "21040", districtName: "영도구" },
  { names: ["부산진구", "부산진"], region: "21", dtlRegion: "21050", districtName: "부산진구" },
  { names: ["동래구", "동래"], region: "21", dtlRegion: "21060", districtName: "동래구" },
  { names: ["남구"], region: "21", dtlRegion: "21070", districtName: "남구" },
  { names: ["북구"], region: "21", dtlRegion: "21080", districtName: "북구" },
  { names: ["해운대구", "해운대"], region: "21", dtlRegion: "21090", districtName: "해운대구" },
  { names: ["사하구", "사하"], region: "21", dtlRegion: "21100", districtName: "사하구" },
  { names: ["금정구", "금정"], region: "21", dtlRegion: "21110", districtName: "금정구" },
  { names: ["강서구"], region: "21", dtlRegion: "21120", districtName: "강서구" },
  { names: ["연제구", "연제"], region: "21", dtlRegion: "21130", districtName: "연제구" },
  { names: ["수영구", "수영"], region: "21", dtlRegion: "21140", districtName: "수영구" },
  { names: ["사상구", "사상"], region: "21", dtlRegion: "21150", districtName: "사상구" },
  { names: ["기장군", "기장"], region: "21", dtlRegion: "21310", districtName: "기장군" },
  // 대구 (22)
  { names: ["중구"], region: "22", dtlRegion: "22010", districtName: "중구" },
  { names: ["동구"], region: "22", dtlRegion: "22020", districtName: "동구" },
  { names: ["서구"], region: "22", dtlRegion: "22030", districtName: "서구" },
  { names: ["남구"], region: "22", dtlRegion: "22040", districtName: "남구" },
  { names: ["북구"], region: "22", dtlRegion: "22050", districtName: "북구" },
  { names: ["수성구", "수성"], region: "22", dtlRegion: "22060", districtName: "수성구" },
  { names: ["달서구", "달서"], region: "22", dtlRegion: "22070", districtName: "달서구" },
  { names: ["달성군", "달성"], region: "22", dtlRegion: "22310", districtName: "달성군" },
  // 인천 (23)
  { names: ["중구"], region: "23", dtlRegion: "23010", districtName: "중구" },
  { names: ["동구"], region: "23", dtlRegion: "23020", districtName: "동구" },
  { names: ["미추홀구", "미추홀"], region: "23", dtlRegion: "23030", districtName: "미추홀구" },
  { names: ["연수구", "연수"], region: "23", dtlRegion: "23040", districtName: "연수구" },
  { names: ["남동구", "남동"], region: "23", dtlRegion: "23050", districtName: "남동구" },
  { names: ["부평구", "부평"], region: "23", dtlRegion: "23060", districtName: "부평구" },
  { names: ["계양구", "계양"], region: "23", dtlRegion: "23070", districtName: "계양구" },
  { names: ["서구"], region: "23", dtlRegion: "23080", districtName: "서구" },
  { names: ["강화군", "강화"], region: "23", dtlRegion: "23310", districtName: "강화군" },
  { names: ["옹진군", "옹진"], region: "23", dtlRegion: "23320", districtName: "옹진군" },
  // 광주 (24)
  { names: ["동구"], region: "24", dtlRegion: "24010", districtName: "동구" },
  { names: ["서구"], region: "24", dtlRegion: "24020", districtName: "서구" },
  { names: ["남구"], region: "24", dtlRegion: "24030", districtName: "남구" },
  { names: ["북구"], region: "24", dtlRegion: "24040", districtName: "북구" },
  { names: ["광산구", "광산"], region: "24", dtlRegion: "24050", districtName: "광산구" },
  // 대전 (25)
  { names: ["동구"], region: "25", dtlRegion: "25010", districtName: "동구" },
  { names: ["중구"], region: "25", dtlRegion: "25020", districtName: "중구" },
  { names: ["서구"], region: "25", dtlRegion: "25030", districtName: "서구" },
  { names: ["유성구", "유성"], region: "25", dtlRegion: "25040", districtName: "유성구" },
  { names: ["대덕구", "대덕"], region: "25", dtlRegion: "25050", districtName: "대덕구" },
  // 울산 (26)
  { names: ["중구"], region: "26", dtlRegion: "26010", districtName: "중구" },
  { names: ["남구"], region: "26", dtlRegion: "26020", districtName: "남구" },
  { names: ["동구"], region: "26", dtlRegion: "26030", districtName: "동구" },
  { names: ["북구"], region: "26", dtlRegion: "26040", districtName: "북구" },
  { names: ["울주군", "울주"], region: "26", dtlRegion: "26310", districtName: "울주군" },
  // 경기 (31) - 주요 시/군
  { names: ["수원시", "수원"], region: "31", dtlRegion: "31010", districtName: "수원시" },
  { names: ["성남시", "성남"], region: "31", dtlRegion: "31020", districtName: "성남시" },
  { names: ["의정부시", "의정부"], region: "31", dtlRegion: "31030", districtName: "의정부시" },
  { names: ["안양시", "안양"], region: "31", dtlRegion: "31040", districtName: "안양시" },
  { names: ["부천시", "부천"], region: "31", dtlRegion: "31050", districtName: "부천시" },
  { names: ["광명시", "광명"], region: "31", dtlRegion: "31060", districtName: "광명시" },
  { names: ["평택시", "평택"], region: "31", dtlRegion: "31070", districtName: "평택시" },
  { names: ["동두천시", "동두천"], region: "31", dtlRegion: "31080", districtName: "동두천시" },
  { names: ["안산시", "안산"], region: "31", dtlRegion: "31090", districtName: "안산시" },
  { names: ["고양시", "고양"], region: "31", dtlRegion: "31100", districtName: "고양시" },
  { names: ["과천시", "과천"], region: "31", dtlRegion: "31110", districtName: "과천시" },
  { names: ["구리시", "구리"], region: "31", dtlRegion: "31120", districtName: "구리시" },
  { names: ["남양주시", "남양주"], region: "31", dtlRegion: "31130", districtName: "남양주시" },
  { names: ["오산시", "오산"], region: "31", dtlRegion: "31140", districtName: "오산시" },
  { names: ["시흥시", "시흥"], region: "31", dtlRegion: "31150", districtName: "시흥시" },
  { names: ["군포시", "군포"], region: "31", dtlRegion: "31160", districtName: "군포시" },
  { names: ["의왕시", "의왕"], region: "31", dtlRegion: "31170", districtName: "의왕시" },
  { names: ["하남시", "하남"], region: "31", dtlRegion: "31180", districtName: "하남시" },
  { names: ["용인시", "용인"], region: "31", dtlRegion: "31190", districtName: "용인시" },
  { names: ["파주시", "파주"], region: "31", dtlRegion: "31200", districtName: "파주시" },
  { names: ["이천시", "이천"], region: "31", dtlRegion: "31210", districtName: "이천시" },
  { names: ["안성시", "안성"], region: "31", dtlRegion: "31220", districtName: "안성시" },
  { names: ["김포시", "김포"], region: "31", dtlRegion: "31230", districtName: "김포시" },
  { names: ["화성시", "화성"], region: "31", dtlRegion: "31240", districtName: "화성시" },
  { names: ["광주시", "광주"], region: "31", dtlRegion: "31250", districtName: "광주시" },
  { names: ["양주시", "양주"], region: "31", dtlRegion: "31260", districtName: "양주시" },
  { names: ["포천시", "포천"], region: "31", dtlRegion: "31270", districtName: "포천시" },
  { names: ["여주시", "여주"], region: "31", dtlRegion: "31280", districtName: "여주시" },
  { names: ["연천군", "연천"], region: "31", dtlRegion: "31350", districtName: "연천군" },
  { names: ["가평군", "가평"], region: "31", dtlRegion: "31370", districtName: "가평군" },
  { names: ["양평군", "양평"], region: "31", dtlRegion: "31380", districtName: "양평군" }
];

function getDetailedRegionHint(query = "", selectedRegion = "") {
  const raw = String(query || "").trim();
  const normalized = normalizeSearchText(raw);
  if (!normalized) return null;

  // 선택 지역 또는 쿼리에서 시도 감지
  const regionFromQuery = getRegionCodeFromText(raw, selectedRegion);
  const effectiveRegionCode = regionFromQuery || selectedRegion;

  // 해당 시도의 구/군 목록을 우선 보되, 쿼리에 다른 지역 별칭이 명확히 들어 있으면 전역 후보로 한 번 더 본다.
  const primaryDistricts = effectiveRegionCode
    ? DETAILED_REGION_MAP.filter((item) => item.region === effectiveRegionCode)
    : DETAILED_REGION_MAP;
  const fallbackDistricts = effectiveRegionCode
    ? DETAILED_REGION_MAP.filter((item) => item.region !== effectiveRegionCode)
    : [];

  const findMatch = (items) => {
    for (const item of items) {
      const hasExclude = item.exclude?.some((ex) => normalized.includes(normalizeSearchText(ex)));
      if (hasExclude) continue;
      if (item.names.some((name) => normalized.includes(normalizeSearchText(name)))) {
        return item;
      }
    }
    return null;
  };

  return findMatch(primaryDistricts) || findMatch(fallbackDistricts);
}

function getLibraryPlaceAliasRegionHint(query = "", selectedRegion = "") {
  const normalized = normalizeSearchText(query);
  if (!normalized) return null;

  for (const item of UNDERSTANDING_PLACE_ALIAS_HINTS) {
    if (!item?.region) continue;
    if (selectedRegion && selectedRegion !== item.region) continue;

    const matchedName = (item.names || []).find((name) => {
      const alias = normalizeSearchText(name);
      return alias && normalized.includes(alias);
    });
    if (!matchedName) continue;

    const aliasLabel = item.regionHint || matchedName;
    const aliasLooksLikeLocality = /동$/u.test(String(aliasLabel || ""));

    return {
      region: item.region,
      dtlRegion: "",
      districtName: aliasLooksLikeLocality ? aliasLabel : (item.districtName || aliasLabel),
      broadDistrictName: item.districtName || "",
      regionHint: aliasLabel,
      isPlaceAlias: true
    };
  }

  return null;
}


function filterLibrariesByDetailedRegion(libraries = [], hint = null) {
  if (!hint?.districtName) return libraries;

  const districtToken = normalizeSearchText(hint.districtName);
  const filtered = libraries.filter((lib) => {
    const address = normalizeSearchText(lib?.address || "");
    const name = normalizeSearchText(lib?.name || "");
    return address.includes(districtToken) || name.includes(districtToken);
  });

  return filtered.length > 0 ? filtered : libraries;
}

function buildLibrarySearchTokens(query) {
  const normalized = stripLibraryQueryNoiseFromNormalizedText(normalizeSearchText(query));

  const tokens = new Set();

  const matches =
    normalized.match(
      /(서울|부산|대구|인천|광주|대전|울산|세종|경기|강원|충북|충남|전북|전남|경북|경남|제주|[가-힣0-9]+구|[가-힣0-9]+시|[가-힣0-9]+군|[가-힣0-9]+읍|[가-힣0-9]+면|[가-힣0-9]+동|[가-힣0-9]+로|[가-힣0-9]+길|[가-힣0-9]+도서관)/g
    ) || [];

  matches.forEach((token) => {
    const cleaned = token
      .replace(/작은도서관/g, "")
      .replace(/도서관/g, "")
      .replace(/구립|시립|군립|공공/g, "")
      .trim();

    if (cleaned) tokens.add(cleaned);
  });

  const stripped = normalized
    .replace(/작은도서관/g, "")
    .replace(/도서관/g, "")
    .replace(/구립|시립|군립|공공/g, "")
    .trim();

  if (stripped) tokens.add(stripped);

  return [...tokens].filter(Boolean);
}

function inferLibraryThreshold(query, tokens = []) {
  const normalized = normalizeSearchText(query);
  if (!normalized) return 20;

  if (tokens.length === 1) {
    const token = tokens[0] || "";
    if (/[가-힣]+\d+동$/.test(token)) return 45;
    if (/[가-힣]+동$/.test(token)) return 35;
    if (/[가-힣]+(구|군|시|읍|면|로|길)$/.test(token)) return 30;
  }

  if (/도서관/.test(normalized) && hasStrongLocationToken(normalized)) return 35;
  if (hasStrongLocationToken(normalized)) return 25;
  return 20;
}

function createAddressVariants(token, options = {}) {
  const { allowReverseForNumericDong = true } = options;
  const variants = new Set([token]);

  if (/^[가-힣0-9]+동$/.test(token)) {
    const withoutDong = token.replace(/동$/, "");
    const base = withoutDong.replace(/\d+$/, "");
    const hasNumericDong = /\d+동$/.test(token);

    if (!hasNumericDong && withoutDong) {
      variants.add(withoutDong);
    }

    if (base) {
      if (!hasNumericDong) {
        variants.add(base);
        variants.add(`${base}동`);

        for (let i = 1; i <= 15; i += 1) {
          variants.add(`${base}${i}동`);
        }
      } else if (allowReverseForNumericDong) {
        variants.add(base);
        variants.add(`${base}동`);
      }
    }
  }

  if (/^[가-힣0-9]+(구|군|시)$/.test(token)) {
    variants.add(token.replace(/(구|군|시)$/, ""));
  }

  return [...variants].filter(Boolean);
}


function hasStrongLocationToken(query) {
  const text = normalizeSearchText(query);
  return /(서울|부산|대구|인천|광주|대전|울산|세종|경기|강원|충북|충남|전북|전남|경북|경남|제주|[가-힣0-9]+구|[가-힣0-9]+시|[가-힣0-9]+군|[가-힣0-9]+읍|[가-힣0-9]+면|[가-힣0-9]+동|[가-힣0-9]+로|[가-힣0-9]+길)/.test(text);
}

function buildLooseLibraryQueries(query = "") {
  const raw = String(query || "").trim();
  const normalized = stripLibraryQueryNoiseFromNormalizedText(normalizeSearchText(raw));

  const withoutLibrary = normalized.replace(/작은도서관/g, "").replace(/도서관/g, "").trim();
  const tokens = buildLibrarySearchTokens(raw);
  const candidates = new Set([normalized, withoutLibrary, ...tokens].filter(Boolean));
  return [...candidates];
}

function computeLooseLibraryScore(lib, query = "") {
  const name = normalizeSearchText(lib?.name || "");
  const address = normalizeSearchText(lib?.address || "");
  const candidates = buildLooseLibraryQueries(query);
  let score = 0;

  for (const candidate of candidates) {
    if (!candidate) continue;

    if (name === candidate) score = Math.max(score, 1000);
    else if (name.startsWith(candidate)) score = Math.max(score, 800);
    else if (name.includes(candidate)) score = Math.max(score, 650);

    if (candidate && name.includes(`${candidate}도서관`)) score = Math.max(score, 780);
    if (candidate && address.includes(candidate)) score = Math.max(score, 500);

    if (candidate.endsWith("도서관")) {
      const base = candidate.replace(/도서관$/, "");
      if (base && name.includes(base)) score = Math.max(score, 700);
      if (base && address.includes(base)) score = Math.max(score, 420);
    }
  }

  return score;
}

function dedupeLibraries(items = []) {
  const unique = [];
  const seen = new Set();

  items.forEach((lib) => {
    const id = String(lib.id || "");
    const nameAddressKey = `${normalizeSearchText(lib.name || "")}::${normalizeSearchText(lib.address || "")}`;
    const key = id && !id.startsWith("stdlib-") ? id : nameAddressKey;
    if (!key || seen.has(key)) return;
    seen.add(key);
    unique.push(lib);
  });

  return unique;
}

function scoreLibraryMatch(lib, query, options = {}) {
  const { allowReverseForNumericDong = true } = options;
  const name = normalizeSearchText(lib.name);
  const address = normalizeSearchText(lib.address);
  const tokens = buildLibrarySearchTokens(query);
  const fullQuery = stripLibraryQueryNoiseFromNormalizedText(normalizeSearchText(query));

  if (!fullQuery) return 0;

  let score = 0;
  let matchedTokens = 0;

  if (name === fullQuery) score += 240;
  else if (name.startsWith(fullQuery)) score += 180;
  else if (name.includes(fullQuery)) score += 140;

  if (address === fullQuery) score += 180;
  else if (address.startsWith(fullQuery)) score += 130;
  else if (address.includes(fullQuery)) score += 100;

  tokens.forEach((token) => {
    let matched = false;
    const variants = createAddressVariants(token, { allowReverseForNumericDong });

    if (token && address.includes(token)) {
      score += token.endsWith("동") ? 110 : 70;
    }

    if (token && name.includes(token)) {
      score += token.endsWith("도서관") ? 90 : 35;
    }

    variants.forEach((variant) => {
      if (name === variant) {
        score += 120;
        matched = true;
      } else if (name.startsWith(variant)) {
        score += 90;
        matched = true;
      } else if (name.includes(variant)) {
        score += 60;
        matched = true;
      }

      if (address.includes(variant)) {
        if (token.endsWith("동")) {
          if (/\d+동$/.test(token)) {
            score += variant === token ? 140 : 70;
          } else {
            score += variant === token ? 120 : 100;
          }
        } else if (token.endsWith("구") || token.endsWith("군") || token.endsWith("시")) {
          score += 95;
        } else {
          score += 60;
        }
        matched = true;
      }
    });

    if (matched) matchedTokens += 1;
  });

  if (tokens.length === 1 && matchedTokens === 1) {
    const token = tokens[0];
    if (token && address.includes(token) && /(구|군|시|동|읍|면|로|길)$/.test(token)) {
      score += 95;
    }
  }

  if (matchedTokens >= 2) score += 100;
  if (matchedTokens >= 3) score += 140;

  if (tokens.length >= 2 && matchedTokens < 2) {
    score -= 40;
  }

  return score;
}


function isGenericLocationLibraryQuery(query = "") {
  const raw = String(query || "").trim();
  if (!raw) return false;

  const compact = raw.replace(/\s+/g, "");
  if (isLikelyFalseAdminRegionHint(compact)) return false;

  const sido = REGION_ALIAS_REGEX_SOURCE || "서울|부산|대구|인천|광주|대전|울산|세종|경기|강원|충북|충남|전북|전남|경북|경남|제주";
  if (new RegExp(`^(?:${sido})도서관$`, "u").test(compact)) {
    return new RegExp(`^(?:${sido})\\s+도서관$`, "u").test(raw);
  }

  const adminUnit = "[가-힣0-9]{1,8}(?:구|군|시|읍|면|동)";
  const roadUnit = "[가-힣0-9]{1,8}(?:로|길)";

  if (new RegExp(`^(?:${sido})\\s+도서관$`, "u").test(raw)) return true;
  if (new RegExp(`^(?:${sido})${adminUnit}도서관$`, "u").test(compact)) return true;
  if (new RegExp(`^${adminUnit}도서관$`, "u").test(compact)) return true;
  if (new RegExp(`^${roadUnit}\\s+도서관$`, "u").test(raw)) return true;
  if (new RegExp(`^(?:${sido}|${adminUnit})$`, "u").test(compact)) return true;

  return false;
}

function isLocationPhraseLibraryQuery(query = "") {
  const text = String(query || "").trim();
  if (!text) return false;
  if (!/(도서관|작은\s*도서관|문고)/u.test(text)) return false;
  if (/(?:도서관|작은\s*도서관|문고)의\s+.{1,}/u.test(text) && !/(?:위치|주소|운영|이용|개관|휴관|전화|연락처|주차|와이파이|좌석|열람실)/u.test(text)) return false;

  const sido = REGION_ALIAS_REGEX_SOURCE || "서울|부산|대구|인천|광주|대전|울산|세종|경기|강원|충북|충남|전북|전남|경북|경남|제주";
  const compact = text.replace(/\s+/g, "");
  // 붙여 쓴 “OO도서관”은 지역 나열보다 고유 도서관명일 가능성이 높다.
  // 예: “서울도서관”, “강남도서관”, “종로도서관”.
  // 단, “중구도서관”, “대치동도서관”처럼 행정단위가 그대로 붙은 경우는 지역 검색으로 둔다.
  if (!/\s/u.test(text) && /(?:도서관|작은도서관|문고)$/u.test(compact)) {
    const stem = compact.replace(/(?:작은도서관|도서관|문고)$/u, "");
    if (stem && !/(?:구|군|시|읍|면|동|리)$/u.test(stem)) return false;
  }
  if (isLikelyFalseAdminRegionHint(compact)) return false;
  if (new RegExp(`^(?:${sido})도서관$`, "u").test(compact) && !new RegExp(`^(?:${sido})\\s+도서관$`, "u").test(text)) return false;
  if (isKnownLocalPlaceLibraryListingQuery(text)) return true;

  const locationToken = `(?:${sido}|[가-힣0-9]{1,8}(?:구|군|시|읍|면|동|리|로|길|역|학교|초등학교|중학교|고등학교|대학교|대학|병원|공원|시장|구청|시청|군청|주민센터|행정복지센터|아파트|마을|광장|터미널|공항|박물관|미술관))`;
  const naturalConnector = "(?:에|에서|의|쪽|근처|주변)?\\s*(?:있는|소재(?:한)?|위치(?:한)?|이용할\\s*수\\s*있는|이용\\s*가능한|갈\\s*수\\s*있는|갈\\s*만한|가기\\s*좋은|가까운|근처|주변|인근)?\\s*";
  const libraryNoun = "(?:공공\\s*)?(?:작은\\s*)?도서관|문고";

  if (new RegExp(`(?:${libraryNoun})\\s*(?:은|는|가|을|를)?\\s*(?:어디|어딘|어딨|위치|주소)`, "u").test(text)) return true;
  if (new RegExp(`${locationToken}${naturalConnector}(?:${libraryNoun})`, "u").test(text)) return true;
  if (new RegExp(`(?:${sido})\\s+[가-힣0-9]{2,}\\s*(?:에|에서|의)?\\s*(?:있는|소재(?:한)?|위치(?:한)?|가까운|근처|주변|인근)?\\s*(?:${libraryNoun})`, "u").test(text)) return true;

  return new RegExp(`${locationToken}`, "u").test(text) &&
    /(근처|주변|인근|가까운|있는|소재|위치|갈\s*수\s*있는|갈\s*만한|가기\s*좋은|아이랑|아이와|어린이)/u.test(text);
}

function isExplicitLibraryNameQuery(query = "") {
  const text = String(query || "").trim();
  if (!text) return false;

  const normalized = normalizeSearchText(text);
  if (!normalized) return false;
  if (isGenericLibraryOnlyQuery(text)) return false;

  const compactOfficialSmallName = !/\s/u.test(text) && /(?:작은도서관|문고)$/u.test(normalized);

  const bookishSignals = [
    "어떤 책", "무슨 책", "줄거리", "내용", "책 소개", "책이야", "책인가",
    "isbn", "저자", "작가", "출판사", "인기", "잘나가는", "대출", "많이빌린", "베스트"
  ];
  if (bookishSignals.some((signal) => normalized.includes(normalizeSearchText(signal)))) return false;

  // 붙여 쓴 작은도서관/문고 명칭은 공식 명칭일 가능성이 높다.
  // 예: 대치1작은도서관, 역삼2동작은도서관.
  if (compactOfficialSmallName) return true;

  if (isGenericLocationLibraryQuery(text) || isLocationPhraseLibraryQuery(text)) return false;

  // "강남구 공부하기 좋은 도서관"처럼 도서관으로 끝나도 실제 명칭이 아니라
  // 목적/조건을 붙인 지역 검색이면 명칭검색으로 잠그지 않는다.
  if (hasNonNameLibraryPurposeSignal(text)) return false;

  return /(도서관|작은도서관|문고)$/u.test(text);
}

function isGenericLibraryOnlyQuery(query = "") {
  const normalized = normalizeSearchText(query);
  return normalized === "도서관" || normalized === "공공도서관" || normalized === "작은도서관" || normalized === "문고";
}

function buildNeedsRegionLibrarySearchPayload() {
  return {
    libraries: [],
    searchScope: "nationwide",
    needsRegion: true,
    message: "전국 범위에서는 결과가 너무 많아집니다. 지역을 함께 입력해 주세요. 예: 서울 종로구 도서관"
  };
}

const REGION_CODE_TO_NAME = {
  "11": "서울",
  "21": "부산",
  "22": "대구",
  "23": "인천",
  "24": "광주",
  "25": "대전",
  "26": "울산",
  "29": "세종",
  "31": "경기",
  "32": "강원",
  "33": "충북",
  "34": "충남",
  "35": "전북",
  "36": "전남",
  "37": "경북",
  "38": "경남",
  "39": "제주"
};

const REGION_ALIAS_TO_CODE = {
  서울: "11", 서울시: "11", 서울특별시: "11",
  부산: "21", 부산시: "21", 부산광역시: "21",
  대구: "22", 대구시: "22", 대구광역시: "22",
  인천: "23", 인천시: "23", 인천광역시: "23",
  광주: "24", 광주광역시: "24",
  대전: "25", 대전시: "25", 대전광역시: "25",
  울산: "26", 울산시: "26", 울산광역시: "26",
  세종: "29", 세종시: "29", 세종특별자치시: "29",
  경기: "31", 경기도: "31",
  강원: "32", 강원도: "32", 강원특별자치도: "32",
  충북: "33", 충청북도: "33",
  충남: "34", 충청남도: "34",
  전북: "35", 전라북도: "35", 전북특별자치도: "35",
  전남: "36", 전라남도: "36",
  경북: "37", 경상북도: "37",
  경남: "38", 경상남도: "38",
  제주: "39", 제주도: "39", 제주특별자치도: "39"
};

const REGION_NAME_TO_CODE = Object.fromEntries(
  Object.entries(REGION_ALIAS_TO_CODE).map(([name, code]) => [normalizeSearchText(name), code])
);

const REGION_ALIAS_ENTRIES = Object.entries(REGION_ALIAS_TO_CODE)
  .map(([name, code]) => ({ name, code, normalized: normalizeSearchText(name) }))
  .sort((a, b) => b.normalized.length - a.normalized.length);

const REGION_ALIAS_REGEX_SOURCE = REGION_ALIAS_ENTRIES
  .map((item) => escapeRegExp(item.name))
  .join("|");

function getRegionCodeByName(name = "") {
  return REGION_NAME_TO_CODE[normalizeSearchText(name)] || "";
}

function getRegionCodeFromName(name = "") {
  return getRegionCodeByName(name);
}

function getRegionCodeFromText(text = "", selectedRegion = "") {
  const raw = String(text || "").trim();
  const normalized = normalizeSearchText(raw);
  if (!normalized) return "";

  const selected = sanitizeRegionCode(selectedRegion || "");

  if (selected && Array.isArray(DETAILED_REGION_MAP)) {
    const selectedDetail = DETAILED_REGION_MAP.find((item) =>
      item.region === selected && item.names.some((name) => normalizeSearchText(name) === normalized)
    );
    if (selectedDetail) return selected;
  }

  const compound = getCompoundDetailedRegionHint(raw, selected);
  if (compound?.region) return compound.region;

  const exactRegionCode = REGION_NAME_TO_CODE[normalized];
  if (exactRegionCode) return exactRegionCode;

  const rawTokens = raw.split(/[^가-힣0-9]+/u).map((token) => normalizeSearchText(token)).filter(Boolean);
  for (const token of rawTokens) {
    if (selected && Array.isArray(DETAILED_REGION_MAP)) {
      const selectedDetail = DETAILED_REGION_MAP.find((item) =>
        item.region === selected && item.names.some((name) => normalizeSearchText(name) === token)
      );
      if (selectedDetail) return selected;
    }
    const code = REGION_NAME_TO_CODE[token];
    if (code) return code;
  }

  if (Array.isArray(DETAILED_REGION_MAP)) {
    for (const token of rawTokens.length ? rawTokens : [normalized]) {
      const matches = DETAILED_REGION_MAP.filter((item) =>
        item.names.some((name) => normalizeSearchText(name) === token)
      );
      if (selected) {
        const selectedMatch = matches.find((item) => item.region === selected);
        if (selectedMatch?.region) return selectedMatch.region;
      }
      if (matches.length === 1 && matches[0]?.region) return matches[0].region;
    }
  }

  const place = UNDERSTANDING_PLACE_ALIAS_HINTS.find((item) =>
    item.names.some((name) => normalizeSearchText(name) === normalized)
  );
  if (place?.region) return place.region;

  return "";
}

function escapeRegExp(text = "") {
  return String(text || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function stripLeadingRegionAlias(normalizedText = "") {
  const text = normalizeSearchText(normalizedText);
  if (!text) return "";

  for (const item of REGION_ALIAS_ENTRIES) {
    if (!item.normalized) continue;
    if (text === item.normalized) return "";
    if (text.startsWith(item.normalized)) {
      return text.slice(item.normalized.length);
    }
  }

  return text;
}

function stripKnownRegionPrefixFromToken(token = "") {
  let text = normalizeSearchText(token);
  if (!text) return "";

  for (const item of REGION_ALIAS_ENTRIES) {
    if (!item.normalized) continue;
    if (text.startsWith(item.normalized) && text.length > item.normalized.length) {
      text = text.slice(item.normalized.length);
      break;
    }
  }

  return text;
}

function stripLibraryLocationTokensFromNormalizedText(normalizedText = "", constraints = {}) {
  let text = stripLeadingRegionAlias(normalizedText);
  if (!text) return "";

  const tokensToRemove = new Set();
  const addToken = (token) => {
    const normalized = normalizeSearchText(token);
    if (normalized && normalized.length >= 2) tokensToRemove.add(normalized);
  };

  addToken(constraints.sido || "");
  addToken(constraints.district || "");
  addToken(constraints.road || "");

  const normalizedDistrict = normalizeSearchText(constraints.district || "");
  if (normalizedDistrict.endsWith("구") || normalizedDistrict.endsWith("군") || normalizedDistrict.endsWith("시") || normalizedDistrict.endsWith("읍") || normalizedDistrict.endsWith("면") || normalizedDistrict.endsWith("동")) {
    addToken(normalizedDistrict.slice(0, -1));
  }

  for (const token of tokensToRemove) {
    text = text.replace(new RegExp(escapeRegExp(token), "g"), "");
  }

  return text
    .replace(/[가-힣0-9]{1,20}(?:구|군|시|읍|면|동|로|길)/g, "")
    .trim();
}

function stripLibraryQueryNoiseFromNormalizedText(text = "") {
  const cleaned = String(text || "")
    .replace(/(?:공공도서관|작은도서관|도서관|문고)(?:은|는|가|을|를)?/g, "")
    .replace(/어디(?:에서|서|에)?(?:있어|있어요|있나요|있니|있습니까|있을까|있을까요|있는데|있는지|있나|있|위치해|위치|야|임|인가요|인가|일까|죠)?|어딘(?:데|지|가요|가)?|어딨(?:어|어요|나요|니|냐|습니까|는데)?/g, "")
    .replace(/에서이용할수있는|에서이용가능한|이용할수있는|이용가능한|에서갈수있는|갈수있는|에서갈만한|갈만한|에서가기좋은|가기좋은/g, "")
    .replace(/에있는|있는|소재한|소재|위치한|위치가|위치는|위치|주소가|주소는|주소/g, "")
    .replace(/근처|주변|인근|가까운|지역|동네/g, "")
    .replace(/아이랑|아이와|아이와함께|가족과|가족이랑|어린이랑|어린이와/g, "")
    .replace(/목록|리스트|좀/g, "")
    .replace(/에서|에는|으로|에서의|의$/g, "")
    .replace(/^에|에$/g, "")
    .trim();

  return stripKoreanRequestTailFromNormalizedText(cleaned).trim();
}

function stripLibraryIntentTokensFromNormalizedText(text = "") {
  return String(text || "")
    .replace(/공부하기좋은|공부하기괜찮은|공부할수있는|공부하기|공부할|공부|열람실|좌석|자리|조용한|조용|스터디|시험|수험|노트북|집중|독서실|책읽기좋은|읽기좋은|책읽기/g, "")
    .replace(/어린이책|어린이|아동|유아|아이들|아이랑|아이와|자녀|가족|키즈|그림책|동화|초등/g, "")
    .replace(/야간운영|야간|밤까지|밤|늦게까지|늦게|늦은|저녁까지|저녁|퇴근후|오래하는|오래여는|운영하는|운영/g, "")
    .replace(/주말|토요일|토욜|일요일|일욜|공휴일|휴일|휴관일/g, "")
    .replace(/큰곳|큰데|큰|대형|넓은|규모|대표|유명한|유명|괜찮은|괜찮|좋은|추천/g, "")
    .replace(/장서많은|장서많|장서|자료많은|자료많|책많은|책많|도서많은|도서많|많은책|많은도서|소장자료|자료수|컬렉션|많은|많이/g, "")
    .replace(/작은곳|작은데|작은|마을문고|동네/g, "")
    .replace(/장애인|점자|시각장애|청각장애|농아|배리어프리|무장애/g, "")
    .replace(/만화책|만화|웹툰|그래픽노블|코믹스|코믹/g, "")
    .replace(/문화프로그램|문화|프로그램|강좌|행사|전시|공연|동아리|메이커|창작/g, "")
    .replace(/할수있는|하기좋은|하기괜찮은|하는곳|하는데|하는|되는곳|되는|많은곳|많은데|곳/g, "")
    .trim();
}


/* ------------------------------
 * 전국도서관표준데이터 XML DB
 * ------------------------------ */

function parseStandardLibraryXml(xmlPath) {
  if (!existsSync(xmlPath)) {
    console.warn("[STANDARD_LIB] XML 파일 없음:", xmlPath);
    return [];
  }
  try {
    const xml = readFileSync(xmlPath, "utf-8");
    const records = [];
    const recordRegex = /<record>([\s\S]*?)<\/record>/g;
    let match;
    while ((match = recordRegex.exec(xml)) !== null) {
      const block = match[1];
      const get = (tag) => {
        const m = block.match(new RegExp(`<${tag}>([\\s\\S]*?)<\\/${tag}>`));
        return m ? m[1].trim() : "";
      };
      const name = get("도서관명");
      if (!name) continue;
      records.push({
        id: `stdlib-${records.length}`,
        name,
        sido: get("시도명"),
        sigungu: get("시군구명"),
        libType: get("도서관유형"),
        address: get("소재지도로명주소"),
        tel: get("도서관전화번호") || "전화번호 정보 없음",
        homepage: get("홈페이지주소"),
        lat: get("위도"),
        lng: get("경도"),
        closed: get("휴관일"),
        weekdayStart: get("평일운영시작시각"),
        weekdayEnd: get("평일운영종료시각"),
        saturdayStart: get("토요일운영시작시각"),
        saturdayEnd: get("토요일운영종료시각"),
        holidayStart: get("공휴일운영시작시각"),
        holidayEnd: get("공휴일운영종료시각"),
        seatCount: parseLibraryNumber(get("열람좌석수")),
        bookCount: parseLibraryNumber(get("자료수도서")),
        periodicalCount: parseLibraryNumber(get("자료수연속간행물")),
        nonBookCount: parseLibraryNumber(get("자료수비도서")),
        loanLimit: parseLibraryNumber(get("대출가능권수")),
        loanDays: parseLibraryNumber(get("대출가능일수")),
        siteArea: parseLibraryNumber(get("부지면적")),
        buildingArea: parseLibraryNumber(get("건물면적")),
        operatingOrg: get("운영기관명"),
        dataDate: get("데이터기준일자"),
        source: "standard_xml"
      });
    }
    console.log(`[STANDARD_LIB] 로드 완료: ${records.length}개 도서관`);
    return records;
  } catch (err) {
    console.error("[STANDARD_LIB] XML 파싱 오류:", err.message);
    return [];
  }
}

function ensureStandardLibraryLoaded() {
  const now = Date.now();
  if (standardLibraryDb.length > 0 && now - standardLibraryLoadedAt < STANDARD_LIB_RELOAD_INTERVAL_MS) return;
  const loaded = parseStandardLibraryXml(STANDARD_LIB_XML_PATH);
  if (loaded.length > 0) {
    standardLibraryDb = loaded;
    standardLibraryLoadedAt = now;
  }
}

// 서버 시작 시 워밍업
try { ensureStandardLibraryLoaded(); } catch (e) { console.error("[STANDARD_LIB] 초기 로드 실패:", e.message); }

function normalizeStandardLibForResult(lib) {
  const libType = String(lib.libType || "").trim();
  // 이름이 도서관·작은도서관·문고로 끝나지 않아도 공식 등록 유형을 note에 명시
  const typeLabel = libType ? `${libType}으로 등록된 시설입니다.` : "";
  const statsNote = [
    lib.bookCount ? `도서 ${formatLibraryNumber(lib.bookCount, "권")}` : "",
    lib.seatCount ? `좌석 ${formatLibraryNumber(lib.seatCount, "석")}` : "",
    hasPositiveLibraryTime(lib.weekdayEnd) ? `평일 ${lib.weekdayEnd}까지` : ""
  ].filter(Boolean).slice(0, 3).join(" · ");

  return {
    id: lib.id,
    name: lib.name,
    address: lib.address || "주소 정보 없음",
    tel: lib.tel || "전화번호 정보 없음",
    homepage: lib.homepage || "",
    closed: lib.closed || "",
    source: "standard_xml",
    libType,
    sido: lib.sido || "",
    sigungu: lib.sigungu || "",
    weekdayStart: lib.weekdayStart || "",
    weekdayEnd: lib.weekdayEnd || "",
    saturdayStart: lib.saturdayStart || "",
    saturdayEnd: lib.saturdayEnd || "",
    holidayStart: lib.holidayStart || "",
    holidayEnd: lib.holidayEnd || "",
    seatCount: lib.seatCount ?? null,
    bookCount: lib.bookCount ?? null,
    periodicalCount: lib.periodicalCount ?? null,
    nonBookCount: lib.nonBookCount ?? null,
    loanLimit: lib.loanLimit ?? null,
    loanDays: lib.loanDays ?? null,
    siteArea: lib.siteArea ?? null,
    buildingArea: lib.buildingArea ?? null,
    operatingOrg: lib.operatingOrg || "",
    dataDate: lib.dataDate || "",
    openingHours: {
      weekday: formatLibraryHours(lib.weekdayStart, lib.weekdayEnd),
      saturday: formatLibraryHours(lib.saturdayStart, lib.saturdayEnd),
      holiday: formatLibraryHours(lib.holidayStart, lib.holidayEnd)
    },
    note: ["전국도서관표준데이터 기준", typeLabel, statsNote].filter(Boolean).join(" · ")
  };
}

const KNOWN_LIBRARY_NEARBY_PLACES = [
  {
    label: "휘문고등학교",
    aliases: ["휘문고", "휘문고등학교", "휘문중고", "휘문중고등학교", "휘문중학교"],
    address: "서울특별시 강남구 역삼로 541",
    region: "11",
    district: "강남구",
    locality: "대치동",
    lat: 37.488941,
    lng: 127.062409,
    source: "known_alias"
  }
];

function hasNearbyLibrarySignal(query = "") {
  const text = String(query || "").trim();
  const normalized = normalizeSearchText(text);
  if (!normalized) return false;

  // "강남구 도서관" 같은 일반 지역 검색은 nearby로 보지 않는다.
  // "휘문고"처럼 학교 이름 안에 들어간 "문고"는 도서관 명사로 보지 않는다.
  const hasLibraryNoun = /(?:도서관|작은\s*도서관)/u.test(text) || /(?:^|[\s,，])문고(?:$|[\s,，])/u.test(text);
  return /(근처|주변|인근|가까운|가까이에\s*있는|근방|반경|거리순)/u.test(text) && hasLibraryNoun;
}

function normalizeNearbyAnchorText(text = "") {
  return String(text || "")
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

function extractNearbyPlaceAnchorQuery(query = "") {
  if (!hasNearbyLibrarySignal(query)) return "";

  let text = stripKoreanRequestTail(normalizeNearbyAnchorText(query))
    .replace(/[?？!！]/g, " ")
    .replace(/목록/gu, " ");

  // "OO에서 가까운 도서관", "OO 근처 도서관", "OO 주변의 작은도서관" 등에서 OO만 남긴다.
  text = text
    .replace(/\s*(?:에서|로부터)?\s*(?:가까운|가까이에\s*있는|근처|주변|인근|근방|반경\s*\d+(?:\.\d+)?\s*(?:km|킬로미터|킬로|m|미터)?\s*(?:안|내)?|거리순)\s*(?:의|에|에서|있는|소재)?\s*(?:도서관|작은도서관|문고)?/gu, " ")
    .replace(/(?:도서관|작은도서관|문고)\s*(?:근처|주변|인근|가까운|근방)/gu, " ")
    .replace(/\s+/g, " ")
    .trim();

  // 위치 정보가 없으면 임의 추정하지 않는다.
  if (!text || /^(내|나|우리집|집|현재위치|여기)$/u.test(text)) return "";
  if (/^(근처|주변|인근|가까운|도서관|작은도서관|문고)$/u.test(text)) return "";

  return text.slice(0, 80);
}

function isAdministrativePlaceAnchorQuery(anchorQuery = "") {
  const text = String(anchorQuery || "").trim();
  const normalized = normalizeSearchText(text);
  if (!normalized) return false;

  if (getRegionCodeFromText(text)) return true;
  return /^[가-힣0-9]+(?:구|군|시|읍|면|동|로|길)$/u.test(text);
}

function resolveKnownNearbyPlace(query = "") {
  if (!hasNearbyLibrarySignal(query)) return null;

  const normalized = normalizeSearchText(query);
  const place = KNOWN_LIBRARY_NEARBY_PLACES.find((item) =>
    item.aliases.some((alias) => normalized.includes(normalizeSearchText(alias)))
  );

  return place ? { ...place, source: place.source || "known_alias" } : null;
}

function buildNaverLocalSearchUrl(anchorQuery = "") {
  const url = new URL("https://openapi.naver.com/v1/search/local.json");
  url.searchParams.set("query", anchorQuery);
  url.searchParams.set("display", String(NAVER_PLACE_ANCHOR_DISPLAY));
  url.searchParams.set("start", "1");
  url.searchParams.set("sort", "random");
  return url.toString();
}

function normalizeNaverCoordinate(mapx, mapy) {
  const x = Number(mapx);
  const y = Number(mapy);
  if (!Number.isFinite(x) || !Number.isFinite(y)) return null;

  const candidates = [
    { lng: x, lat: y },
    { lng: x / 1e7, lat: y / 1e7 },
    { lng: x / 1e6, lat: y / 1e6 }
  ];

  return candidates.find(({ lng, lat }) =>
    Number.isFinite(lng) && Number.isFinite(lat) &&
    lng >= 124 && lng <= 132 &&
    lat >= 33 && lat <= 39
  ) || null;
}

function inferRegionCodeFromAddress(address = "") {
  return getRegionCodeFromText(address);
}

function extractDistrictFromAddress(address = "") {
  const match = String(address || "").match(/([가-힣0-9]+(?:구|군|시))/u);
  return match?.[1] || "";
}

function extractLocalityFromAddress(address = "") {
  const matches = [...String(address || "").matchAll(/([가-힣0-9]+(?:읍|면|동))/gu)];
  return matches.length ? matches[matches.length - 1][1] : "";
}

function scoreNaverPlaceAnchorCandidate(item = {}, anchorQuery = "") {
  const title = stripHtml(item.title || "");
  const category = stripHtml(item.category || "");
  const address = stripHtml(item.roadAddress || item.address || "");
  const normalizedTitle = normalizeSearchText(title);
  const normalizedQuery = normalizeSearchText(anchorQuery);
  const normalizedAddress = normalizeSearchText(address);
  const normalizedCategory = normalizeSearchText(category);

  if (!normalizedTitle || !normalizedQuery) return -9999;

  let score = 0;
  if (normalizedTitle === normalizedQuery) score += 1200;
  else if (normalizedTitle.includes(normalizedQuery)) score += 850;
  else if (normalizedQuery.includes(normalizedTitle) && normalizedTitle.length >= 2) score += 350;

  if (normalizedAddress.includes(normalizedQuery)) score += 250;
  if (normalizedCategory) score += 20;

  if (/(학교|중학교|고등학교|대학교|역|터미널|공항|공원|광장|백화점|쇼핑|몰|병원|청사|구청|시청|도서관|박물관|미술관|시장|아파트|빌딩)/u.test(`${title} ${category}`)) {
    score += 80;
  }

  // anchor를 찾는 용도라 카페·학원·상점도 완전히 배제하지는 않지만,
  // 쿼리와 이름/주소가 전혀 맞지 않는 후보는 사용하지 않는다.
  return score;
}

function normalizeNaverPlaceAnchorItem(item = {}, anchorQuery = "") {
  const coord = normalizeNaverCoordinate(item.mapx, item.mapy);
  if (!coord) return null;

  const title = stripHtml(item.title || "");
  const address = stripHtml(item.roadAddress || item.address || "");
  const category = stripHtml(item.category || "");
  const score = scoreNaverPlaceAnchorCandidate(item, anchorQuery);

  if (score < 250) return null;

  const region = inferRegionCodeFromAddress(address);
  return {
    label: title || anchorQuery,
    aliases: [anchorQuery],
    address,
    category,
    region,
    district: extractDistrictFromAddress(address),
    locality: extractLocalityFromAddress(address),
    lat: coord.lat,
    lng: coord.lng,
    source: "naver_place_anchor",
    score
  };
}

async function resolveNaverPlaceAnchor(anchorQuery = "") {
  const normalizedAnchor = normalizeSearchText(anchorQuery);
  if (!normalizedAnchor || normalizedAnchor.length < 2) return null;
  if (!NAVER_PLACE_ANCHOR_ENABLED || !NAVER_CLIENT_ID || !NAVER_CLIENT_SECRET) return null;

  const cached = getTimedCacheValue(placeAnchorCache, normalizedAnchor);
  if (cached !== null) return cached;

  try {
    const response = await fetchWithTimeout(buildNaverLocalSearchUrl(anchorQuery), {
      headers: {
        "X-Naver-Client-Id": NAVER_CLIENT_ID,
        "X-Naver-Client-Secret": NAVER_CLIENT_SECRET
      }
    }, NAVER_PLACE_ANCHOR_TIMEOUT_MS);

    if (!response.ok) {
      throw new Error(`네이버 장소 anchor 조회 실패: ${response.status}`);
    }

    const raw = await response.json();

    const items = Array.isArray(raw?.items) ? raw.items : [];
    const candidates = items
      .map((item) => normalizeNaverPlaceAnchorItem(item, anchorQuery))
      .filter(Boolean)
      .sort((a, b) => b.score - a.score);

    const place = candidates[0] || null;
    setTimedCacheValue(placeAnchorCache, normalizedAnchor, place, PLACE_ANCHOR_CACHE_TTL_MS);
    return place;
  } catch (error) {
    console.warn("[PLACE_ANCHOR] 네이버 장소 anchor 조회 실패:", String(error?.message || error).slice(0, 200));
    setTimedCacheValue(placeAnchorCache, normalizedAnchor, null, Math.min(PLACE_ANCHOR_CACHE_TTL_MS, 1000 * 60 * 3));
    return null;
  }
}

async function resolveNearbyPlaceAnchor(query = "") {
  const knownPlace = resolveKnownNearbyPlace(query);
  if (knownPlace) return knownPlace;

  const anchorQuery = extractNearbyPlaceAnchorQuery(query);
  if (!anchorQuery) return null;

  const naverPlace = await resolveNaverPlaceAnchor(anchorQuery);
  if (naverPlace) return naverPlace;

  return null;
}

function toFiniteNumber(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function haversineDistanceKm(aLat, aLng, bLat, bLng) {
  const lat1 = toFiniteNumber(aLat);
  const lng1 = toFiniteNumber(aLng);
  const lat2 = toFiniteNumber(bLat);
  const lng2 = toFiniteNumber(bLng);
  if ([lat1, lng1, lat2, lng2].some((value) => value === null)) return null;

  const toRad = (degree) => degree * Math.PI / 180;
  const earthRadiusKm = 6371.0088;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const phi1 = toRad(lat1);
  const phi2 = toRad(lat2);

  const h = Math.sin(dLat / 2) ** 2 +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(dLng / 2) ** 2;

  return 2 * earthRadiusKm * Math.asin(Math.sqrt(h));
}

function formatDistanceKm(distanceKm) {
  if (!Number.isFinite(distanceKm)) return "거리 정보 없음";
  if (distanceKm < 1) return `약 ${Math.round(distanceKm * 1000)}m`;
  return `약 ${distanceKm.toFixed(1)}km`;
}

function buildNearbyLibrarySearchPayload(query = "", place = null) {
  if (!place) return null;

  ensureStandardLibraryLoaded();

  const placeRegionName = REGION_CODE_TO_NAME[place.region] || "";
  const nearbyLibraries = standardLibraryDb
    .map((lib) => {
      const distanceKm = haversineDistanceKm(place.lat, place.lng, lib.lat, lib.lng);
      return { ...lib, distanceKm };
    })
    .filter((lib) => Number.isFinite(lib.distanceKm))
    .filter((lib) => !place.region || normalizeSearchText(lib.sido).includes(normalizeSearchText(placeRegionName)))
    .filter((lib) => lib.distanceKm <= NEARBY_LIBRARY_RADIUS_KM)
    .sort((a, b) => {
      if (a.distanceKm !== b.distanceKm) return a.distanceKm - b.distanceKm;
      return getStandardLibraryTypeWeight(b.libType, b.name) - getStandardLibraryTypeWeight(a.libType, a.name);
    })
    .slice(0, NEARBY_LIBRARY_RESULT_LIMIT)
    .map((lib) => {
      const normalized = normalizeStandardLibForResult(lib);
      const distanceText = formatDistanceKm(lib.distanceKm);
      return {
        ...normalized,
        distanceKm: Number(lib.distanceKm.toFixed(3)),
        note: [
          `${place.label} 기준 ${distanceText}`,
          normalized.note
        ].filter(Boolean).join(" · ")
      };
    });

  const placeAddress = place.address || "주소 정보 없음";
  const resultSourceNote = place.source === "naver_place_anchor"
    ? "네이버 결과는 장소 좌표 확인에만 사용했고, 도서관 목록은 자체 DB에서 가져왔어요."
    : "도서관 목록은 자체 DB에서 가져왔어요.";

  return {
    libraries: nearbyLibraries,
    searchScope: "nearby",
    targetPlace: {
      label: place.label,
      address: placeAddress,
      region: place.region,
      district: place.district,
      locality: place.locality,
      source: place.source || "unknown",
      category: place.category || ""
    },
    note: nearbyLibraries.length > 0
      ? `${place.label}(${placeAddress}) 기준 가까운 도서관을 전국도서관표준데이터 좌표로 정렬했어요. ${resultSourceNote}`
      : `${place.label} 주변 ${NEARBY_LIBRARY_RADIUS_KM}km 안에서 도서관을 찾지 못했어요.`
  };
}

function getStandardLibraryTypeWeight(libType = "", name = "") {
  const type = String(libType || "").trim();
  const libName = String(name || "").trim();

  if (type === "공공도서관") return 3000;
  if (type === "어린이도서관") return 2600;
  if (type === "장애인도서관") return 2400;
  if (type === "작은도서관") {
    if (/문고/u.test(libName)) return 1500;
    return 1800;
  }
  return 1000;
}

function parseLibraryNumber(value) {
  if (value === null || value === undefined) return null;
  const raw = String(value).replace(/,/g, "").trim();
  if (!raw) return null;
  const match = raw.match(/-?\d+(?:\.\d+)?/u);
  if (!match) return null;
  const parsed = Number(match[0]);
  return Number.isFinite(parsed) ? parsed : null;
}

function parseLibraryTimeToMinutes(value) {
  const raw = String(value || "").trim();
  const match = raw.match(/^(\d{1,2}):(\d{2})/u);
  if (!match) return null;
  const hour = Number(match[1]);
  const minute = Number(match[2]);
  if (!Number.isInteger(hour) || !Number.isInteger(minute) || hour < 0 || hour > 24 || minute < 0 || minute > 59) return null;
  return hour * 60 + minute;
}

function formatLibraryNumber(value, suffix = "") {
  const parsed = parseLibraryNumber(value);
  if (parsed === null) return "";
  return `${Math.round(parsed).toLocaleString("ko-KR")}${suffix}`;
}

function hasPositiveLibraryTime(value) {
  const minutes = parseLibraryTimeToMinutes(value);
  return minutes !== null && minutes > 0;
}

function formatLibraryHours(start, end) {
  if (!hasPositiveLibraryTime(end)) return "";
  return [start, end].map((value) => String(value || "").trim()).filter(Boolean).join("~");
}

function formatLibraryCloseTime(label, value) {
  if (!hasPositiveLibraryTime(value)) return "";
  return `${label} ${String(value || "").trim()}`;
}

function scoreMetricLog(value, maxScore = 100, referenceValue = 1000) {
  const parsed = parseLibraryNumber(value);
  const ref = Math.max(1, Number(referenceValue) || 1);
  if (parsed === null || parsed <= 0) return 0;
  return Math.min(maxScore, Math.log1p(parsed) / Math.log1p(ref) * maxScore);
}

function scoreLateClose(value, thresholds = []) {
  const minutes = parseLibraryTimeToMinutes(value);
  if (minutes === null) return 0;

  for (const item of thresholds) {
    if (minutes >= item.minutes) return item.score;
  }
  return 0;
}

function inferLibraryIntentRankingProfile(query = "") {
  const raw = String(query || "").trim();
  const normalized = normalizeSearchText(raw);

  const profile = {
    child: /어린이|아동|유아|아이랑|아이와|아이들|자녀|가족|키즈|그림책|동화|초등|어린이책/u.test(normalized),
    study: /공부|열람실|좌석|자리|조용|스터디|시험|수험|노트북|집중|독서실|읽기좋|책읽기좋/u.test(normalized),
    large: /큰|대형|넓은|규모|대표|중앙|시립|도립|구립|공공|유명|메인/u.test(normalized),
    collection: /장서|자료많|책많|도서많|많은책|많은도서|소장자료|자료수|컬렉션/u.test(normalized),
    night: /야간|밤|늦게|늦은|저녁|퇴근후|오래하는|오래여는|밤까지|저녁까지|21시|22시|23시|9시까지|10시까지|11시까지/u.test(normalized),
    weekend: /주말|토요일|토욜|일요일|일욜|공휴일|휴일|휴관일/u.test(normalized),
    small: /작은도서관|작은곳|작은데|마을문고|새마을문고|동네도서관/u.test(normalized) || /(?:^|\s)문고(?:\s|$)/u.test(raw),
    accessibility: /장애인|점자|시각장애|청각장애|농아|배리어프리|무장애/u.test(normalized),
    manga: /만화|웹툰|그래픽노블|코믹|코믹스/u.test(normalized),
    culture: /문화|프로그램|강좌|행사|전시|공연|동아리|메이커|창작/u.test(normalized)
  };

  profile.representative = profile.large || (!profile.child && !profile.small && !profile.accessibility && !profile.manga && !profile.study && !profile.night && !profile.weekend && !profile.collection && !profile.culture);
  profile.hasPurpose = Object.entries(profile).some(([key, value]) => key !== "representative" && Boolean(value));
  return profile;
}

function hasNonNameLibraryPurposeSignal(query = "") {
  const raw = String(query || "").trim();
  const normalized = normalizeSearchText(raw);
  if (!normalized) return false;

  // Strong request/condition signals. Keep library-type/name words such as
  // “어린이도서관”, “작은도서관”, “장애인도서관” out of this first pass:
  // they can be official names, not user intent.
  if (/공부|열람실|좌석|자리|조용|스터디|시험|수험|노트북|집중|독서실|읽기좋|책읽기좋/u.test(normalized)) return true;
  if (/어린이책|아이랑|아이와|아이들|자녀|가족|키즈|그림책|동화|초등/u.test(normalized)) return true;
  if (/장서|자료많|책많|도서많|많은책|많은도서|소장자료|자료수|많은|많이/u.test(normalized)) return true;
  if (/야간|밤|늦게|늦은|저녁|퇴근후|오래하는|오래여는|밤까지|저녁까지|21시|22시|23시|9시까지|10시까지|11시까지/u.test(normalized)) return true;
  if (/주말|토요일|토욜|일요일|일욜|공휴일|휴일|휴관일/u.test(normalized)) return true;
  if (/만화책|만화|웹툰|그래픽노블|코믹|코믹스/u.test(normalized)) return true;
  if (/문화프로그램|프로그램|강좌|행사|전시|공연|동아리|메이커|창작/u.test(normalized)) return true;
  if (/큰곳|큰데|대형|넓은|규모|대표|유명|추천|메인/u.test(normalized)) return true;

  const hasAmbiguousPurposeWord = /어린이|아동|유아|작은곳|작은데|마을문고|동네도서관|장애인|점자|시각장애|청각장애|농아|배리어프리|무장애|괜찮|좋은/u.test(normalized);
  if (!hasAmbiguousPurposeWord) return false;

  const hasLocationOrListingShape =
    hasStrongLocationToken(raw) ||
    isGenericLocationLibraryQuery(raw) ||
    /(추천|찾아|알려|목록|리스트|어디|근처|주변|인근|있는|갈만한|가기좋은|이용|가능|많은곳|많은데|하는곳|하는데)/u.test(raw);

  return hasLocationOrListingShape;
}

function hasLibraryNameSignal(lib = {}, pattern) {
  const text = normalizeSearchText([
    lib?.name,
    lib?.libType,
    lib?.address,
    lib?.sido,
    lib?.sigungu,
    lib?.operatingOrg
  ].filter(Boolean).join(" "));
  return pattern.test(text);
}

function hasLibraryOwnNameSignal(lib = {}, pattern) {
  const text = normalizeSearchText([
    lib?.name,
    lib?.libType
  ].filter(Boolean).join(" "));
  return pattern.test(text);
}

function isSmallLibrary(lib = {}) {
  return String(lib?.libType || "").trim() === "작은도서관" || hasLibraryOwnNameSignal(lib, /작은도서관|문고/u);
}

function isChildLibrary(lib = {}) {
  return String(lib?.libType || "").trim() === "어린이도서관" || hasLibraryOwnNameSignal(lib, /어린이|아동|유아|키즈|꿈나무|새싹/u);
}

function isAccessibilityLibrary(lib = {}) {
  return String(lib?.libType || "").trim() === "장애인도서관" || hasLibraryOwnNameSignal(lib, /장애인|점자|시각장애|농아|청각장애/u);
}

function getLibraryCloseMinutes(value = "") {
  const minutes = parseLibraryTimeToMinutes(value);
  return minutes !== null && minutes > 0 ? minutes : null;
}

function getLibraryWeekdayCloseMinutes(lib = {}) {
  return getLibraryCloseMinutes(lib?.weekdayEnd || lib?.weekdayClose || lib?.weekdayCloseTime || "");
}

function getLibrarySaturdayCloseMinutes(lib = {}) {
  return getLibraryCloseMinutes(lib?.saturdayEnd || lib?.saturdayClose || lib?.saturdayCloseTime || "");
}

function getLibraryHolidayCloseMinutes(lib = {}) {
  return getLibraryCloseMinutes(lib?.holidayEnd || lib?.holidayClose || lib?.holidayCloseTime || "");
}

function isClosedOnSunday(lib = {}) {
  const raw = String(lib?.closed || "").replace(/\s+/g, "").trim();
  if (!raw) return false;
  if (/일요일(?:을|은)?제외|일요일을제외한|일요일은제외한/u.test(raw)) return false;
  if (/매주일요일|일요일/u.test(raw)) return true;
  return /(?:^|[+/,，])일(?:$|[+/,，])/u.test(raw);
}

function isSundayOpenIntentQuery(query = "") {
  const normalized = normalizeSearchText(query);
  if (!/일요일|일욜/u.test(normalized)) return false;
  return !/휴관|쉬는|쉰|닫|안여|안열/u.test(normalized);
}

function scoreLibraryGeneralQuality(lib = {}, options = {}) {
  const { explicitLibraryName = false } = options;
  const scale = explicitLibraryName ? 0.25 : 1;

  let score = 0;
  score += scoreMetricLog(lib?.bookCount, 260, 250_000);
  score += scoreMetricLog(lib?.seatCount, 220, 500);
  score += scoreMetricLog(lib?.buildingArea, 140, 8_000);
  score += scoreMetricLog(lib?.siteArea, 80, 20_000);

  const weekdayClose = getLibraryWeekdayCloseMinutes(lib);
  if (weekdayClose !== null) {
    if (weekdayClose >= 22 * 60) score += 90;
    else if (weekdayClose >= 21 * 60) score += 65;
    else if (weekdayClose >= 20 * 60) score += 35;
  }

  if (hasLibraryNameSignal(lib, /중앙|대표|시립|도립|구립|군립|교육청|정보/u)) score += 130;
  if (isSmallLibrary(lib)) score -= 80;

  return Math.round(score * scale);
}

function scoreLibraryIntentAlignment(lib = {}, query = "", options = {}) {
  const profile = options.intentProfile || inferLibraryIntentRankingProfile(query);
  const explicitLibraryName = Boolean(options.explicitLibraryName);
  const qualityScale = explicitLibraryName ? 0.35 : 1;
  const isPublic = String(lib?.libType || "").trim() === "공공도서관" || (!lib?.libType && !isSmallLibrary(lib));
  const childLib = isChildLibrary(lib);
  const smallLib = isSmallLibrary(lib);
  const accessibilityLib = isAccessibilityLibrary(lib);
  const weekdayClose = getLibraryWeekdayCloseMinutes(lib);
  const saturdayClose = getLibrarySaturdayCloseMinutes(lib);
  const holidayClose = getLibraryHolidayCloseMinutes(lib);

  let score = scoreLibraryGeneralQuality(lib, { explicitLibraryName }) * qualityScale;

  if (profile.child) {
    if (childLib) score += 1900;
    if (hasLibraryNameSignal(lib, /어린이|아동|유아|키즈|꿈나무|새싹|그림책|동화/u)) score += 900;
    if (isPublic) score += 180;
    score += scoreMetricLog(lib?.bookCount, 180, 180_000);
    if (accessibilityLib) score -= 250;
  }

  if (profile.study) {
    if (isPublic) score += 650;
    score += scoreMetricLog(lib?.seatCount, 950, 700);
    score += scoreMetricLog(lib?.buildingArea, 260, 10_000);
    score += scoreMetricLog(lib?.bookCount, 260, 250_000);
    score += scoreLateClose(lib?.weekdayEnd, [
      { minutes: 22 * 60, score: 650 },
      { minutes: 21 * 60, score: 420 },
      { minutes: 20 * 60, score: 220 }
    ]);
    if (hasLibraryNameSignal(lib, /정보|중앙|시립|도립|구립|교육|학습|열람/u)) score += 180;
    if (childLib) score -= 520;
    if (smallLib) score -= 760;
  }

  if (profile.representative || profile.large) {
    if (isPublic) score += profile.large ? 900 : 360;
    if (hasLibraryNameSignal(lib, /중앙|대표|시립|도립|구립|군립|교육청|정보/u)) score += profile.large ? 760 : 260;
    score += scoreMetricLog(lib?.bookCount, profile.large ? 850 : 360, 300_000);
    score += scoreMetricLog(lib?.seatCount, profile.large ? 560 : 240, 800);
    score += scoreMetricLog(lib?.buildingArea, profile.large ? 420 : 170, 12_000);
    if (smallLib) score -= profile.large ? 1150 : 260;
    if (hasLibraryNameSignal(lib, /문고/u)) score -= profile.large ? 1350 : 320;
  }

  if (profile.collection) {
    score += scoreMetricLog(lib?.bookCount, 1250, 350_000);
    score += scoreMetricLog(lib?.periodicalCount, 120, 300);
    score += scoreMetricLog(lib?.nonBookCount, 100, 20_000);
    if (smallLib) score -= 260;
  }

  if (profile.night) {
    if (weekdayClose !== null) {
      if (weekdayClose >= 22 * 60) score += 1700;
      else if (weekdayClose >= 21 * 60) score += 1050;
      else if (weekdayClose >= 20 * 60) score += 620;
      else score -= 300;
    }
    if (smallLib) score -= 220;
  }

  if (profile.weekend) {
    const wantsSunday = isSundayOpenIntentQuery(query);
    if (saturdayClose !== null) {
      if (saturdayClose >= 18 * 60) score += 550;
      else if (saturdayClose >= 17 * 60) score += 360;
      else if (saturdayClose >= 13 * 60) score += 160;
    }
    if (holidayClose !== null) {
      if (holidayClose >= 18 * 60) score += wantsSunday ? 900 : 500;
      else if (holidayClose >= 13 * 60) score += wantsSunday ? 520 : 220;
    }
    if (wantsSunday) {
      if (isClosedOnSunday(lib)) score -= 20000;
      else score += 380;
      if (holidayClose === null) score -= 250;
    }
  }

  if (profile.small) {
    if (smallLib) score += 2800;
    if (hasLibraryOwnNameSignal(lib, /작은도서관|마을|문고/u)) score += 900;
    if (isPublic && !smallLib) score -= 1050;
  }

  if (profile.accessibility) {
    if (accessibilityLib) score += 2300;
    if (hasLibraryNameSignal(lib, /장애인|점자|시각장애|청각장애|농아|무장애/u)) score += 900;
    if (!accessibilityLib) score -= 120;
  }

  if (profile.manga) {
    if (hasLibraryOwnNameSignal(lib, /만화|웹툰|코믹/u)) score += 2300;
    if (hasLibraryOwnNameSignal(lib, /청소년|어린이|아동/u)) score += 420;
    score += scoreMetricLog(lib?.bookCount, 160, 160_000);
  }

  if (profile.culture) {
    if (hasLibraryOwnNameSignal(lib, /문화|정보|미디어|메이커|창작/u)) score += 620;
    if (isPublic) score += 280;
    score += scoreMetricLog(lib?.buildingArea, 220, 10_000);
  }

  return Math.round(score);
}

function getLibraryIntentRankingReason(lib = {}, query = "", options = {}) {
  if (isExplicitLibraryNameQuery(query)) return "";

  const profile = options.intentProfile || inferLibraryIntentRankingProfile(query);
  const reasons = [];

  if (profile.child && isChildLibrary(lib)) reasons.push("어린이·가족 이용 의도와 맞음");
  if (profile.study) {
    const seats = formatLibraryNumber(lib?.seatCount, "석");
    if (seats) reasons.push(`열람좌석 ${seats}`);
    const weekdayReason = formatLibraryCloseTime("평일", lib?.weekdayEnd);
    if (weekdayReason) reasons.push(`${weekdayReason}까지 운영`);
  }
  if (profile.night) {
    const weekdayReason = formatLibraryCloseTime("평일", lib?.weekdayEnd);
    if (weekdayReason) reasons.push(`${weekdayReason}까지 운영`);
  }
  if (profile.weekend) {
    const parts = [
      formatLibraryCloseTime("토", lib?.saturdayEnd),
      formatLibraryCloseTime("공휴일", lib?.holidayEnd)
    ].filter(Boolean);
    if (parts.length) reasons.push(parts.join(" / "));
  }
  if ((profile.collection || profile.large || profile.representative) && lib?.bookCount) reasons.push(`도서 ${formatLibraryNumber(lib.bookCount, "권")}`);
  if ((profile.large || profile.representative) && lib?.seatCount && reasons.length < 2) reasons.push(`좌석 ${formatLibraryNumber(lib.seatCount, "석")}`);
  if (profile.small && isSmallLibrary(lib)) reasons.push("작은도서관·문고 의도와 맞음");
  if (profile.accessibility && isAccessibilityLibrary(lib)) reasons.push("장애인도서관 의도와 맞음");
  if (profile.manga && hasLibraryOwnNameSignal(lib, /만화|웹툰|코믹/u)) reasons.push("만화·웹툰 키워드와 맞음");
  if (profile.culture && hasLibraryOwnNameSignal(lib, /문화|정보|미디어|메이커|창작/u)) reasons.push("문화 프로그램 의도와 맞음");

  return reasons.slice(0, 2).join(" · ");
}

function attachLibraryRankingMetadata(lib = {}, query = "", options = {}) {
  if (options.explicitLibraryName) return lib;

  const intentProfile = options.intentProfile || inferLibraryIntentRankingProfile(query);
  const reason = getLibraryIntentRankingReason(lib, query, { intentProfile });
  if (!reason) return lib;
  return { ...lib, rankReason: reason };
}

function getLocalityNameBase(normalizedDistrict = "") {
  const token = normalizeSearchText(normalizedDistrict);
  if (!token || !/(읍|면|동)$/.test(token)) return "";
  const base = token.slice(0, -1);
  return base.length >= 2 ? base : "";
}

function isLocalityBaseNameMatch(normalizedName = "", base = "") {
  const name = normalizeSearchText(normalizedName);
  const token = normalizeSearchText(base);
  if (!name || !token) return false;

  return name.startsWith(token) || name.includes(`${token}도서관`) || name.includes(`${token}작은도서관`);
}

function isDistrictMatchedByLibrary(lib = {}, normalizedDistrict = "") {
  const token = normalizeSearchText(normalizedDistrict);
  if (!token) return true;

  const name = normalizeSearchText(lib?.name || "");
  const address = normalizeSearchText(lib?.address || "");
  const sigungu = normalizeSearchText(lib?.sigungu || "");
  const base = getLocalityNameBase(token);

  return address.includes(token) ||
    sigungu.includes(token) ||
    Boolean(base && isLocalityBaseNameMatch(name, base));
}

function scoreStandardLibraryMatch(lib, query = "", constraints = {}, options = {}) {
  const { selectedRegion = "", explicitLibraryName = false } = options;

  const name = normalizeSearchText(lib?.name || "");
  const address = normalizeSearchText(lib?.address || "");
  const sido = normalizeSearchText(lib?.sido || "");
  const sigungu = normalizeSearchText(lib?.sigungu || "");
  const libType = String(lib?.libType || "").trim();

  const normalizedQuery = normalizeSearchText(query);
  const queryNoLocationBase = stripLibraryQueryNoiseFromNormalizedText(
    stripLibraryLocationTokensFromNormalizedText(normalizedQuery, constraints)
  );
  const queryNoLocation = explicitLibraryName
    ? queryNoLocationBase
    : stripLibraryIntentTokensFromNormalizedText(queryNoLocationBase);

  const normalizedSido = normalizeSearchText(
    constraints.sido || (selectedRegion ? REGION_CODE_TO_NAME[selectedRegion] || "" : "")
  );
  const normalizedDistrict = normalizeSearchText(constraints.district || "");
  const normalizedRoad = normalizeSearchText(constraints.road || "");

  let score = getStandardLibraryTypeWeight(libType, lib?.name || "");

  if (normalizedSido) {
    if (address.includes(normalizedSido) || sido.includes(normalizedSido)) score += 500;
    else return -9999;
  }

  if (normalizedDistrict) {
    const districtBase = getLocalityNameBase(normalizedDistrict);
    if (address.includes(normalizedDistrict) || sigungu.includes(normalizedDistrict)) score += 1000;
    else if (districtBase && isLocalityBaseNameMatch(name, districtBase)) score += 700;
    else return -9999;
  }

  if (normalizedRoad) {
    if (address.includes(normalizedRoad)) score += 850;
    else return -9999;
  }

  if (explicitLibraryName) {
    let explicitNameScore = 0;
    if (name === normalizedQuery) explicitNameScore += 5000;
    else if (name.startsWith(normalizedQuery)) explicitNameScore += 3500;
    else if (name.includes(normalizedQuery)) explicitNameScore += 2200;
    else if (queryNoLocation && name === queryNoLocation) explicitNameScore += 1800;
    else if (queryNoLocation && name.includes(queryNoLocation)) explicitNameScore += 1200;

    if (explicitNameScore === 0) return -9999;
    score += explicitNameScore;
  } else {
    if (name === normalizedQuery) score += 2200;
    else if (name.startsWith(normalizedQuery)) score += 1600;
    else if (name.includes(normalizedQuery)) score += 900;

    if (queryNoLocation && queryNoLocation.length >= 2) {
      if (name === queryNoLocation) score += 2000;
      else if (name.startsWith(queryNoLocation)) score += 1400;
      else if (name.includes(queryNoLocation)) score += 800;
    }
  }

  if (normalizedDistrict && name.includes(normalizedDistrict)) score += 180;
  else {
    const districtBase = getLocalityNameBase(normalizedDistrict);
    if (districtBase && isLocalityBaseNameMatch(name, districtBase)) score += 120;
  }
  if (normalizedSido && name.includes(normalizedSido)) score += 80;

  score += scoreLibraryIntentAlignment(lib, query, {
    selectedRegion,
    explicitLibraryName,
    constraints
  });

  return score;
}

function getLibraryNameAddressKey(item = {}) {
  const name = normalizeSearchText(item?.name || "");
  const address = normalizeSearchText(item?.address || "");
  return name && address ? `${name}::${address}` : "";
}

function buildLibraryEnrichmentLookup(xmlItems = []) {
  const byNameAddress = new Map();
  const byName = new Map();

  xmlItems.forEach((item) => {
    const name = normalizeSearchText(item?.name || "");
    const address = normalizeSearchText(item?.address || "");
    if (!name) return;

    if (address) byNameAddress.set(`${name}::${address}`, item);
    if (!byName.has(name)) byName.set(name, []);
    byName.get(name).push(item);
  });

  return { byNameAddress, byName };
}

function resolveLibraryEnrichment(item = {}, lookup = null) {
  if (!lookup) return null;

  const exactKey = getLibraryNameAddressKey(item);
  if (exactKey && lookup.byNameAddress.has(exactKey)) {
    return lookup.byNameAddress.get(exactKey);
  }

  const name = normalizeSearchText(item?.name || "");
  if (!name) return null;

  const candidates = lookup.byName.get(name) || [];
  if (candidates.length === 1) return candidates[0];

  const address = normalizeSearchText(item?.address || "");
  if (!address) return null;

  return candidates.find((candidate) => {
    const candidateAddress = normalizeSearchText(candidate?.address || "");
    return candidateAddress && (candidateAddress.includes(address) || address.includes(candidateAddress));
  }) || null;
}

function mergeLibraryEnrichment(item = {}, enrichment = null) {
  if (!enrichment) return item;

  return {
    ...enrichment,
    ...item,
    source: item.source || enrichment.source,
    libType: item.libType || enrichment.libType || "",
    sido: item.sido || enrichment.sido || "",
    sigungu: item.sigungu || enrichment.sigungu || "",
    seatCount: item.seatCount ?? enrichment.seatCount,
    bookCount: item.bookCount ?? enrichment.bookCount,
    periodicalCount: item.periodicalCount ?? enrichment.periodicalCount,
    nonBookCount: item.nonBookCount ?? enrichment.nonBookCount,
    weekdayStart: item.weekdayStart || enrichment.weekdayStart || "",
    weekdayEnd: item.weekdayEnd || enrichment.weekdayEnd || "",
    saturdayStart: item.saturdayStart || enrichment.saturdayStart || "",
    saturdayEnd: item.saturdayEnd || enrichment.saturdayEnd || "",
    holidayStart: item.holidayStart || enrichment.holidayStart || "",
    holidayEnd: item.holidayEnd || enrichment.holidayEnd || "",
    loanLimit: item.loanLimit ?? enrichment.loanLimit,
    loanDays: item.loanDays ?? enrichment.loanDays,
    siteArea: item.siteArea ?? enrichment.siteArea,
    buildingArea: item.buildingArea ?? enrichment.buildingArea,
    operatingOrg: item.operatingOrg || enrichment.operatingOrg || "",
    dataDate: item.dataDate || enrichment.dataDate || "",
    note: item.note || enrichment.note || ""
  };
}

function mergeLibraryResults(data4Items = [], xmlItems = [], options = {}) {
  const { query = "", constraints = {}, explicitLibraryName = false, selectedRegion = "" } = options;
  const merged = [];
  const seen = new Set();
  const enrichmentLookup = buildLibraryEnrichmentLookup(xmlItems);

  const pushItem = (item, score = 0) => {
    const key = normalizeSearchText(item.name || "") || `${normalizeSearchText(item.address || "")}-${item.source || ""}`;
    if (!key || seen.has(key)) return;
    seen.add(key);
    merged.push({ ...item, _score: score });
  };

  data4Items.forEach((item) => {
    const enrichedItem = mergeLibraryEnrichment(item, resolveLibraryEnrichment(item, enrichmentLookup));
    const strictBaseScore = explicitLibraryName
      ? scoreStrictLibraryNameMatch(enrichedItem, query)
      : scoreStrictRegionLibraryMatch(enrichedItem, query, constraints, { selectedRegion });

    if (strictBaseScore <= 0) return;

    const strictScore = strictBaseScore + 5000;
    const rankingScore = scoreLibraryIntentAlignment(enrichedItem, query, {
      selectedRegion,
      explicitLibraryName,
      constraints
    });
    const score = strictScore + rankingScore;

    if (score > 0) pushItem(enrichedItem, score);
  });

  xmlItems.forEach((item) => {
    const score = scoreStandardLibraryMatch(item, query, constraints, {
      selectedRegion,
      explicitLibraryName
    });

    if (score > 0) pushItem(item, score);
  });

  return merged.sort((a, b) => {
    if ((b._score || 0) !== (a._score || 0)) return (b._score || 0) - (a._score || 0);
    return String(a.name || "").localeCompare(String(b.name || ""), "ko");
  });
}
function searchStandardLibraryDb(query = "", selectedRegion = "") {
  ensureStandardLibraryLoaded();
  if (!standardLibraryDb.length) return [];

  const normalizedQuery = normalizeSearchText(query);
  if (!normalizedQuery) return [];

  const detailHint = getDetailedRegionHint(query, selectedRegion);
  const regionName = selectedRegion ? (REGION_CODE_TO_NAME[selectedRegion] || "") : "";
  let constraints = extractLibraryLocationConstraints(query, selectedRegion);
  if (detailHint) {
    constraints = {
      ...constraints,
      sido: constraints.sido || REGION_CODE_TO_NAME[detailHint.region] || "",
      district: constraints.district || detailHint.districtName || "",
      hasLocationConstraint: true
    };
  }

  // 위치·자연어 표현을 제거한 순수 명칭 토큰
  // 예: "강남구에 있는 도서관 찾아줘" -> "" / "종로도서관" -> "종로도서관"
  const explicitLibraryNameForQuery = isExplicitLibraryNameQuery(query);
  const queryNoLocationBase = stripLibraryQueryNoiseFromNormalizedText(
    stripLibraryLocationTokensFromNormalizedText(normalizedQuery, constraints)
  );
  const queryNoLocation = explicitLibraryNameForQuery
    ? queryNoLocationBase
    : stripLibraryIntentTokensFromNormalizedText(queryNoLocationBase);

  // queryNoLocation이 '도서관'·'작은도서관'만 남은 경우 무효 처리
  const queryNoLocClean = queryNoLocation.replace(/도서관|작은도서관|문고/g, "").trim();

  // 지역/동네 검색은 주소·행정구역 일치만으로도 결과를 허용한다.
  const hasLocationConstraint = Boolean(regionName || constraints.sido || constraints.district || constraints.road);
  const isPureLocationLibraryQuery = hasLocationConstraint && queryNoLocClean.length === 0 && !explicitLibraryNameForQuery;
  const wantsSundayOpen = isSundayOpenIntentQuery(query);

  const results = [];

  for (const lib of standardLibraryDb) {
    const normName = normalizeSearchText(lib.name);
    const normAddr = normalizeSearchText(lib.address);
    const normSido = normalizeSearchText(lib.sido);
    const normSigungu = normalizeSearchText(lib.sigungu);

    // 지역 필터
    if (regionName) {
      const nr = normalizeSearchText(regionName);
      if (!normSido.includes(nr) && !normAddr.includes(nr)) continue;
    }
    if (constraints.sido && !regionName) {
      const ns = normalizeSearchText(constraints.sido);
      if (!normSido.includes(ns) && !normAddr.includes(ns)) continue;
    }
    if (constraints.district) {
      const nd = normalizeSearchText(constraints.district);
      if (!isDistrictMatchedByLibrary({ ...lib, address: lib.address, sigungu: lib.sigungu }, nd)) continue;
    }
    if (constraints.road) {
      const nr = normalizeSearchText(constraints.road);
      if (!normAddr.includes(nr)) continue;
    }
    if (wantsSundayOpen && isClosedOnSunday(lib)) continue;

    // ── 명칭 매칭 (필수) ──────────────────────────────────
    let nameScore = 0;

    if (normName === normalizedQuery) nameScore = 2000;
    else if (normName.startsWith(normalizedQuery)) nameScore = 1500;
    else if (normName.includes(normalizedQuery)) nameScore = 900;

    // queryNoLocation이 유효한 경우에만 보조 매칭
    if (nameScore === 0 && queryNoLocation && queryNoLocClean.length >= 2) {
      if (normName === queryNoLocation) nameScore = 1800;
      else if (normName.startsWith(queryNoLocation)) nameScore = 1300;
      else if (normName.includes(queryNoLocation)) nameScore = 750;
    }

    // 전국 검색은 명칭 매칭 필수.
    // 지역 지정 검색에서 남은 명칭 토큰이 없으면 주소/행정구역 매칭만으로 통과시킨다.
    if (nameScore === 0) {
      if (isPureLocationLibraryQuery) {
        nameScore = getStandardLibraryTypeWeight(lib.libType, lib.name);
        if (constraints.district) nameScore += 1000;
        if (constraints.sido || regionName) nameScore += 500;
      } else {
        continue;
      }
    }

    const score = nameScore + scoreLibraryIntentAlignment(lib, query, {
      selectedRegion,
      explicitLibraryName: explicitLibraryNameForQuery,
      constraints
    });
    results.push({ lib, score });
  }

  return results
    .sort((a, b) => b.score - a.score)
    .map(({ lib }) => normalizeStandardLibForResult(lib));
}

// 관리자용 XML 재로드 엔드포인트 (선택적)
app.post("/api/admin/reload-library-db", (req, res) => {
  const secret = process.env.ADMIN_SECRET;

  // Production safety: do not expose this admin action when ADMIN_SECRET is not configured.
  if (!secret) {
    return res.status(404).json({ error: "Not found" });
  }

  if (req.headers["x-admin-secret"] !== secret) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  standardLibraryLoadedAt = 0; // TTL 만료 강제
  ensureStandardLibraryLoaded();
  return res.json({ ok: true, count: standardLibraryDb.length });
});

function extractLibraryLocationConstraints(query = "", selectedRegion = "") {
  const raw = String(query || "").trim();
  const normalized = normalizeSearchText(raw);

  let sido = selectedRegion ? (REGION_CODE_TO_NAME[selectedRegion] || "") : "";
  let district = "";
  let road = "";

  if (normalized && !sido) {
    const regionCodeFromQuery = getRegionCodeFromText(raw);
    if (regionCodeFromQuery) {
      sido = REGION_CODE_TO_NAME[regionCodeFromQuery] || "";
    }
  }

  const locationMatches = [...raw.matchAll(/([가-힣0-9]+(?:구|군|시|읍|면|동|리))/gu)]
    .map((match) => stripKnownRegionPrefixFromToken(match[1]))
    .filter(Boolean);

  for (const token of locationMatches) {
    // "서울시 중구"의 서울시처럼 광역시도 별칭은 세부지역으로 쓰지 않음
    const sidoAliasPattern = /^(서울|부산|대구|인천|광주|대전|울산|세종)(특별시|광역시|특별자치시|시)?$|^(경기|강원|충북|충남|전북|전남|경북|경남|제주)(도|특별자치도)?$/u;
    if (getRegionCodeFromName(token) || sidoAliasPattern.test(token)) continue;
    district = token;
    break;
  }

  const roadMatches = [...raw.matchAll(/([가-힣0-9]{1,20}(?:로|길))(?![가-힣0-9])/gu)]
    .map((match) => stripKnownRegionPrefixFromToken(match[1]))
    .filter(Boolean);
  for (const token of roadMatches) {
    if (/(?:도서관|공공도서관|작은도서관|문고)$/u.test(token)) continue;
    road = token;
    break;
  }

  return {
    sido,
    district,
    road,
    hasLocationConstraint: Boolean(sido || district || road)
  };
}

function getDirectLibraryFollowupActions(query = "") {
  const normalized = normalizeSearchText(query || "");
  const whitelist = {
    "종로도서관": { label: "종로구 도서관 검색", value: "종로구 도서관" },
    "강남도서관": { label: "강남구 도서관 검색", value: "강남구 도서관" },
    "대치도서관": { label: "대치동 도서관 검색", value: "대치동 도서관" }
  };

  for (const [key, item] of Object.entries(whitelist)) {
    if (normalized === normalizeSearchText(key)) {
      return [{ label: item.label, action: "run_library_search", value: item.value }];
    }
  }

  return [];
}

function scoreStrictLibraryNameMatch(lib, query = "") {
  const name = normalizeSearchText(lib?.name || "");
  const queryText = normalizeSearchText(query);
  const queryNoLibrary = queryText.replace(/도서관$/u, "");
  let score = 0;

  if (!name || !queryText) return 0;

  if (name === queryText) score += 5000;
  else if (name === `${queryNoLibrary}도서관`) score += 4800;
  else if (name.startsWith(queryText)) score += 3600;
  else if (name.endsWith(queryText)) score += 3200;
  else if (name.includes(queryText)) score += 2200;
  else if (queryNoLibrary && name === queryNoLibrary) score += 1200;

  return score;
}

function scoreStrictRegionLibraryMatch(lib, query = "", constraints = {}, options = {}) {
  const { selectedRegion = "" } = options;
  const name = normalizeSearchText(lib?.name || "");
  const address = normalizeSearchText(lib?.address || "");
  const category = normalizeSearchText(lib?.category || "");
  const normalizedQuery = normalizeSearchText(query);
  const normalizedSido = normalizeSearchText(constraints.sido || (selectedRegion ? REGION_CODE_TO_NAME[selectedRegion] || "" : ""));
  const normalizedDistrict = normalizeSearchText(constraints.district || "");
  let score = 0;

  if (!normalizedSido && !normalizedDistrict && hasStrongLocationToken(query)) {
    return -9999;
  }

  if (normalizedSido) {
    if (address.includes(normalizedSido)) score += 250;
    else return -9999;
  }

  if (normalizedDistrict) {
    const districtBase = getLocalityNameBase(normalizedDistrict);
    if (address.includes(normalizedDistrict)) score += 900;
    else if (districtBase && isLocalityBaseNameMatch(name, districtBase)) score += 650;
    else return -9999;
  }

  if (/(도서관|작은도서관|문고)/u.test(`${lib?.name || ""} ${lib?.category || ""}`)) {
    score += 150;
  } else {
    return -9999;
  }

  if (name === normalizedQuery) score += 1500;
  else if (name.startsWith(normalizedQuery)) score += 800;
  else if (name.includes(normalizedQuery)) score += 400;

  if (normalizedDistrict && name.includes(normalizedDistrict)) score += 180;
  else {
    const districtBase = getLocalityNameBase(normalizedDistrict);
    if (districtBase && isLocalityBaseNameMatch(name, districtBase)) score += 120;
  }
  if (normalizedQuery.includes(normalizeSearchText("도서관")) && category.includes(normalizeSearchText("도서관"))) score += 80;

  return score;
}

function getXmlLibrarySearchResults(query = "", selectedRegion = "", constraints = null, explicitLibraryName = false) {
  const effectiveConstraints = constraints || extractLibraryLocationConstraints(query, selectedRegion);

  const scored = searchStandardLibraryDb(query, selectedRegion)
    .map((lib) => ({
      ...lib,
      _score: scoreStandardLibraryMatch(lib, query, effectiveConstraints, {
        selectedRegion,
        explicitLibraryName
      })
    }))
    .filter((lib) => lib._score > 0)
    .sort((a, b) => (b._score || 0) - (a._score || 0))
    .map(({ _score, ...lib }) => lib);

  return dedupeLibraries(scored);
}

function getLibraryRegionalFallbackQueryForExactName(query = "", constraints = {}, selectedRegion = "") {
  const district = String(constraints?.district || "").trim();
  const sido = String(constraints?.sido || "").trim();
  if (district) return `${district} 도서관`;
  if (sido) return `${sido} 도서관`;

  const compact = normalizeSearchText(query).replace(/(?:작은도서관|도서관|문고)$/u, "");
  if (!compact) return "";

  const broadRegion = getRegionCodeFromName(compact) || getRegionCodeFromText(compact, selectedRegion);
  if (broadRegion) return `${REGION_CODE_TO_NAME[broadRegion] || compact} 도서관`;

  const detailedHint = getDetailedRegionHint(`${compact} 도서관`, selectedRegion);
  if (detailedHint?.districtName) return `${detailedHint.districtName} 도서관`;

  return "";
}

function buildLibrarySearchConstraintsWithDetailHint(query = "", selectedRegion = "", detailHint = null) {
  const constraints = extractLibraryLocationConstraints(query, selectedRegion);
  if (!detailHint) return constraints;
  return {
    ...constraints,
    sido: constraints.sido || REGION_CODE_TO_NAME[detailHint.region] || "",
    district: constraints.district || detailHint.districtName || "",
    hasLocationConstraint: true
  };
}


function buildXmlOnlyLibrarySearchPayload(query = "", selectedRegion = "", options = {}) {
  const explicitLibraryName = options.explicitLibraryName ?? isExplicitLibraryNameQuery(query);
  const constraints = options.constraints || extractLibraryLocationConstraints(query, selectedRegion);
  const detailHint = options.detailHint || getDetailedRegionHint(query, selectedRegion);
  let effectiveRegion = detailHint?.region || selectedRegion || getRegionCodeFromText(query);
  let effectiveDtlRegion = detailHint?.dtlRegion || "";
  const intentProfile = inferLibraryIntentRankingProfile(query);
  let rankingQuery = query;
  let rankingExplicitLibraryName = explicitLibraryName;
  let exactNameFallback = false;
  let exactNameFallbackQuery = "";
  let exactNameFallbackMessage = "";

  let libraries = getXmlLibrarySearchResults(query, selectedRegion, constraints, explicitLibraryName)
    .map((lib) => attachLibraryRankingMetadata(lib, query, { explicitLibraryName, intentProfile }));

  if (explicitLibraryName && libraries.length === 0) {
    const fallbackQuery = getLibraryRegionalFallbackQueryForExactName(query, constraints, selectedRegion);
    if (fallbackQuery && fallbackQuery.trim() !== String(query || "").trim()) {
      const fallbackDetailHint = getDetailedRegionHint(fallbackQuery, selectedRegion);
      const fallbackConstraints = buildLibrarySearchConstraintsWithDetailHint(fallbackQuery, selectedRegion, fallbackDetailHint);
      const fallbackIntentProfile = inferLibraryIntentRankingProfile(fallbackQuery);
      const fallbackLibraries = getXmlLibrarySearchResults(fallbackQuery, selectedRegion, fallbackConstraints, false)
        .map((lib) => attachLibraryRankingMetadata(lib, fallbackQuery, { explicitLibraryName: false, intentProfile: fallbackIntentProfile }));

      if (fallbackLibraries.length > 0) {
        libraries = fallbackLibraries;
        rankingQuery = fallbackQuery;
        rankingExplicitLibraryName = false;
        exactNameFallback = true;
        exactNameFallbackQuery = fallbackQuery;
        exactNameFallbackMessage = `정확한 명칭 “${query}”은(는) 전국도서관표준데이터에서 찾지 못해, “${fallbackQuery}” 기준 후보를 함께 보여드려요.`;
        effectiveRegion = fallbackDetailHint?.region || selectedRegion || getRegionCodeFromText(fallbackQuery);
        effectiveDtlRegion = fallbackDetailHint?.dtlRegion || "";
      }
    }
  }

  const payload = {
    libraries,
    searchScope: effectiveDtlRegion ? "detailed_region" : (effectiveRegion ? "selected_region" : "nationwide"),
    actionButtons: explicitLibraryName && libraries.length > 0 ? getDirectLibraryFollowupActions(query) : []
  };

  if (exactNameFallback) {
    payload.exactNameFallback = true;
    payload.exactNameFallbackQuery = exactNameFallbackQuery;
    payload.message = exactNameFallbackMessage;
  }

  if (options.debug) {
    payload.debug = {
      query,
      selectedRegion,
      effectiveRegion,
      effectiveDtlRegion,
      explicitLibraryName,
      rankingQuery,
      rankingExplicitLibraryName,
      exactNameFallback,
      exactNameFallbackQuery,
      constraints,
      matchedXmlCount: libraries.length,
      intentRankingProfile: exactNameFallback ? inferLibraryIntentRankingProfile(rankingQuery) : intentProfile
    };
  }

  return payload;
}

function buildPopularBooksByLibraryUrl({ libCode = "", region = "", dtlRegion = "", pageNo = 1, pageSize = 20 } = {}) {
  const url = new URL("http://data4library.kr/api/loanItemSrchByLib");
  url.searchParams.set("authKey", DATA4LIBRARY_API_KEY);
  if (libCode) url.searchParams.set("libCode", libCode);
  if (region) url.searchParams.set("region", region);
  if (dtlRegion) url.searchParams.set("dtl_region", dtlRegion);
  url.searchParams.set("pageNo", String(pageNo));
  url.searchParams.set("pageSize", String(pageSize));
  return url.toString();
}

function getFirstDefinedValue(source = {}, keys = []) {
  for (const key of keys) {
    const value = source?.[key];
    if (value !== undefined && value !== null && String(value).trim() !== "") {
      return value;
    }
  }
  return "";
}

function normalizePopularLoanBookResults(raw) {
  const docs = forceArray(
    raw?.response?.docs?.doc ||
    raw?.response?.doc ||
    raw?.response?.items?.item ||
    raw?.response?.item ||
    []
  );

  return docs.map((doc, index) => {
    const item = doc?.book || doc;
    const isbn13 = sanitizeIsbn(getFirstDefinedValue(item, ["isbn13", "isbn", "isbn13s", "isbn_13"]));

    return {
      id: isbn13 || `popular-book-${index}`,
      ranking: String(getFirstDefinedValue(item, ["ranking", "rank", "no", "rnum"]) || index + 1),
      title: String(getFirstDefinedValue(item, ["bookname", "bookName", "title", "name"]) || "제목 없음"),
      author: String(getFirstDefinedValue(item, ["authors", "author", "authorName"]) || "저자 정보 없음"),
      publisher: String(getFirstDefinedValue(item, ["publisher", "publisherName"]) || "출판사 정보 없음"),
      publicationYear: String(getFirstDefinedValue(item, ["publication_year", "publicationYear", "publicationYearName", "pubYear", "pubdate"]) || ""),
      isbn13,
      loanCount: String(getFirstDefinedValue(item, ["loan_count", "loanCount", "loanCnt", "loan_count_sum"]) || ""),
      image: String(getFirstDefinedValue(item, ["bookImageURL", "bookImageUrl", "image", "imageUrl"]) || "")
    };
  }).filter((book) => book.title && book.title !== "제목 없음");
}

async function fetchPopularBooksByLibraryTarget(target = {}) {
  const cacheKey = JSON.stringify({
    type: "popular-books",
    libCode: target.libCode || "",
    region: target.region || "",
    dtlRegion: target.dtlRegion || ""
  });
  const cached = getTimedCacheValue(popularBooksCache, cacheKey);
  if (cached) return cached;

  const requestUrl = buildPopularBooksByLibraryUrl({
    libCode: target.libCode || "",
    region: target.region || "",
    dtlRegion: target.dtlRegion || "",
    pageNo: 1,
    pageSize: POPULAR_BOOK_PAGE_SIZE
  });

  const data = await fetchXml(requestUrl);
  const books = normalizePopularLoanBookResults(data);
  setTimedCacheValue(popularBooksCache, cacheKey, books, POPULAR_BOOK_CACHE_TTL_MS);
  return books;
}

function extractPopularBooksTargetQuery(query = "") {
  return String(query || "")
    .replace(/도서관\s*에서의?/g, "도서관 ")
    .replace(/([가-힣0-9]+(?:구|군|시|읍|면|동))\s*에서의?/g, "$1 ")
    .replace(/도서관\s*의/g, "도서관 ")
    .replace(/([가-힣0-9]+(?:구|군|시|읍|면|동))\s*의/g, "$1 ")
    .replace(/\s+의\s+/g, " ")
    .replace(/잘\s*나가는|인기\s*많은|인기\s*대출|대출\s*인기|인기|많은|많이\s*빌린|많이\s*대출|베스트|추천|요즘\s*핫한|요즘|핫한/g, " ")
    .replace(/책|도서(?!관)|자료|목록|순위|랭킹/g, " ")
    .replace(KOREAN_REQUEST_TAIL_PATTERN, " ")
    .replace(/[?？]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function findDetailedRegionByDistrict(regionCode = "", districtName = "") {
  const normalizedDistrict = normalizeSearchText(districtName);
  if (!normalizedDistrict) return null;

  return DETAILED_REGION_MAP.find((item) => {
    if (regionCode && item.region !== regionCode) return false;
    return normalizeSearchText(item.districtName) === normalizedDistrict ||
      item.names.some((name) => normalizeSearchText(name) === normalizedDistrict);
  }) || null;
}

async function resolveData4LibraryByName(libraryQuery = "", selectedRegion = "") {
  const query = sanitizeQuery(libraryQuery, 120);
  if (!query) return null;

  let detailHint = getDetailedRegionHint(query, selectedRegion);
  let effectiveRegion = detailHint?.region || selectedRegion || getRegionCodeFromText(query);
  let effectiveDtlRegion = detailHint?.dtlRegion || "";

  if (!effectiveRegion) {
    const xmlCandidates = searchStandardLibraryDb(query, selectedRegion);
    const xmlExact = xmlCandidates.find((lib) =>
      normalizeSearchText(lib.name) === normalizeSearchText(query) ||
      normalizeSearchText(lib.name).includes(normalizeSearchText(query.replace(/도서관$/u, "")))
    ) || xmlCandidates[0];

    if (xmlExact?.sido) {
      effectiveRegion = getRegionCodeFromName(xmlExact.sido) || getRegionCodeFromText(xmlExact.sido);
      const xmlDetailHint = findDetailedRegionByDistrict(effectiveRegion, xmlExact.sigungu || "");
      if (xmlDetailHint) {
        detailHint = xmlDetailHint;
        effectiveDtlRegion = xmlDetailHint.dtlRegion;
      }
    }
  }

  const rankCandidates = (libraries = [], hint = null) => dedupeLibraries(filterLibrariesByDetailedRegion(libraries, hint))
    .map((lib) => ({
      ...lib,
      _score: scoreStrictLibraryNameMatch(lib, query) || computeLooseLibraryScore(lib, query)
    }))
    .filter((lib) => lib._score > 0)
    .sort((a, b) => (b._score || 0) - (a._score || 0));

  const fetchAndPick = async (region = "", dtlRegion = "", hint = null, maxPages = LIBRARY_SEARCH_MAX_PAGES_WITH_REGION) => {
    const fetchedLibraries = await fetchPagedLibraryKeywordResults(region, maxPages, dtlRegion);
    const ranked = rankCandidates(fetchedLibraries, hint);
    if (ranked.length === 0) return null;
    const { _score, ...library } = ranked[0];
    return library;
  };

  const maxPages = effectiveDtlRegion
    ? LIBRARY_SEARCH_MAX_PAGES_WITH_DTL_REGION
    : (effectiveRegion ? LIBRARY_SEARCH_MAX_PAGES_WITH_REGION : Math.max(LIBRARY_SEARCH_MAX_PAGES_NATIONWIDE, 8));

  const directMatch = await fetchAndPick(effectiveRegion, effectiveDtlRegion, detailHint, maxPages);
  if (directMatch) return directMatch;

  // 지역 힌트가 없는 정확한 도서관명은 전국 첫 몇 페이지만으로 누락될 수 있어
  // 광역시도별 목록을 순회해 한 번 더 찾는다. fetchPagedLibraryKeywordResults 캐시가 있어 반복 검색 부담은 줄어든다.
  if (!effectiveRegion) {
    for (const regionCode of Object.keys(REGION_CODE_TO_NAME)) {
      const regionalMatch = await fetchAndPick(regionCode, "", null, LIBRARY_SEARCH_MAX_PAGES_WITH_REGION);
      if (regionalMatch) return regionalMatch;
    }
  }

  return null;
}

async function resolvePopularBooksTarget(query = "", selectedRegion = "") {
  const rawQuery = sanitizeQuery(query, 160);
  const targetQuery = extractPopularBooksTargetQuery(rawQuery);
  const queryForLocation = targetQuery || rawQuery;

  if (targetQuery && isExplicitLibraryNameQuery(targetQuery)) {
    const library = await resolveData4LibraryByName(targetQuery, selectedRegion);
    if (!library?.id || String(library.id).startsWith("stdlib-")) {
      return {
        error: `“${targetQuery}”의 정보나루 도서관 코드를 찾지 못했어요. 도서관명을 조금 더 정확히 입력해 주세요.`
      };
    }

    return {
      type: "library",
      libCode: library.id,
      library,
      scopeLabel: `${library.name} 인기대출 도서`,
      note: "정보나루 도서관별 인기대출도서 기준입니다."
    };
  }

  const detailHint = getDetailedRegionHint(queryForLocation, selectedRegion);
  const region = detailHint?.region || selectedRegion || getRegionCodeFromText(queryForLocation);
  const dtlRegion = detailHint?.dtlRegion || "";

  if (region) {
    const regionName = detailHint?.districtName || REGION_CODE_TO_NAME[region] || "선택 지역";
    return {
      type: "region",
      region,
      dtlRegion,
      scopeLabel: `${regionName} 인기대출 도서`,
      note: "정보나루 지역별 인기대출도서 기준입니다."
    };
  }

  return {
    error: "인기 도서는 도서관명이나 지역을 함께 입력해 주세요. 예: 정독도서관에서 잘나가는 책, 강남구 인기 도서"
  };
}

/* ------------------------------
 * Routes
 * ------------------------------ */

app.get("/api/health", (req, res) => {
  const payload = { ok: true };

  if (HEALTH_EXPOSE_DETAILS) {
    payload.nationalLibraryEnabled = Boolean(NL_API_KEY);
    payload.data4LibraryCoolingDown = isData4LibraryCoolingDown();
    payload.standardLibraryDb = {
      loaded: standardLibraryDb.length > 0,
      loadedAt: standardLibraryLoadedAt ? new Date(standardLibraryLoadedAt).toISOString() : null
    };
  }

  res.json(payload);
});

app.get("/api/books", async (req, res) => {
  try {
    const rawKeyword = sanitizeQuery(req.query.keyword, 150);
    // /api/query-understanding 또는 프론트가 이미 제목을 정리해서 넘긴다.
    // 여기서 다시 availability용 정규화를 적용하면 "나는 어디에 있는가" 같은 제목이 훼손된다.
    const keyword = normalizePlainBookSearchKeyword(rawKeyword);

    if (!keyword) {
      return res.status(400).json({ error: "검색어를 입력해주세요." });
    }

    const books = await searchHybridBooks(keyword, { enrichTop: NATIONAL_LIBRARY_ENRICH_LIMIT, allowNationalLibraryFallback: true });

    return res.json({
      books,
      sources: {
        naver: true,
        nationalLibrary: Boolean(NL_API_KEY)
      }
    });
  } catch (error) {
    console.error("BOOK_SEARCH_ERROR:", error);
    return res.status(500).json({
      error: `도서 검색 중 오류가 발생했습니다: ${error.message}`
    });
  }
});

app.get("/api/book-recommendations", async (req, res) => {
  try {
    const query = sanitizeQuery(req.query.query, 180);

    if (!query) {
      return res.status(400).json({ error: "추천받고 싶은 상황이나 주제를 입력해주세요." });
    }

    const result = await getBookRecommendations(query);

    return res.json({
      books: result.books,
      message: result.message,
      note: result.note,
      searchQueries: result.plan.searchQueries,
      labels: result.plan.labels
    });
  } catch (error) {
    console.error("BOOK_RECOMMENDATION_ERROR:", error);
    return res.status(500).json({
      error: `추천 도서 검색 중 오류가 발생했습니다: ${error.message}`
    });
  }
});

app.post("/api/query-understanding", async (req, res) => {
  try {
    const userMessage = sanitizeQuery(req.body?.message || "", 300);
    const selectedRegion = sanitizeRegionCode(req.body?.selectedRegion || req.body?.region || "");

    if (!userMessage) {
      return res.status(400).json({ error: "검색어를 입력해주세요." });
    }

    const plan = await getQueryUnderstandingPlan(userMessage, selectedRegion);
    return res.json(plan);
  } catch (error) {
    console.error("QUERY_UNDERSTANDING_ERROR:", error);
    return res.status(500).json({
      error: `검색 의도 해석 중 오류가 발생했습니다: ${error.message}`
    });
  }
});

app.post("/api/assist", async (req, res) => {
  try {
    const userMessage = sanitizeQuery(req.body?.message || "", 300);

    if (!userMessage) {
      return res.status(400).json({ error: "질문을 입력해주세요." });
    }

    const intentResult = await classifyAssistIntent(userMessage);

    if (intentResult.intent === "faq") {
      const faqMatch = await findBestFaqMatch(userMessage);
      if (faqMatch) {
        return res.json(buildAssistResponse({ answer: faqMatch.answer }));
      }
      return res.json(buildContactResponse());
    }

    if (intentResult.intent === "library_info") {
      return res.json(buildAssistResponse({
        kind: "redirect_library",
        answer: "이 질문은 도서관 검색으로 보는 편이 더 정확합니다. 가능하면 지역을 함께 입력해 주세요. 예: 서울 중구 도서관",
        actionButtons: [
          { label: "도서관 검색으로 다시 입력", action: "fill_input", value: userMessage }
        ]
      }));
    }

    if (intentResult.intent === "recommendation") {
      const recommendation = await getBookRecommendations(userMessage);
      const preview = recommendation.books.slice(0, 5).map((book, index) => {
        const author = book.author ? ` — ${book.author}` : "";
        return `${index + 1}. ${book.title}${author}`;
      }).join("\n");

      return res.json(buildAssistResponse({
        kind: "recommendation",
        answer: preview
          ? `${recommendation.message}

${preview}

책 카드와 소장 도서관 버튼으로 보려면 같은 문장을 검색창에 다시 입력해 주세요.`
          : "조건에 맞는 추천 도서를 찾지 못했어요. 분위기나 주제를 조금 다르게 적어주세요.",
        actionButtons: [
          { label: "추천 검색어 다시 입력", action: "fill_input", value: userMessage },
          { label: "문의하기", action: "contact", url: "https://minervalib.com/?page_id=78" }
        ]
      }));
    }

    if (intentResult.intent === "book_info" || isLikelyPlainBookQuery(userMessage)) {
      const title = isBareBookWhereQuestion(userMessage)
        ? normalizeBookSearchKeyword(userMessage)
        : extractBookTitleFromQuestion(userMessage);
      const books = await searchHybridBooks(title, { enrichTop: 1, allowNationalLibraryFallback: true });

      const rankedBooks = books.sort((a, b) => {
        const aTitle = normalizeSearchText(a.title);
        const bTitle = normalizeSearchText(b.title);
        const q = normalizeSearchText(title);

        const aExact = aTitle === q ? 1 : 0;
        const bExact = bTitle === q ? 1 : 0;
        if (bExact !== aExact) return bExact - aExact;

        const aStarts = aTitle.startsWith(q) ? 1 : 0;
        const bStarts = bTitle.startsWith(q) ? 1 : 0;
        if (bStarts !== aStarts) return bStarts - aStarts;

        const aMeta = scoreBookCandidateForQuery(a, title);
        const bMeta = scoreBookCandidateForQuery(b, title);
        return bMeta - aMeta;
      });

      const book = rankedBooks.find((item) => item.description) || rankedBooks[0];

      if (!book) {
        return res.json(buildContactResponse());
      }

      // description 유무 관계없이 GPT 호출 (description 없으면 서지정보 기반 소개)
      const aiAnswer = await getOpenAIBookExplanation(book, userMessage);

      const answer = aiAnswer || book.description || formatBookFallback(book);

      return res.json(buildAssistResponse({
        kind: "book_intro",
        answer,
        actionButtons: [
          { label: "이 작품이 있는 도서관 찾기", action: "fill_input", value: `${book.title} 있는 도서관` },
          { label: "문의하기", action: "contact", url: "https://minervalib.com/?page_id=78" }
        ]
      }));
    }

    return res.json(buildContactResponse());
  } catch (error) {
    console.error("ASSIST_ERROR:", error);
    return res.status(500).json({
      error: `안내 응답 처리 중 오류가 발생했습니다: ${error.message}`
    });
  }
});

app.get("/api/popular-books", async (req, res) => {
  try {
    if (!DATA4LIBRARY_API_KEY) {
      return res.status(500).json({
        error: "정보나루 API 키가 설정되지 않았습니다. 인기대출 도서 조회는 정보나루 API가 필요해요."
      });
    }

    let query = sanitizeQuery(req.query.query, 160);
    const selectedRegion = sanitizeRegionCode(req.query.region);

    if (!query && selectedRegion) {
      query = REGION_CODE_TO_NAME[selectedRegion] || selectedRegion;
    }

    if (!query) {
      return res.status(400).json({ error: "검색어를 입력해주세요." });
    }

    if (isData4LibraryCoolingDown()) {
      return res.status(503).json({
        error: getData4LibraryCooldownMessage()
      });
    }

    const target = await resolvePopularBooksTarget(query, selectedRegion);
    if (target.error) {
      return res.status(400).json({ error: target.error });
    }

    const books = await fetchPopularBooksByLibraryTarget(target);

    return res.json({
      books,
      targetType: target.type,
      library: target.library || null,
      scopeLabel: target.scopeLabel || "인기대출 도서",
      note: target.note || ""
    });
  } catch (error) {
    console.error("POPULAR_BOOKS_SEARCH_ERROR:", error);

    if (error.message.includes("정보나루 API 오류:")) {
      return res.status(503).json({
        error: mapData4LibraryErrorMessage(error.message)
      });
    }

    return res.status(500).json({
      error: `인기 도서 검색 중 오류가 발생했습니다: ${error.message}`
    });
  }
});

app.get("/api/libraries", async (req, res) => {
  try {
    if (!DATA4LIBRARY_API_KEY) {
      return res.status(500).json({
        error: "정보나루 API 키가 설정되지 않았습니다."
      });
    }

    const isbn = sanitizeIsbn(req.query.isbn);
    const region = sanitizeRegionCode(req.query.region);

    if (!isbn) {
      return res.status(400).json({ error: "ISBN 정보가 필요합니다." });
    }

    const cached = getCachedLibraries(isbn, region);
    if (cached) {
      return res.json({ ...cached, cached: true });
    }

    if (isData4LibraryCoolingDown()) {
      return res.status(503).json({
        error: getData4LibraryCooldownMessage()
      });
    }

    const fetchResult = await fetchPagedLibrariesByBook(isbn, region);
    const libraries = dedupeLibraries(fetchResult.libraries);
    const payload = {
      libraries,
      cached: false,
      searchScope: region ? "selected_region" : "nationwide",
      totalCount: fetchResult.totalCount,
      fetchedCount: libraries.length,
      fetchedPages: fetchResult.fetchedPages,
      totalPages: fetchResult.totalPages,
      partial: fetchResult.partial,
      regionsSearched: fetchResult.regionsSearched || (region ? 1 : DATA4LIBRARY_REGION_CODES.length),
      regionErrors: fetchResult.regionErrors || [],
      note: fetchResult.partial
        ? (region
          ? "소장 도서관 결과가 많아 우선 확인 가능한 범위부터 반환했습니다."
          : "전국 소장도서 조회는 지역별로 나누어 확인했습니다. 결과가 많거나 일부 지역 API가 불안정하면 우선 확인 가능한 범위부터 반환합니다.")
        : ""
    };

    setCachedLibraries(isbn, region, payload);

    return res.json(payload);
  } catch (error) {
    console.error("LIBRARY_SEARCH_ERROR:", error);

    if (error.message.includes("정보나루 API 오류:")) {
      return res.status(503).json({
        error: mapData4LibraryErrorMessage(error.message)
      });
    }

    return res.status(500).json({
      error: `도서관 검색 중 오류가 발생했습니다: ${error.message}`
    });
  }
});

app.get("/api/library-search", async (req, res) => {
  try {
    const query = sanitizeQuery(req.query.query);
    const selectedRegion = sanitizeRegionCode(req.query.region);
    const debug = String(req.query.debug || "") === "1";

    if (!query) {
      return res.status(400).json({ error: "검색어를 입력해주세요." });
    }

    const explicitLibraryName = isExplicitLibraryNameQuery(query);
    let constraints = extractLibraryLocationConstraints(query, selectedRegion);
    const detailHint = getDetailedRegionHint(query, selectedRegion) || getLibraryPlaceAliasRegionHint(query, selectedRegion);
    if (detailHint) {
      constraints = {
        ...constraints,
        sido: constraints.sido || REGION_CODE_TO_NAME[detailHint.region] || "",
        district: constraints.district || detailHint.districtName || "",
        hasLocationConstraint: true
      };
    }
    const effectiveRegion = detailHint?.region || selectedRegion || getRegionCodeFromText(query);
    const effectiveDtlRegion = detailHint?.dtlRegion || "";
    const cacheKey = JSON.stringify({
      query,
      region: effectiveRegion,
      dtlRegion: effectiveDtlRegion,
      explicitLibraryName,
      constraints,
      debug
    });

    const cached = getTimedCacheValue(librarySearchCache, cacheKey);
    if (cached) {
      return res.json(cached);
    }

    const hasStrongLocation = hasStrongLocationToken(query);
    if (!effectiveRegion && !hasStrongLocation && !explicitLibraryName && isGenericLibraryOnlyQuery(query)) {
      return res.json(buildNeedsRegionLibrarySearchPayload());
    }

    const nearbyPlace = await resolveNearbyPlaceAnchor(query);
    if (nearbyPlace) {
      const payload = buildNearbyLibrarySearchPayload(query, nearbyPlace);
      setTimedCacheValue(librarySearchCache, cacheKey, payload, LIBRARY_SEARCH_CACHE_TTL_MS);
      return res.json(payload);
    }

    if (hasNearbyLibrarySignal(query)) {
      const anchorQuery = extractNearbyPlaceAnchorQuery(query);

      if (anchorQuery && isAdministrativePlaceAnchorQuery(anchorQuery)) {
        const regionalQuery = `${anchorQuery} 도서관`;
        const regionalDetailHint = getDetailedRegionHint(regionalQuery, selectedRegion);
        const payload = buildXmlOnlyLibrarySearchPayload(regionalQuery, selectedRegion, {
          explicitLibraryName: false,
          constraints: extractLibraryLocationConstraints(regionalQuery, selectedRegion),
          detailHint: regionalDetailHint,
          debug
        });
        payload.note = `${anchorQuery}은(는) 장소 좌표가 아니라 지역명으로 해석해 전국도서관표준데이터 기준 결과를 보여드려요.`;
        setTimedCacheValue(librarySearchCache, cacheKey, payload, LIBRARY_SEARCH_CACHE_TTL_MS);
        return res.json(payload);
      }

      if (anchorQuery) {
        const message = NAVER_PLACE_ANCHOR_ENABLED
          ? "장소 좌표를 찾지 못했어요. 장소명을 조금 더 구체적으로 입력해 주세요. 예: 휘문고 근처 도서관"
          : "장소명 기준 근처 검색은 현재 내부 등록 장소만 지원합니다. 운영 환경에서 NAVER_PLACE_ANCHOR_ENABLED=true를 켜면 네이버 지역검색을 좌표 확인용으로만 사용할 수 있어요.";
        const payload = {
          libraries: [],
          searchScope: "nearby",
          needsPlaceAnchor: true,
          targetPlace: {
            label: anchorQuery,
            source: "unresolved"
          },
          message
        };
        setTimedCacheValue(librarySearchCache, cacheKey, payload, LIBRARY_SEARCH_CACHE_TTL_MS);
        return res.json(payload);
      }
    }

    if (!DATA4LIBRARY_API_KEY) {
      const payload = buildXmlOnlyLibrarySearchPayload(query, selectedRegion, {
        explicitLibraryName,
        constraints,
        detailHint,
        debug
      });
      payload.note = "정보나루 API 키 없이 전국도서관표준데이터 기준으로 검색한 결과예요.";
      setTimedCacheValue(librarySearchCache, cacheKey, payload, LIBRARY_SEARCH_CACHE_TTL_MS);
      return res.json(payload);
    }

    if (isData4LibraryCoolingDown()) {
      const payload = buildXmlOnlyLibrarySearchPayload(query, selectedRegion, {
        explicitLibraryName,
        constraints,
        detailHint,
        debug
      });
      payload.warning = getData4LibraryCooldownMessage();
      return res.json(payload);
    }

    if (!effectiveRegion && !hasStrongLocation && !explicitLibraryName) {
      if (isGenericLibraryOnlyQuery(query)) {
        return res.json(buildNeedsRegionLibrarySearchPayload());
      }

      const xmlOnly = searchStandardLibraryDb(query, "")
        .slice(0, 20)
        .map((lib) => attachLibraryRankingMetadata(lib, query));
      if (xmlOnly.length > 0) {
        return res.json({
          libraries: xmlOnly,
          searchScope: "nationwide",
          note: "전국도서관표준데이터 기준 결과입니다. 지역을 함께 입력하면 더 정확한 결과를 얻을 수 있어요."
        });
      }

      return res.json({
        libraries: [],
        searchScope: "nationwide",
        needsRegion: true,
        message: "정확한 도서관 검색을 위해 지역을 함께 입력해 주세요. 예: 서울 중구 도서관"
      });
    }

    const maxPages = effectiveDtlRegion
      ? LIBRARY_SEARCH_MAX_PAGES_WITH_DTL_REGION
      : (effectiveRegion
        ? LIBRARY_SEARCH_MAX_PAGES_WITH_REGION
        : (explicitLibraryName ? Math.max(LIBRARY_SEARCH_MAX_PAGES_NATIONWIDE, 6) : LIBRARY_SEARCH_MAX_PAGES_NATIONWIDE));

    let fetchedLibraries = [];
    try {
      fetchedLibraries = await fetchPagedLibraryKeywordResults(effectiveRegion, maxPages, effectiveDtlRegion);
    } catch (error) {
      console.error("LIBRARY_REGION_FETCH_ERROR:", {
        regionCode: effectiveRegion || "nationwide",
        dtlRegionCode: effectiveDtlRegion || "",
        message: error.message
      });

      const fallbackPayload = buildXmlOnlyLibrarySearchPayload(query, selectedRegion, {
        explicitLibraryName,
        constraints,
        detailHint,
        debug
      });

      if (fallbackPayload.libraries.length > 0) {
        fallbackPayload.warning = error.message.includes("정보나루 API 오류:")
          ? mapData4LibraryErrorMessage(error.message)
          : "정보나루 연결이 불안정해서 전국도서관표준데이터 기준으로 보여드려요.";
        return res.json(fallbackPayload);
      }

      if (error.message.includes("정보나루 API 오류:")) {
        return res.status(503).json({
          error: mapData4LibraryErrorMessage(error.message),
          searchScope: effectiveDtlRegion ? "detailed_region" : (effectiveRegion ? "selected_region" : "nationwide")
        });
      }

      throw error;
    }

    const data4Candidates = dedupeLibraries(
      filterLibrariesByDetailedRegion(fetchedLibraries, detailHint)
    );

    let strictData4 = [];
    if (explicitLibraryName) {
      strictData4 = data4Candidates
        .map((lib) => ({ ...lib, _score: scoreStrictLibraryNameMatch(lib, query) }))
        .filter((lib) => lib._score > 0);
    } else {
      strictData4 = data4Candidates
        .map((lib) => ({
          ...lib,
          _score: scoreStrictRegionLibraryMatch(lib, query, constraints, { selectedRegion })
        }))
        .filter((lib) => lib._score > 0);
    }

    const xmlDbResults = searchStandardLibraryDb(query, selectedRegion)
      .map((lib) => ({
        ...lib,
        _score: scoreStandardLibraryMatch(lib, query, constraints, {
          selectedRegion,
          explicitLibraryName
        })
      }))
      .filter((lib) => lib._score > 0);

    const merged = mergeLibraryResults(
      strictData4.map(({ _score, ...lib }) => lib),
      xmlDbResults.map(({ _score, ...lib }) => lib),
      {
        query,
        constraints,
        explicitLibraryName,
        selectedRegion
      }
    );

    const intentProfile = inferLibraryIntentRankingProfile(query);
    const finalResult = merged.map(({ _score, ...lib }) => attachLibraryRankingMetadata(lib, query, { explicitLibraryName, intentProfile }));

    const payload = {
      libraries: finalResult,
      searchScope: effectiveDtlRegion ? "detailed_region" : (effectiveRegion ? "selected_region" : "nationwide"),
      actionButtons: explicitLibraryName && finalResult.length > 0 ? getDirectLibraryFollowupActions(query) : []
    };

    if (debug) {
      payload.debug = {
        query,
        selectedRegion,
        effectiveRegion,
        effectiveDtlRegion,
        explicitLibraryName,
        constraints,
        fetchedCount: fetchedLibraries.length,
        matchedData4Count: strictData4.length,
        matchedXmlCount: xmlDbResults.length,
        mergedCount: finalResult.length,
        intentRankingProfile: intentProfile
      };
    }

    setTimedCacheValue(librarySearchCache, cacheKey, payload, LIBRARY_SEARCH_CACHE_TTL_MS);
    return res.json(payload);
  } catch (error) {
    console.error("LIBRARY_KEYWORD_SEARCH_ERROR:", error);

    if (error.message.includes("정보나루 API 오류:")) {
      return res.status(503).json({
        error: mapData4LibraryErrorMessage(error.message)
      });
    }

    return res.status(500).json({
      error: `도서관 검색 중 오류가 발생했습니다: ${error.message}`
    });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
