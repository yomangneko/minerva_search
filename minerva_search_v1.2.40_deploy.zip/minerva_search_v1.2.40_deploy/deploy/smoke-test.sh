#!/usr/bin/env sh
set -eu

BASE_URL="${BASE_URL:-http://localhost:${PORT:-3000}}"

echo "[1/2] health check: $BASE_URL/api/health"
curl -fsS "$BASE_URL/api/health"
echo

echo "[2/2] library intent ranking smoke test"
curl -fsS "$BASE_URL/api/library-search?query=%EA%B0%95%EB%82%A8%EA%B5%AC%20%EC%95%BC%EA%B0%84%20%EC%9A%B4%EC%98%81%20%EB%8F%84%EC%84%9C%EA%B4%80&debug=1"
echo
