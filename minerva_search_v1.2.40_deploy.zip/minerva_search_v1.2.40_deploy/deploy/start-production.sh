#!/usr/bin/env sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
APP_DIR="$(dirname "$SCRIPT_DIR")/backend"

cd "$APP_DIR"

if [ ! -f .env ]; then
  echo "backend/.env 파일이 없습니다. backend/.env.example을 복사해서 먼저 설정하세요." >&2
  exit 1
fi

npm ci --omit=dev
NODE_ENV=production npm start
