---
name: Query-understanding case
about: Report a query that routes incorrectly or ambiguously
labels: query-understanding
---

## User query

```text

```

## Selected region, if any


## Expected intent

- [ ] book_search
- [ ] book_availability
- [ ] library_search
- [ ] popular_books
- [ ] book_recommendation
- [ ] book_info
- [ ] faq
- [ ] ambiguous
- [ ] unknown

## Actual behavior


## Notes

Please do not include API keys, `.env` contents, or private logs.
