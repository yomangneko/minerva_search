# Contributing

Thanks for considering a contribution.

## Development setup

```bash
cd backend
cp .env.example .env
npm install
npm run check
npm run dev
```

## Pull request guidelines

- Keep API keys and local data out of commits.
- Add a short explanation for query-understanding changes, especially when they affect ambiguous Korean region/title behavior.
- Prefer small, reviewable patches.
- Include example queries and expected routing behavior for parser changes.
