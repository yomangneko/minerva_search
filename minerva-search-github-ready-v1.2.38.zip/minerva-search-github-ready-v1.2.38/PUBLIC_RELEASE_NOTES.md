# Public release notes

Prepared from `minerva_search_v1.2.38_selected_region_guardrails(1).zip` as a GitHub-ready public package.

## Removed

- Backup files such as `server.js.bak*`
- Loose patch-note files in `backend/`
- `backend/library_data.xml`, pending source/redistribution verification

## Added or changed

- README, docs, license, security policy, contribution guide, and issue template
- `.env.example` with empty placeholders only
- Environment-based production CORS origins
- Environment-based contact URL
- Verbose external API logs gated by `DEBUG_EXTERNAL_API_LOGS`

## Validation

- JavaScript syntax check: `node --check backend/server.js`
- Regex-based scan for common secret/token patterns
- Confirmed no `.env`, backup files, loose patch-note files, or XML dataset in the package
