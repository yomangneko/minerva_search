# Security Policy

Please do not open a public issue for secrets, credential leaks, or exploitable vulnerabilities.

For private deployments:

- Never commit `.env`.
- Rotate any API key that may have been exposed.
- Configure `ALLOWED_ORIGINS`, `PUBLIC_APP_ORIGIN`, or `PRODUCTION_ORIGINS` in production.
- Leave `ADMIN_SECRET` empty unless the reload endpoint is needed.
- Keep detailed health output disabled unless it is intentionally public.
- Keep verbose external API logging disabled outside local debugging.

Secrets include `DATA4LIBRARY_API_KEY`, `NAVER_CLIENT_SECRET`, `OPENAI_API_KEY`, `NOTION_API_KEY`, `NL_API_KEY`, and `ADMIN_SECRET`.
