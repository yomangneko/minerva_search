# Minerva Search

Minerva Search is a Node.js backend for Korean public-library and book discovery. It combines book search, holdings lookup, library search, popular-loan data, and Korean natural-language query understanding with region-aware guardrails.

This public release keeps the search functionality intact while removing private deployment details, backup files, loose patch-note files, and the local XML dataset whose redistribution source should be verified separately.

## What it does

- Searches books through Naver Book Search, with optional National Library of Korea enrichment.
- Finds libraries that hold a book through Data4Library / 정보나루.
- Searches public libraries by region, district, name, and nearby-place style Korean queries.
- Provides popular-loan book lookup by library or region.
- Interprets Korean natural-language search messages into API routing plans.
- Uses conservative guardrails for ambiguous region names such as `중구`, `서구`, `동구`, `남구`, `북구`, `광주`, and `종로`.
- Supports optional OpenAI-assisted planning while keeping deterministic rule-based fallback behavior.

## Repository layout

```text
minerva-search-github-ready-v1.2.38/
├─ backend/
│  ├─ server.js
│  ├─ package.json
│  └─ .env.example
├─ data/
│  └─ README.md
├─ docs/
│  ├─ architecture.md
│  ├─ changelog.md
│  ├─ guardrails.md
│  └─ publication-checklist.md
├─ .github/ISSUE_TEMPLATE/
├─ .gitignore
├─ LICENSE
├─ CONTRIBUTING.md
├─ SECURITY.md
└─ README.md
```

## Quick start

```bash
cd backend
cp .env.example .env
npm install
npm run check
npm run dev
```

Then check the server:

```bash
curl http://localhost:3000/api/health
```

For a minimal local run, configure at least `NAVER_CLIENT_ID` and `NAVER_CLIENT_SECRET` for book search. Holdings and popular-loan endpoints require `DATA4LIBRARY_API_KEY`. OpenAI, Notion, and National Library API keys are optional.

## Environment variables

Start from `backend/.env.example`. The most important settings are:

| Variable | Required | Purpose |
| --- | --- | --- |
| `NAVER_CLIENT_ID`, `NAVER_CLIENT_SECRET` | Yes for book search | Naver Book Search API credentials. |
| `DATA4LIBRARY_API_KEY` | Yes for holdings/popular loans | Data4Library / 정보나루 key. |
| `OPENAI_API_KEY` | Optional | AI-assisted intent planning and book explanations. |
| `NL_API_KEY` | Optional | National Library of Korea enrichment/fallback. |
| `NOTION_API_KEY`, `NOTION_FAQ_DATABASE_ID` | Optional | FAQ lookup for `/api/assist`. |
| `ALLOWED_ORIGINS`, `PUBLIC_APP_ORIGIN`, `PRODUCTION_ORIGINS`, `PRODUCTION_CORS_ORIGINS` | Production recommended | Browser CORS allowlist. |
| `CONTACT_URL` | Optional | URL used in assistant fallback action buttons. |
| `ADMIN_SECRET` | Optional | Enables `/api/admin/reload-library-db`; disabled when empty. |
| `STANDARD_LIB_XML_PATH` | Optional | Path to a local standard-library XML dataset. |

## API overview

| Method | Path | Description |
| --- | --- | --- |
| `GET` | `/api/health` | Basic health check. |
| `GET` | `/api/books?keyword=...` | Book search. |
| `GET` | `/api/book-recommendations?query=...` | Book recommendations from a theme or situation. |
| `POST` | `/api/query-understanding` | Converts a Korean user message into a search routing plan. |
| `POST` | `/api/assist` | FAQ/book-info/recommendation assistant response. |
| `GET` | `/api/popular-books?query=...&region=11` | Popular-loan books by library or region. |
| `GET` | `/api/libraries?isbn=...&region=11` | Libraries that hold a given ISBN. |
| `GET` | `/api/library-search?query=...&region=11` | Library search by natural-language location/name query. |
| `POST` | `/api/admin/reload-library-db` | Reloads local XML data when `ADMIN_SECRET` is configured. |

## Local standard-library XML data

`backend/library_data.xml` is intentionally not included in this public release. The server can run without it, but XML-backed fallback library search will be limited.

To use your own dataset, place the file at `backend/library_data.xml` or set `STANDARD_LIB_XML_PATH` in `.env`. Before committing any dataset, check its redistribution license and attribution requirements.

## Security notes before publishing

- Do not commit `.env` or real API keys.
- Keep `ADMIN_SECRET` non-empty only in trusted deployments.
- In production, set `ALLOWED_ORIGINS`, `PUBLIC_APP_ORIGIN`, or `PRODUCTION_ORIGINS` explicitly.
- Avoid enabling `HEALTH_EXPOSE_DETAILS=1` on public deployments unless the details are intended to be visible.
- Keep `DEBUG_EXTERNAL_API_LOGS=0` outside local debugging.
- Review local datasets before committing them.

## License

MIT. See [LICENSE](./LICENSE).
