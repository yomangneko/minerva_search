# Changelog

This public release consolidates the scattered working-tree patch notes into a readable project history. Raw `*_PATCH_NOTES.txt`, `*_NOTES.txt`, and backup `server.js.bak*` files are intentionally omitted.

## v1.2.38

- Added selected-region-aware ambiguous local-region guardrails.
- Prevented duplicated district names from being silently corrected to a different broad region when they conflict with the selected region.
- Strengthened detailed-region alias hints with invalid/ambiguous selected-region states.

## v1.2.37

- Moved duplicated local-region checks into the common plan-normalization path.
- Shared ambiguous-region clarification across library search, book availability, popular books, and recommendation/info variants.

## v1.2.33–v1.2.36

- Hardened ambiguous-region ordering for `중구`, `서구`, `동구`, `남구`, and `북구`.
- Kept clear library listing/recommendation requests ahead of book/library ambiguity parsing.
- Added regression locks for edge cases around library listings, recommendation, popular books, and book availability.

## v1.2.30–v1.2.32

- Stabilized loan-availability expressions such as `대출 가능`, `대출가능`, and `대출 가능한 도서관`.
- Preserved specific-library availability queries such as `정독도서관 데미안 대출 가능`.
- Routed region + generic library + book + loan forms to book availability instead of generic library search.
- Reduced destructive normalization at API boundaries.

## v1.2.27–v1.2.29

- Added AI-planned routing guardrails and natural-language context fixes.
- Preserved titles for “어느/어떤/무슨 도서관에 있어” style availability questions.
- Recognized spaced specific-library names such as `정독 도서관 데미안 있어?`.
- Added digital/audio routing boundaries and large-print edition candidate preservation.

## v1.2.23–v1.2.26

- Refactored the optional AI planner so model output is a structured search plan, not raw regex.
- Preserved AI/rule book-search titles without applying availability-specific normalization.
- Added `bookTitleCandidates`, `filters`, `apiRoute`, and `needsClarification` to search plans.
- Reduced destructive Korean particle stripping for title endings.

## v1.2.20–v1.2.22

- Reordered query-understanding priorities around library search, book availability, and FAQ/service questions.
- Improved selected-region propagation and region guardrails.
- Added stronger separation for three meanings of `도서관`: place search, holding lookup, and service/help topic.

## v1.2.14–v1.2.19

- Introduced optional AI query understanding.
- Added rule/AI arbitration so confident deterministic routes are not blindly overwritten.
- Improved natural-language availability routing for suffix/prefix region phrases.
- Added loose district/place alias handling.

## v1.2.11–v1.2.13

- Added colloquial Korean where-question handling.
- Treated short title + `어디?` queries as book-location intent when appropriate.
- Fixed nationwide holding lookup by querying per region and adding edition-aware retries.
