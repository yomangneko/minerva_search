# Publication checklist

## Already cleaned in this package

- Removed backup server files.
- Removed loose patch-note files from `backend/`.
- Consolidated project history into `docs/changelog.md`.
- Added `backend/.env.example`.
- Added `.gitignore` rules for secrets, dependencies, backups, archives, and local datasets.
- Excluded `backend/library_data.xml` until source/redistribution terms are verified.
- Added MIT `LICENSE`, `SECURITY.md`, and `CONTRIBUTING.md`.
- Made production CORS origins environment-based.
- Made fallback contact URL environment-based.
- Gated verbose external API logs behind `DEBUG_EXTERNAL_API_LOGS`.

## Do before pushing

- Review `LICENSE`; change it if MIT is not your intended license.
- Decide whether to publish a sample dataset, no dataset, or verified public-data snapshot.
- Add screenshots or a demo GIF if this will be used as an OSS application portfolio.
- Create a local `backend/.env`, but never commit it.
- Check GitHub secret scanning results after the first push.

## Suggested first commit

```bash
git init
git add .
git commit -m "Initial public release of Minerva Search"
git branch -M main
git remote add origin git@github.com:<your-id>/minerva-search.git
git push -u origin main
```
