# Architecture

Minerva Search is currently a single Express backend.

## Runtime flow

1. The client sends a direct API request or a natural-language query.
2. `/api/query-understanding` applies deterministic Korean rules first.
3. If configured, OpenAI-assisted planning can be used when rules are not confident.
4. The backend routes the request to book search, holdings search, library search, popular-loan lookup, recommendations, or assistant fallback.
5. External API calls use timeouts, short-lived caches, and per-client rate limits.
6. Library-search fallback can use a local standard-library XML dataset when present.

## Main modules inside `server.js`

- Environment setup, CORS, and rate limiting.
- Query sanitization and shared utility helpers.
- Book search normalization and external API wrappers.
- Korean query-understanding rules and optional AI fallback planning.
- Region aliases, detailed-region hints, and ambiguous-region guardrails.
- Data4Library holdings/popular-loan integrations.
- Naver Book and optional Naver Local Search integrations.
- National Library of Korea optional enrichment.
- Notion FAQ optional integration.
- Express API routes.

## Caching and rate limits

The server uses in-memory maps for short-lived caches. This is simple and deployment-friendly for small instances, but larger production deployments should consider a shared cache such as Redis.

Rate limits are also in-memory and configurable via `.env`.

## Optional integrations

The server is designed to degrade gracefully:

- Without OpenAI, deterministic query understanding still works.
- Without a local XML dataset, XML-backed fallback search is skipped.
- Without Notion, FAQ fallback returns a contact-style response if `CONTACT_URL` is configured.
- Without Data4Library, holdings and popular-loan endpoints are limited or unavailable.
