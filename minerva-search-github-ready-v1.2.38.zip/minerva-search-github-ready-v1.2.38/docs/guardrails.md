# Query-understanding guardrails

The search parser is intentionally conservative because Korean library/book queries often reuse the same words for places, institutions, and book titles.

## Core principles

- Do not destructively remove possible book-title text unless the pattern is very clear.
- Treat selected user region as context, but do not let it override explicit query text.
- Distinguish book availability from library-location search before routing.
- Avoid nationwide Data4Library calls for broad generic queries such as `도서관`.
- Use local XML fallback when Data4Library is unavailable or too broad.
- Preserve ambiguous local region names until there is enough context.

## Examples of ambiguity handled

- `중구 도서관`: asks for a broader region unless the user has selected one.
- `서울 중구 도서관`: resolves to Seoul.
- `부산 서구 데미안 있어?`: keeps the selected/explicit broad region and does not remap to another city.
- `종로도서관`: likely a specific library name, not just “libraries in Jongno”.
- `휘문고 근처 도서관`: can use place anchoring if enabled; otherwise it asks for a more precise place.

## AI fallback boundary

OpenAI-assisted planning is optional. Rules are applied first, and model output is validated against known intents/routes before it is accepted. The model returns structured search-plan fields rather than raw executable code or arbitrary regular expressions.
