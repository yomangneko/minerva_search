# Data files

The original working ZIP included `backend/library_data.xml`. It is excluded from this public package because the exact dataset source and redistribution terms should be confirmed before publishing.

The backend still runs without this file. For XML-backed fallback library search, provide your own standard-library XML file and point `STANDARD_LIB_XML_PATH` to it, or place it at `backend/library_data.xml`.

Suggested public-data attribution, once verified:

> This project may use public library metadata available through Korean public-data portals and/or public library APIs. The data belongs to the respective public-data providers and may be subject to separate terms from the source-code license.
